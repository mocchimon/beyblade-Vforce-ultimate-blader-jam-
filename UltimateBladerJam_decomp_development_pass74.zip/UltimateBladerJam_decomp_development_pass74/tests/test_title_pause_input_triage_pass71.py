import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pass71',ROOT/'tools/audit_title_pause_input_triage_pass71.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class TitlePauseInputTriageTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.data=ROM.read_bytes()
 def test_reference_rom(self): self.assertTrue(mod.audit(self.data)['matches_reference_rom'])
 def test_fingerprint_count(self): self.assertEqual(mod.audit(self.data)['verified_halfwords'],33)
 def test_masks_and_arguments(self):
  d=mod.audit(self.data); self.assertEqual([x['mask'] for x in d['observed_input_masks']],[1,256,4]); self.assertEqual(d['conditional_arguments_to_08049250'],['0x12','0x11','0x13'])
 def test_instruction_mutation_rejected(self):
  b=bytearray(self.data); b[0x43D42]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): mod.audit(b)
 def test_rom_size_rejected(self):
  with self.assertRaisesRegex(ValueError,'8 MiB'): mod.audit(self.data[:-1])
if __name__=='__main__': unittest.main()
