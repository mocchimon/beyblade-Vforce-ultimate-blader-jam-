import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_state_motion_field_consumers_pass67', ROOT/'tools/audit_state_motion_field_consumers_pass67.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class StateMotionFieldConsumerTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rom=ROM.read_bytes()
 def test_original_rom_and_consumer_fingerprints(self):
  result=AUDIT.audit(self.rom); self.assertTrue(result['sha256_matches_expected_rom']); self.assertEqual(result['pass'],67); self.assertGreaterEqual(len(AUDIT.HALFWORDS),45)
 def test_consumer_mutation_rejected(self):
  data=bytearray(self.rom); data[0x08049098-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
 def test_reset_helper_mutation_rejected(self):
  data=bytearray(self.rom); data[0x08049030-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
 def test_callsite_mutation_rejected(self):
  data=bytearray(self.rom); data[0x0804966A-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
 def test_state_base_literal_mutation_rejected(self):
  data=bytearray(self.rom); data[0x080490CC-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'word mismatch'): AUDIT.audit(data)
if __name__=='__main__': unittest.main()
