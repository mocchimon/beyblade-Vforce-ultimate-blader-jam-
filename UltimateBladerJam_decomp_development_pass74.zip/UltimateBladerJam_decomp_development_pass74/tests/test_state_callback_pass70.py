import importlib.util,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit70',ROOT/'tools/audit_state_callback_pass70.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class CallbackAudit(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.rom=ROM.read_bytes()
 def test_original(self):self.assertTrue(mod.audit(self.rom)['original_rom_sha256_matches'])
 def test_count(self):self.assertEqual(mod.audit(self.rom)['instruction_halfwords'],len(mod.HALFWORDS))
 def test_caller_mutation(self):
  b=bytearray(self.rom);b[0x4990c]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'):mod.audit(b)
 def test_helper_mutation(self):
  b=bytearray(self.rom);b[0x508e4]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'):mod.audit(b)
 def test_literal_mutation(self):
  b=bytearray(self.rom);b[0x4994c]^=1
  with self.assertRaisesRegex(ValueError,'literal mismatch'):mod.audit(b)
