import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_context_history_pass63',ROOT/'tools/audit_context_history_pass63.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class ContextHistoryPass63Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rom=ROM.read_bytes()
 def test_original_rom_and_history_targets(self):
  r=AUDIT.audit(self.rom); self.assertTrue(r['sha256_matches_expected_rom']); self.assertEqual(r['state_block'],'0x03000650'); self.assertEqual(r['restore_or_pop_helper'],'0x0804917C')
 def test_select_instruction_mutation_rejected(self):
  b=bytearray(self.rom); b[0x08049136-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_restore_instruction_mutation_rejected(self):
  b=bytearray(self.rom); b[0x080491A0-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_global_literal_mutation_rejected(self):
  b=bytearray(self.rom); b[0x08049158-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'literal mismatch'): AUDIT.audit(b)
 def test_wrong_rom_size_rejected(self):
  with self.assertRaisesRegex(ValueError,'8 MiB'): AUDIT.audit(self.rom[:-1])
if __name__=='__main__': unittest.main()
