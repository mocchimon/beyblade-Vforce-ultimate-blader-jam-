import importlib.util,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit73',ROOT/'tools/audit_full_rom_pages_pass73.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class InventoryTests(unittest.TestCase):
 def test_zero(self):self.assertEqual(m.classify(bytes(4096)),'all_zero_fill')
 def test_ff(self):self.assertEqual(m.classify(bytes([255])*4096),'all_ff_fill')
 def test_mixed(self):self.assertEqual(m.classify(bytes(range(256))*16),'unresolved')
 def test_reject_size(self):
  with self.assertRaises(ValueError):m.audit(b'bad')
 def test_original(self):
  p=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
  if not p.exists():self.skipTest('Original ROM not available')
  result=m.audit(p.read_bytes());self.assertEqual(result['pages'],2048);self.assertTrue(result['matches_expected_rom'])
