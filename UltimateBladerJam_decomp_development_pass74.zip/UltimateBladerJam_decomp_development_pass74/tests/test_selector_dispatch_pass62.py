import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_selector_dispatch_pass62',ROOT/'tools/audit_selector_dispatch_pass62.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class SelectorDispatchPass62Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rom=ROM.read_bytes()
 def test_original_rom_passes(self):
  r=AUDIT.audit(self.rom); self.assertTrue(r['sha256_matches_expected_rom']); self.assertEqual(len(r['targets']),5)
 def test_selector_load_mutation_fails(self):
  b=bytearray(self.rom); b[0x08045A0E-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_case_setter_mutation_fails(self):
  b=bytearray(self.rom); b[0x08045A5A-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_jump_table_mutation_fails(self):
  b=bytearray(self.rom); b[0x08045A3C-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'word/table mismatch'): AUDIT.audit(b)
 def test_wrong_rom_size_rejected(self):
  with self.assertRaisesRegex(ValueError,'8 MiB'): AUDIT.audit(self.rom[:-1])
if __name__=='__main__': unittest.main()
