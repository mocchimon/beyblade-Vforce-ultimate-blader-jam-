import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_state_followup_pass64',ROOT/'tools/audit_state_followup_pass64.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class StateFollowupPass64Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rom=ROM.read_bytes()
 def test_original_rom_and_state_table(self):
  r=AUDIT.audit(self.rom); self.assertTrue(r['sha256_matches_expected_rom']); self.assertEqual(r['state_descriptor_table'],'0x08069FEC'); self.assertEqual(len(AUDIT.HALFWORDS),75)
 def test_prologue_mutation_rejected(self):
  b=bytearray(self.rom); b[0x080495C8-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_descriptor_lookup_mutation_rejected(self):
  b=bytearray(self.rom); b[0x080495E4-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_record_dispatch_mutation_rejected(self):
  b=bytearray(self.rom); b[0x08049622-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_literal_mutation_rejected(self):
  b=bytearray(self.rom); b[0x080495F0-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'literal mismatch'): AUDIT.audit(b)
if __name__=='__main__': unittest.main()
