import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('scan74',ROOT/'tools/scan_thumb_entry_candidates_pass74.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class CandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.data=ROM.read_bytes()
    def test_rom_identity(self): self.assertTrue(m.scan(self.data,0x1000)['matches_expected_rom'])
    def test_descriptor_thumb_pointer(self):
        result=m.scan(self.data,0x1000)
        self.assertIn(0x08043A0C,{e['target'] for e in result['entry_candidates']})
    def test_bl_forward(self): self.assertEqual(m.decode_bl(0x08001000,0xF000,0xF800),0x08001004)
    def test_bl_backward(self): self.assertEqual(m.decode_bl(0x08001000,0xF7FF,0xFFFE),0x08001000)
    def test_non_bl(self): self.assertIsNone(m.decode_bl(0x08001000,0xB500,0xF800))
    def test_bad_size(self):
        with self.assertRaises(ValueError):m.scan(b'bad')
    def test_bad_limit(self):
        with self.assertRaises(ValueError):m.scan(self.data,3)
