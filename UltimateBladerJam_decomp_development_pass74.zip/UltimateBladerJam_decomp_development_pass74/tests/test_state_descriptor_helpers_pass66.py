import importlib.util
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_state_descriptor_helpers_pass66', ROOT/'tools/audit_state_descriptor_helpers_pass66.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class StateDescriptorHelpersPass66Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.rom=ROM.read_bytes()
    def test_original_rom_and_helper_fingerprints(self):
        result=AUDIT.audit(self.rom); self.assertTrue(result['sha256_matches_expected_rom'])
        self.assertEqual(result['coordinate_state_writer'],'0x08049040')
        self.assertEqual(result['descriptor_stride_bytes'],24)
        self.assertGreaterEqual(len(AUDIT.HALFWORDS),35)
    def test_predicate_instruction_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08049008-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
    def test_coordinate_writer_mutation_rejected(self):
        data=bytearray(self.rom); data[0x0804905C-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
    def test_state_pointer_literal_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08049014-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'word mismatch'): AUDIT.audit(data)
    def test_adjacent_data_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08069FE8-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'word mismatch'): AUDIT.audit(data)
if __name__=='__main__': unittest.main()
