import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_parallel_selector_pass60', ROOT / 'tools/audit_parallel_selector_pass60.py')
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)
ROM_PATH = Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')

class ParallelSelectorPass60Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rom = ROM_PATH.read_bytes()

    def test_original_rom_passes(self):
        report = AUDIT.audit(self.rom)
        self.assertTrue(report['sha256_matches_expected_rom'])
        self.assertEqual(len(report['cases']), 5)

    def test_selector_dispatch_mutation_fails(self):
        data = bytearray(self.rom)
        data[0x08043C92 - AUDIT.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, 'instruction mismatch'):
            AUDIT.audit(data)

    def test_jump_table_mutation_fails(self):
        data = bytearray(self.rom)
        data[0x08043CC0 - AUDIT.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, 'word/literal mismatch'):
            AUDIT.audit(data)

    def test_case_argument_mutation_fails(self):
        data = bytearray(self.rom)
        data[0x08043CD4 - AUDIT.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, 'instruction mismatch'):
            AUDIT.audit(data)

    def test_wrong_rom_size_rejected(self):
        with self.assertRaisesRegex(ValueError, '8 MiB'):
            AUDIT.audit(self.rom[:-2])

if __name__ == '__main__':
    unittest.main()
