import importlib.util, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("rom_wide_coverage", ROOT / "tools/rom_wide_coverage.py")
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
class RomWideCoverageTests(unittest.TestCase):
    def test_wrong_rom_size_rejected(self):
        with self.assertRaisesRegex(ValueError, "expected"):
            mod.build_inventory(b"x", ROOT)
    def test_every_page_covers_entire_rom(self):
        import os
        with tempfile.TemporaryDirectory() as td:
            repo = Path(td); (repo / "src").mkdir(); (repo / "src/a.c").write_text("void f(void) { /* 0x08001234 */ }\n")
            report = mod.build_inventory(bytes(mod.ROM_SIZE), repo)
        self.assertEqual(report["page_count"], 2048)
        self.assertEqual(sum(p["size_bytes"] for p in report["pages"]), mod.ROM_SIZE)
        self.assertEqual(report["unique_rom_address_values_mentioned"], 1)
        self.assertEqual(report["pages"][1]["status"], "referenced-in-repository")
    def test_reference_scan_does_not_count_out_of_range(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            repo=Path(td); (repo/"src").mkdir(); (repo/"src/x.c").write_text("0x02000000 0x08800000 0x08000000")
            report=mod.build_inventory(bytes(mod.ROM_SIZE),repo)
        self.assertEqual(report["unique_rom_address_values_mentioned"],1)
    def test_report_warns_not_true_decomp_coverage(self):
        self.assertIn("not decompilation coverage", mod.build_inventory(bytes(mod.ROM_SIZE), ROOT)["coverage_warning"])
if __name__ == "__main__": unittest.main()
