import importlib.util,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pass68',ROOT/'tools/audit_state_adjustment_pass68.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class AdjustmentTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.rom=ROM.read_bytes()
 def test_original(self):self.assertTrue(mod.audit(self.rom)['sha256_matches_expected_rom'])
 def test_zero(self):self.assertEqual(mod.adjustment(0),0)
 def test_small_deltas(self):
  for n in (1,255,256,257,512):
   self.assertEqual(mod.adjustment(n),1);self.assertEqual(mod.adjustment(-n),-1)
 def test_thresholds(self):
  self.assertEqual(mod.adjustment(32768),64);self.assertEqual(mod.adjustment(32769),128);self.assertEqual(mod.adjustment(-32769),-128)
 def test_instruction_mutation(self):
  data=bytearray(self.rom);data[0x491f4]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'):mod.audit(data)
 def test_literal_mutation(self):
  data=bytearray(self.rom);data[0x49014]^=1
  with self.assertRaisesRegex(ValueError,'literal mismatch'):mod.audit(data)
