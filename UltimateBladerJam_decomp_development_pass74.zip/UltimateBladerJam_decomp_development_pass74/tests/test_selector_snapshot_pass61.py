import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_selector_snapshot_pass61',ROOT/'tools/audit_selector_snapshot_pass61.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class SelectorSnapshotPass61Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rom=ROM.read_bytes()
 def test_original_rom_passes(self):
  r=AUDIT.audit(self.rom); self.assertTrue(r['sha256_matches_expected_rom']); self.assertEqual(len(r['snapshots']),2)
 def test_first_snapshot_mutation_fails(self):
  b=bytearray(self.rom); b[0x0804853C-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_second_snapshot_mutation_fails(self):
  b=bytearray(self.rom); b[0x080488B8-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(b)
 def test_dispatch_table_mutation_fails(self):
  b=bytearray(self.rom); b[0x08048980-AUDIT.ROM_BASE]^=1
  with self.assertRaisesRegex(ValueError,'word/literal mismatch'): AUDIT.audit(b)
 def test_wrong_rom_size_rejected(self):
  with self.assertRaisesRegex(ValueError,'8 MiB'): AUDIT.audit(self.rom[:-1])
if __name__=='__main__': unittest.main()
