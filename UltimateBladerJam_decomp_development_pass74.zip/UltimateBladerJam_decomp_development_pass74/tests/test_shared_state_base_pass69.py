import importlib.util, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit69',ROOT/'tools/audit_shared_state_base_pass69.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')
class StateBaseAuditTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=ROM.read_bytes()
 def test_original(self):self.assertTrue(mod.audit(self.data)['original_rom_sha256_matches'])
 def test_reference_count(self):self.assertEqual(len(mod.audit(self.data)['literal_references']),10)
 def test_literal_corruption(self):
  data=bytearray(self.data);data[0x49948]^=1
  with self.assertRaisesRegex(ValueError,'literal mismatch'):mod.audit(data)
 def test_predicate_corruption(self):
  data=bytearray(self.data);data[0x49004]^=1
  with self.assertRaisesRegex(ValueError,'predicate mismatch'):mod.audit(data)
 def test_field_corruption(self):
  data=bytearray(self.data);data[0x4905c]^=1
  with self.assertRaisesRegex(ValueError,'field read mismatch'):mod.audit(data)
