import importlib.util
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('audit_state_descriptor_records_pass65', ROOT/'tools/audit_state_descriptor_records_pass65.py')
AUDIT=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(AUDIT)
ROM=Path('/mnt/data/Beyblade V-Force - Ultimate Blader # GBA(2).GBA')

class StateDescriptorRecordsPass65Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.rom=ROM.read_bytes()
    def test_original_rom_and_descriptor_table(self):
        result=AUDIT.audit(self.rom)
        self.assertTrue(result['sha256_matches_expected_rom'])
        self.assertEqual(result['descriptor_stride_bytes'],24)
        self.assertEqual(result['descriptor_table'],'0x08069FEC')
        self.assertGreaterEqual(len(AUDIT.HALFWORDS),100)
    def test_followup_instruction_mutation_rejected(self):
        data=bytearray(self.rom); data[0x080495E4-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
    def test_builder_a_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08050508-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
    def test_builder_b_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08050550-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'instruction mismatch'): AUDIT.audit(data)
    def test_descriptor_table_mutation_rejected(self):
        data=bytearray(self.rom); data[0x08069FF0-AUDIT.ROM_BASE]^=1
        with self.assertRaisesRegex(ValueError,'word mismatch'): AUDIT.audit(data)

if __name__=='__main__': unittest.main()
