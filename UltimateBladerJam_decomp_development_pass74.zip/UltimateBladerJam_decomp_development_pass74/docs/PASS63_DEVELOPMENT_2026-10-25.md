# Pass 63 — context selection history and restore

## Why this pass

The selector consumers traced in Passes 59–62 call `0x080490FC` with small numeric arguments. Rather than assign meaning to those values prematurely, this pass inspects that helper and its nearby companion at `0x0804917C`.

## Verified behavior

The routine at `0x080490FC` reads the state block pointer `0x03000650`. It compares the requested state argument (`r0`) against the words at state-block offsets `+0` and `+4`; if either matches, it exits without performing the update sequence. Otherwise it:

- tests whether the word at offset `+0` equals `0xFFFFFFFF`; if it does, the setup calls are skipped. Otherwise it calls `0x08049348(3)` and `0x080490D0(3, 1)`, then sets byte `0x03000BFC` to `1`;
- uses the byte at state-block `+0x7C` as a bounded history count, with saved entries beginning at `+0x14` and spaced four bytes apart;
- saves the word at `+4` in the history array when the counter is at most 14, increments the counter, shifts the word at `+0` into `+8`, stores the requested state at `+4`, and calls `0x080495C8`.

The companion at `0x0804917C` checks the same history count. If nonzero, it calls the same setup helpers, sets the same byte flag, decrements the count, loads a saved word from `+0x14 + index*4` into `+4`, copies `+0` to `+8`, then calls `0x080495C8`. With a zero count it skips the restore mutation and reaches the shared final call.

## Interpretation limits

This is evidence for a small state-selection/history mechanism, not a verified name for the original subsystem. State IDs supplied by the dispatchers remain numeric; the meaning of `0x03000BFC`, and whether any of this relates to hidden content, is not yet known. No Easter egg is established.

## Validation

`tools/audit_context_history_pass63.py` checks 70+ Thumb halfwords and the four literal words for the two routines against the original 8 MiB ROM. `tests/test_context_history_pass63.py` contains five tests, including mutations of both routines and the global-pointer literal. Run:

```sh
make audit-context-history-pass63 ROM=/path/to/original.gba
make test-context-history-pass63
```
