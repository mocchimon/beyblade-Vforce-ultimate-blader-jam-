# Pass 60 — parallel context selector dispatch

## Verified finding

The ROM contains a second five-way dispatch at `0x08043C8C` that reads the word at `[r6 + 0x4B4]`, rejects selector values greater than four, and jumps through a five-entry table at `0x08043CBC`. This is the same field offset read by the Pass 59 dispatcher at `0x08045A08`, but its case actions differ.

| Selector | Target | Value passed to `0x08063AA0` |
|---:|---:|---:|
| 0 | `0x08043CD0` | 0 |
| 1 | `0x08043CD4` | 3 |
| 2 | `0x08043CD8` | 4 |
| 3 | `0x08043CDC` | 5 |
| 4 | `0x08043CE0` | 7 |

All five branches converge on the call at `0x08043CE4`; after that call the routine stores `0x20` to the global word at `0x03000168`. The call target is the known helper at `0x08063AA0`, previously mapped as storing its 32-bit argument at `0x03005E98`.

## Interpretation boundary

This cross-reference shows that `+0x4B4` participates in at least two separate five-way dispatch sites with different downstream actions. That makes a single semantic label for selector values premature. This pass does not identify the upstream writer of `+0x4B4`, and does not establish any Easter egg.

## Validation

`tools/audit_parallel_selector_pass60.py` checks the ROM identity, dispatch instructions, offset/table literals, five jump-table targets, case values, and common action. Five tests cover success and mutation/failure cases.
