# Pass 62 — another consumer of selector offset `+0x4B4`

## Verified path

Routine `0x08045A00` loads the word at `[r6 + 0x4B4]`, rejects values greater than 4, and dispatches through the table at `0x08045A34`. The table order is `0x08045A48`, `0x08045A5A`, `0x08045A56`, `0x08045A70`, `0x08045A68`.

Case 0 calls the runtime field setter with `1` and then calls `0x080490FC` with `0x19`. Case 1 sets the field to `4` and calls `0x080490FC` with `0x0F`. Case 2 sets the field to `1` and calls the same helper with `0x0F`. Case 3 calls it with `0x0C`, and case 4 calls it with `0x28`; those two case blocks do not show a setter call.

## Interpretation limits

This confirms another consumer of selector offset `+0x4B4`, and corroborates that selector branches have differing side effects. It does **not** identify the upstream writer or justify semantic names for the selector or numeric arguments. To identify the writer, the next analysis needs a complete code-reference search for stores to a pointer derived from the context base plus `0x4B4`, including callers that may pass a different base register. No Easter egg is established.

## Validation

`tools/audit_selector_dispatch_pass62.py` verifies the 8 MiB ROM fingerprint, instruction halfwords, selector-offset literal, and five jump-table entries. The test suite mutates representative instructions and table entries to ensure mismatches are rejected.
