# Pass 61 — selector snapshot cross-references

## Verified findings

Two additional code paths read the word at offset `+0x4B4` and copy its low byte into another record:

- `0x08048536`: reads `[r6 + 0x4B4]`, then `STRB` to `[r7 + 4]` at `0x0804853C`.
- `0x080488B2`: reads `[r7 + 0x4B4]`, then `STRB` to `[r6 + 4]` at `0x080488B8`.

A third consumer at `0x08048956` reads the same offset, rejects values above four, and dispatches through the five-entry table at `0x08048974`.

## Interpretation limits

These are reads/snapshots, not writes to `+0x4B4`. This pass did **not** find the upstream writer, so the selector's semantics remain unresolved. The copied byte suggests the value is preserved in a downstream record, but that alone does not establish what the record represents. No Easter egg is confirmed.

## Validation

`tools/audit_selector_snapshot_pass61.py` checks the original ROM identity, instruction fingerprints at both snapshot sites and the third dispatch, plus the five-entry jump table. Five tests cover positive verification and mutations.
