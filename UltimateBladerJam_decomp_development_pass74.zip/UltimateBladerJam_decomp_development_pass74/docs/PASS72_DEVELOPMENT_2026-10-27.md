# Pass 72 — ROM-wide inventory baseline

## Direction change

The project priority is now full-ROM reconstruction for a close 1:1 recreation, rather than chasing the title/pause Easter egg in isolation. The secret-input work remains useful only as one small subsystem within the whole-ROM map.

## Inventory baseline

The input ROM is 8 MiB, SHA-256 `a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce`, mapped at `0x08000000..0x08800000`. `tools/rom_wide_coverage.py` divides the entire ROM into 2,048 pages of 4 KiB, reports byte statistics for every page, and counts explicit ROM-address references found in project sources and notes.

Current baseline generated in `docs/rom_wide_inventory_pass72.json`:

- 2,048 pages cover all 8,388,608 bytes.
- 1,463 unique ROM address values are explicitly mentioned in repository text.
- 224 implementation/evidence files contain at least one ROM address mention.
- The original ROM hash matches the expected input.

**Important limitation:** these numbers measure inventory/reference density, not decompilation coverage. An address mention does not mean its instructions are reconstructed, and a page without explicit address references is not necessarily unknown. The JSON report makes that limitation explicit.

## Full-ROM workflow from here

1. Establish a reproducible ROM map: code, literal pools, pointer tables, compressed resources, graphics, audio, and padding, with confidence and evidence recorded per range.
2. Build a function/call/reference graph, distinguishing proven Thumb entry points from pointer-like values and inline data.
3. Convert recovered code clusters to C/assembly with ROM-backed instruction fingerprints and tests; avoid inventing semantic names.
4. Recover resource/data formats and cross-reference their runtime consumers.
5. Track byte/range status as `unclassified`, `candidate-code`, `confirmed-code`, `candidate-data`, `confirmed-data`, or `reconstructed`, including evidence and confidence.
6. Compare any rebuilt image byte-for-byte when feasible, but never treat byte equality alone as proof of semantic reconstruction.

The next passes should focus on ROM region classification and function boundary/call graph coverage across the full address space, not isolated Easter-egg hunting. The title/pause candidate remains a hypothesis pending caller and input-sequence confirmation.
