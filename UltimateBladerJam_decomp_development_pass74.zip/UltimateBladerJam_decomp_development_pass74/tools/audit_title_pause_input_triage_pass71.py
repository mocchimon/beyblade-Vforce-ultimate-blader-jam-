#!/usr/bin/env python3
"""ROM-backed triage for menu-like input branches around 0x08043D20."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE = 0x08000000
EXPECTED_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
# Fingerprint the contiguous input branch block; these are ROM halfwords, not
# a claim that every nearby byte is independently a function boundary.
START = 0x08043D42
HALFWORDS = (
    0x2008, 0xF005, 0xFA78, 0x2001, 0xF00D, 0xFD2B, 0x2800, 0xD003,
    0x2012, 0xF005, 0xFA7C, 0xE011, 0x2080, 0x0040, 0xF00D, 0xFD21,
    0x2800, 0xD003, 0x2011, 0xF005, 0xFA72, 0xE007, 0x2004, 0xF00D,
    0xFD18, 0x2800, 0xD002, 0x2013, 0xF005, 0xFA69, 0x2009, 0xF005,
    0xF9BC,
)
def audit(rom):
    if len(rom) != 0x800000:
        raise ValueError("expected the 8 MiB reference ROM")
    off = START - ROM_BASE
    actual = struct.unpack_from('<' + 'H' * len(HALFWORDS), rom, off)
    if actual != HALFWORDS:
        i = next(i for i,(a,b) in enumerate(zip(actual, HALFWORDS)) if a != b)
        raise ValueError(f"instruction mismatch at {START + 2*i:#010x}")
    digest = hashlib.sha256(rom).hexdigest()
    return {
      "pass": 71, "rom_sha256": digest, "matches_reference_rom": digest == EXPECTED_SHA256,
      "fingerprint_start": f"0x{START:08X}", "verified_halfwords": len(HALFWORDS),
      "observed_input_masks": [
        {"call_site":"0x08043D4A", "mask":1, "meaning":"lowest input bit; button identity not assigned here"},
        {"call_site":"0x08043D5E", "mask":256, "meaning":"bit 8 in the game's input mask"},
        {"call_site":"0x08043D70", "mask":4, "meaning":"bit 2 in the game's input mask"}],
      "conditional_arguments_to_08049250": ["0x12", "0x11", "0x13"],
      "state_history_calls": [{"site":"0x08043D28","argument":"0x0A"},{"site":"0x08043D80","argument":"0x09"}],
      "interpretation": "This is a high-value menu/UI input candidate: three separate input masks lead to distinct arguments passed to 0x08049250, and other branches call 0x080490FC with 0x0A or 0x09. The supplied clue says the secret is activated from title-screen or pause-menu inputs; this region is prioritized for caller/context tracing, but title-versus-pause identity and any secret sequence are not yet proven.",
      "limitations": ["Mask bits are recorded numerically; button names depend on the game's input mapping.", "The 47 candidates in the older whole-ROM scan include BL-shaped data and must not all be treated as executed calls.", "No secret sequence or Easter egg trigger is confirmed by this fingerprint alone."]
    }
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
    result=audit(a.rom.read_bytes())
    print(f"PASS: title/pause input triage fingerprint ({result['verified_halfwords']} halfwords)")
    print("  masks 1, 0x100, 4; candidate arguments 0x12, 0x11, 0x13")
    print("  screen context and secret sequence remain unconfirmed")
    if a.json:
        a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(result,indent=2)+'\\n')
if __name__=='__main__': main()
