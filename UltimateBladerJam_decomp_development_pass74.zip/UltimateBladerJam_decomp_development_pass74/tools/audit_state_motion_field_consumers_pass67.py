#!/usr/bin/env python3
"""ROM-backed audit of state motion fields and their observed consumers."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE = 0x08000000
ROM_SHA256 = 'a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce'
# Include the target-setting helper, its immediate consumer, zero initializer, and call sites.
HALFWORDS = {
    0x0804901C:0x4B06, 0x0804901E:0x1C1A, 0x08049020:0x3284,
    0x08049022:0x1C18, 0x08049024:0x3088, 0x08049026:0x4905,
    0x08049028:0x6001, 0x0804902A:0x6011, 0x0804902C:0x3208,
    0x0804902E:0x3008, 0x08049030:0x6001, 0x08049032:0x6011,
    0x08049034:0x4770,
    0x08049078:0xB570, 0x0804907A:0x1C06, 0x0804907C:0x4C13,
    0x08049080:0x308C, 0x08049082:0x1C25, 0x08049084:0x3584,
    0x08049086:0x6800, 0x08049088:0x6829, 0x0804908A:0x1A40,
    0x0804908C:0x2180, 0x0804908E:0xF000, 0x08049090:0xF8A9,
    0x08049092:0x0140, 0x08049094:0x6829, 0x08049096:0x1809,
    0x08049098:0x6029, 0x0804909A:0x1C20, 0x0804909C:0x3090,
    0x0804909E:0x3488, 0x080490A0:0x6800, 0x080490A2:0x6821,
    0x080490A4:0x1A40, 0x080490A6:0x2180, 0x080490A8:0xF000,
    0x080490AA:0xF89C, 0x080490AC:0x0140, 0x080490AE:0x6822,
    0x080490B0:0x1812, 0x080490B2:0x6022, 0x080490B4:0x6828,
    0x080490B6:0x1200, 0x080490B8:0x1C31, 0x080490BA:0x3148,
    0x080490BC:0x8008, 0x080490BE:0x1212, 0x080490C0:0x364A,
    0x080490C2:0x8032, 0x080490C4:0xBC70, 0x080490C6:0xBC01,
    0x080490C8:0x4700,
    0x08049460:0xF7FF, 0x08049462:0xFDDC,
    0x08049654:0xF7FF, 0x08049656:0xFCD4,
    0x0804966A:0xF7FF, 0x0804966C:0xFCE9,
}
WORDS = {0x08049038:0x03000650, 0x08049074:0x03000650, 0x080490CC:0x03000650,
         0x08049678:0x03000650}
def u16(rom, a): return struct.unpack_from('<H', rom, a-ROM_BASE)[0]
def u32(rom, a): return struct.unpack_from('<I', rom, a-ROM_BASE)[0]
def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for a,v in HALFWORDS.items():
        if u16(rom,a) != v: raise ValueError(f'instruction mismatch at {a:#010x}')
    for a,v in WORDS.items():
        if u32(rom,a) != v: raise ValueError(f'word mismatch at {a:#010x}')
    digest=hashlib.sha256(rom).hexdigest()
    return {'pass':67,'rom_size':len(rom),'rom_sha256':digest,'expected_original_rom_sha256':ROM_SHA256,
      'motion_state_base':'0x03000650','current_fields':['0x030006D4 (+0x84)','0x030006D8 (+0x88)'],
      'target_fields':['0x030006DC (+0x8C)','0x030006E0 (+0x90)'],
      'observations':[
       'At 0x08049040, arguments r1/r2 are shifted left by eight into state +0x8C/+0x90; signed halfwords from the source record +0x48/+0x4A are shifted left by eight into state +0x84/+0x88.',
       'The routine beginning at 0x08049078 reads target fields +0x8C/+0x90 and current fields +0x84/+0x88, subtracts current from target, calls 0x080491E4 with scale argument 0x80, shifts the returned adjustment left by five, and adds it to the current value.',
       'That consumer then arithmetic-shifts the updated current values right by eight and stores low halfwords back to source record +0x48/+0x4A. This is evidence of a smoothed/interpolated pair of signed record coordinates, likely spatial or animation coordinates; exact meaning is not proven.',
       'The helper at 0x0804901C clears all four state fields at offsets +0x84/+0x88/+0x8C/+0x90. A caller at 0x08049460 invokes this reset helper.',
       'The follow-up routine at 0x080495C8 calls the bit predicate at 0x08049000 and, when true, calls the writer at 0x08049040 with source values from the optional descriptor object. The flag meaning remains unknown.',
       'Static direct-call scan finds the predicate called at 0x08049654 and the field writer at 0x0804966A; other uses may be indirect and are not inferred from this scan.',
       'No write to the pointed-to structure halfword bit 0 at pointer +0xEC has been attributed confidently yet; the pointer is loaded from 0x03000BEC.',
       'No Easter egg trigger is established by this field flow.'
      ], 'sha256_matches_expected_rom':digest==ROM_SHA256}
def main():
 p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args(); result=audit(a.rom.read_bytes())
 print(f"PASS: motion-field consumer fingerprints verified ({len(HALFWORDS)} halfwords, {len(WORDS)} words)")
 print('  current/target fields form a smoothed coordinate-like flow; exact semantics remain provisional')
 if a.json: a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__': main()
