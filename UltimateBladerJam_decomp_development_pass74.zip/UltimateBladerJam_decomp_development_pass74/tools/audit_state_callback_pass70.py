#!/usr/bin/env python3
"""Pass 70 ROM-backed audit: state-indexed callback caller and video-register helper."""
import struct,hashlib,argparse,json
from pathlib import Path
BASE=0
SHA="a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
HALFWORDS={301308: 46384, 301310: 19474, 301312: 7200, 301314: 61446, 301316: 65505, 301318: 19729, 301320: 18449, 301322: 6180, 301324: 26656, 301326: 26625, 301328: 328, 301330: 6208, 301332: 128, 301334: 7209, 301336: 12664, 301338: 6208, 301340: 26624, 301342: 10240, 301344: 53249, 301346: 61454, 301348: 63649, 301350: 26656, 301352: 26625, 301354: 328, 301356: 6208, 301358: 128, 301360: 7209, 301362: 12668, 301364: 6208, 301366: 26624, 301368: 10240, 301370: 53249, 301372: 61454, 301374: 63650, 301376: 48176, 301378: 48129, 301380: 18176, 329928: 18951, 329930: 30721, 329932: 28689, 329934: 18951, 329936: 30785, 329938: 28689, 329940: 8832, 329942: 1234, 329944: 35011, 329946: 537, 329948: 35075, 329950: 17177, 329952: 32785, 329954: 8448, 329956: 32897, 329958: 18288}
WORDS={301384: 50334688, 301388: 134654028, 301392: 4294966052, 329960: 50335200, 329964: 50335292}
def audit(data):
    if len(data)!=0x800000: raise ValueError('expected 8 MiB ROM')
    for addr,v in HALFWORDS.items():
        if struct.unpack_from('<H',data,addr-BASE)[0]!=v: raise ValueError(f'instruction mismatch {addr:#x}')
    for addr,v in WORDS.items():
        if struct.unpack_from('<I',data,addr-BASE)[0]!=v: raise ValueError(f'literal mismatch {addr:#x}')
    digest=hashlib.sha256(data).hexdigest()
    return {'pass':70,'sha256':digest,'original_rom_sha256_matches':digest==SHA,'instruction_halfwords':len(HALFWORDS),'literal_words':len(WORDS),'state_callback_caller':'0x080498FC','video_helper':'0x080508C8','pointer_flag_writer':'unresolved'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('rom',type=Path);ap.add_argument('--json',type=Path);a=ap.parse_args();r=audit(a.rom.read_bytes())
    if a.json:a.json.write_text(json.dumps(r,indent=2)+'\n')
    print('PASS: Pass 70 caller/helper ROM fingerprints verified')
if __name__=='__main__':main()
