#!/usr/bin/env python3
"""Audit the second five-way selector dispatch at ROM 0x08043C8C."""
import argparse
import hashlib
import json
import struct
from pathlib import Path

ROM_BASE = 0x08000000
ROM_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
INSTRUCTIONS = {
    0x08043C8C: 0x4909, 0x08043C8E: 0x1870, 0x08043C90: 0x6800,
    0x08043C92: 0x2804, 0x08043C94: 0xD825, 0x08043C96: 0x0080,
    0x08043C98: 0x4907, 0x08043C9A: 0x1840, 0x08043C9C: 0x6800,
    0x08043C9E: 0x4687,
    0x08043CD0: 0x2400, 0x08043CD2: 0xE006,
    0x08043CD4: 0x2403, 0x08043CD6: 0xE004,
    0x08043CD8: 0x2404, 0x08043CDA: 0xE002,
    0x08043CDC: 0x2405, 0x08043CDE: 0xE000,
    0x08043CE0: 0x2407, 0x08043CE2: 0x1C20,
    0x08043CE8: 0x4903, 0x08043CEA: 0x2020, 0x08043CEC: 0x6008,
}
WORDS = {
    0x08043CB4: 0x000004B4,
    0x08043CB8: 0x08043CBC,
    0x08043CBC: 0x08043CD0,
    0x08043CC0: 0x08043CD4,
    0x08043CC4: 0x08043CD8,
    0x08043CC8: 0x08043CDC,
    0x08043CCC: 0x08043CE0,
    0x08043CF8: 0x03000168,
}


def u16(rom, address):
    return struct.unpack_from('<H', rom, address - ROM_BASE)[0]


def u32(rom, address):
    return struct.unpack_from('<I', rom, address - ROM_BASE)[0]


def audit(rom):
    if len(rom) != 0x800000:
        raise ValueError('expected the 8 MiB original GBA ROM')
    for address, expected in INSTRUCTIONS.items():
        if u16(rom, address) != expected:
            raise ValueError(f'instruction mismatch at {address:#010x}')
    for address, expected in WORDS.items():
        if u32(rom, address) != expected:
            raise ValueError(f'word/literal mismatch at {address:#010x}')
    digest = hashlib.sha256(rom).hexdigest()
    cases = [
        {'selector': 0, 'target': '0x08043CD0', 'argument_to_08063AA0': 0},
        {'selector': 1, 'target': '0x08043CD4', 'argument_to_08063AA0': 3},
        {'selector': 2, 'target': '0x08043CD8', 'argument_to_08063AA0': 4},
        {'selector': 3, 'target': '0x08043CDC', 'argument_to_08063AA0': 5},
        {'selector': 4, 'target': '0x08043CE0', 'argument_to_08063AA0': 7},
    ]
    return {
        'rom_size': len(rom), 'rom_sha256': digest,
        'expected_original_rom_sha256': ROM_SHA256,
        'dispatch_entry': '0x08043C8C', 'selector_offset': '0x4B4',
        'bounds_check': 'selector > 4 branches to 0x08043CE2',
        'jump_table_base': '0x08043CBC', 'cases': cases,
        'common_action': 'passes selected argument to 0x08063AA0, then stores 0x20 to RAM word 0x03000168',
        'comparison': 'A second dispatch reads the same context offset +0x4B4 as 0x08045A08 but maps selector values to different arguments (0,3,4,5,7).',
        'interpretation_limit': 'Selector semantic names and relationship to Easter eggs are not established.',
        'sha256_matches_expected_rom': digest == ROM_SHA256,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', type=Path)
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    report = audit(args.rom.read_bytes())
    print('PASS: parallel five-way selector dispatch, table, case arguments and common action verified')
    print('  same selector offset (+0x4B4) as 0x08045A08; semantic labels remain unresolved')
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2) + '\n')

if __name__ == '__main__':
    main()
