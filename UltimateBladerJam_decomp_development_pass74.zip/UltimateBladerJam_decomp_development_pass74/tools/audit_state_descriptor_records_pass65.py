#!/usr/bin/env python3
"""ROM-backed audit of state descriptor records and fixed-point point builders."""
import argparse
import hashlib
import json
import struct
from pathlib import Path

ROM_BASE = 0x08000000
ROM_SHA256 = 'a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce'

# State follow-up descriptor selection and gating at 0x080495C8.
HALFWORDS = {
    0x080495C8:0xB570, 0x080495CA:0xB081, 0x080495CC:0x4908,
    0x080495D0:0x30B4, 0x080495D2:0x6800, 0x080495D4:0x6842,
    0x080495D6:0x6849, 0x080495D8:0x2001, 0x080495DA:0x4240,
    0x080495DC:0x4281, 0x080495DE:0xD00B, 0x080495E0:0x0048,
    0x080495E2:0x1840, 0x080495E4:0x00C0, 0x080495E6:0x4903,
    0x080495E8:0x1840, 0x080495EA:0x6846, 0x080495F8:0x2600,
    0x08049600:0x2100, 0x08049602:0x5E40, 0x08049604:0x2800,
    0x08049606:0xD01C, 0x08049608:0x6910, 0x0804960A:0x6A85,
    0x0804960C:0x2D00, 0x0804960E:0xD018, 0x08049610:0x208B,
    0x08049616:0x6829, 0x08049618:0x686A, 0x0804961A:0x68AB,
    0x0804961C:0x68E8, 0x0804961E:0x9000, 0x08049620:0x1C20,
    0x08049622:0xF006, 0x08049624:0xFF61, 0x08049626:0x6929,
    0x08049628:0x696A, 0x0804962A:0x69AB, 0x0804962C:0x69E8,
    0x0804962E:0x9000, 0x08049630:0x1C20, 0x08049632:0xF006,
    0x08049634:0xFF7D, 0x08049636:0x6A29, 0x08049638:0x2026,
    0x0804963A:0x5E2A, 0x0804963C:0x1C20, 0x0804963E:0xF006,
    0x08049640:0xFF9D, 0x08049642:0x4C0D, 0x08049644:0x1C20,
    0x08049646:0xF7F9, 0x08049648:0xFF87, 0x0804964A:0x2E00,
    0x0804964C:0xD00F, 0x0804964E:0x6A70, 0x08049650:0x2800,
    0x08049652:0xD00C, 0x08049654:0xF7FF, 0x08049656:0xFCD4,
    0x08049658:0x0600, 0x0804965A:0x2800, 0x0804965C:0xD007,
    0x0804965E:0x21A0, 0x08049660:0x0049, 0x08049662:0x1860,
    0x08049664:0x6A72, 0x08049666:0x6811, 0x08049668:0x6852,
    0x0804966A:0xF7FF, 0x0804966C:0xFCE9, 0x0804966E:0xB001,
    0x08049670:0xBC70, 0x08049672:0xBC01, 0x08049674:0x4700,
    # Fixed-point builder A: coordinate-like fields at +0x10/+0x14.
    0x080504E8:0xB5F0, 0x080504EA:0x4647, 0x080504EC:0xB480,
    0x080504EE:0x1C04, 0x080504F6:0x2380, 0x080504F8:0x005B,
    0x080504FC:0x68A1, 0x080504FE:0x2200, 0x08050502:0x4660,
    0x08050504:0x4368, 0x08050506:0x1200, 0x08050508:0x6108,
    0x0805050A:0x4640, 0x0805050C:0x4358, 0x0805050E:0x1200,
    0x08050510:0x6148, 0x08050512:0x19AD, 0x08050516:0x181B,
    0x08050518:0x3118, 0x0805051A:0x3201, 0x0805051C:0x270C,
    0x0805051E:0x5FE0, 0x08050520:0x4282, 0x08050522:0xDBEE,
    # Fixed-point builder B: corresponding fields at +0x08/+0x0C.
    0x08050530:0xB5F0, 0x08050532:0x4647, 0x08050534:0xB480,
    0x08050536:0x1C04, 0x0805053E:0x2380, 0x08050540:0x005B,
    0x08050544:0x68A1, 0x08050546:0x2200, 0x0805054A:0x4660,
    0x0805054C:0x4368, 0x0805054E:0x1200, 0x08050550:0x6088,
    0x08050552:0x4640, 0x08050554:0x4358, 0x08050556:0x1200,
    0x08050558:0x60C8, 0x0805055A:0x19AD, 0x0805055E:0x181B,
    0x08050560:0x3118, 0x08050562:0x3201, 0x08050564:0x270C,
    0x08050566:0x5FE0, 0x08050568:0x4282, 0x0805056A:0xDBEE,
    # Small record field writers.
    0x08050578:0x81C1, 0x0805057A:0x4770,
    0x0805057C:0x6101, 0x0805057E:0x0412, 0x08050580:0x1412,
    0x08050582:0x6142, 0x08050584:0x4770,
}
WORDS = {
    0x080495F0:0x03000650, 0x080495F4:0x08069FEC,
    0x08049678:0x03000650, 0x0804967C:0x00000464,
}
# The first six words of the table establish 0x18-byte records and their
# pointer/callback-shaped fields without claiming semantic names.
TABLE_WORDS = {
    0x08069FEC:0x00000000, 0x08069FF0:0x08069FC4,
    0x08069FF4:0x08043A0D, 0x08069FF8:0x08049A89,
    0x08069FFC:0x08049CED, 0x0806A000:0x08049DE5,
    0x0806A004:0x00000011, 0x0806A008:0x08069FC4,
    0x0806A00C:0x08043A0D, 0x0806A010:0x08049AFD,
}

def u16(data, address): return struct.unpack_from('<H', data, address-ROM_BASE)[0]
def u32(data, address): return struct.unpack_from('<I', data, address-ROM_BASE)[0]

def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for address, expected in HALFWORDS.items():
        if u16(rom, address) != expected: raise ValueError(f'instruction mismatch at {address:#010x}')
    for address, expected in {**WORDS, **TABLE_WORDS}.items():
        if u32(rom, address) != expected: raise ValueError(f'word mismatch at {address:#010x}')
    digest = hashlib.sha256(rom).hexdigest()
    return {
      'pass':65, 'rom_size':len(rom), 'rom_sha256':digest,
      'expected_original_rom_sha256':ROM_SHA256,
      'state_followup':'0x080495C8', 'descriptor_table':'0x08069FEC',
      'descriptor_stride_bytes':24, 'state_block_base':'0x03000650',
      'record_builder_a':'0x080504E8', 'record_builder_b':'0x08050530',
      'record_scalar_writer':'0x0805057C',
      'observations':[
        'the follow-up reads a state index from the word at 0x03000654; 0xFFFFFFFF takes a no-descriptor path',
        'for other indices it computes 0x08069FEC + index*0x18 and loads the word at descriptor +4',
        'the descriptor table contains 0x18-byte records with code-pointer-shaped words; record meanings are not yet identified',
        'a signed halfword at 0x03000AB4 gates the record-processing path',
        'when the pointer chain is non-null, the routine forwards groups of four words at record offsets 0x00 and 0x10 to builders at 0x080504E8 and 0x08050530, then forwards a word and halfword at offsets 0x20 and 0x26 to 0x0805057C',
        'builder 0x080504E8 loops using a signed halfword count at argument-object +0x0C, emits entries at output stride 0x18, and writes two scaled/interpolated values to output offsets +0x10 and +0x14',
        'builder 0x08050530 uses the same count and stride, writing the corresponding values at output offsets +0x08 and +0x0C',
        '0x0805057C writes a word at destination +0x10 and a sign-extended halfword at destination +0x14',
        'the scale arithmetic uses an initial fixed-point term of 0x100 and arithmetic right shift by eight; the exact coordinate units and domain semantics remain unresolved',
        'the routine also calls 0x08043558 and conditionally invokes 0x08049000 / 0x08049040; their semantic roles remain unresolved',
      ],
      'sha256_matches_expected_rom':digest==ROM_SHA256,
    }

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom',type=Path); parser.add_argument('--json',type=Path)
    args=parser.parse_args(); result=audit(args.rom.read_bytes())
    print(f"PASS: descriptor/record fingerprints verified ({len(HALFWORDS)} halfwords, {len(WORDS)+len(TABLE_WORDS)} words)")
    print('  descriptor/coordinate semantics remain provisional; no Easter egg inferred')
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True)
        args.json.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__': main()
