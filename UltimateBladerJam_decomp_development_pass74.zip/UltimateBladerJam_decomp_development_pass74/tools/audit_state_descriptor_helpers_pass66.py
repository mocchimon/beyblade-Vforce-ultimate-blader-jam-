#!/usr/bin/env python3
"""ROM-backed fingerprints for descriptor follow-up helpers and adjacent data."""
import argparse
import hashlib
import json
import struct
from pathlib import Path

ROM_BASE = 0x08000000
ROM_SHA256 = 'a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce'

# Thumb halfwords: predicate helper at 0x08049000 and state-coordinate copier at 0x08049040.
HALFWORDS = {
    0x08049000:0x4804, 0x08049002:0x68C1, 0x08049004:0x31EC,
    0x08049006:0x2001, 0x08049008:0x8809, 0x0804900A:0x4008,
    0x0804900C:0x2800, 0x0804900E:0xD103, 0x08049010:0x2000,
    0x08049012:0xE002, 0x08049018:0x2001, 0x0804901A:0x4770,
    0x0804901C:0x4B06, 0x0804901E:0x1C1A,
    0x08049040:0x4B0C, 0x08049042:0x469C, 0x08049044:0x338C,
    0x08049046:0x0209, 0x08049048:0x6019, 0x0804904A:0x4661,
    0x0804904C:0x3190, 0x0804904E:0x0212, 0x08049050:0x600A,
    0x08049052:0x4662, 0x08049054:0x3284, 0x08049056:0x1C01,
    0x08049058:0x3148, 0x0804905A:0x2300, 0x0804905C:0x5EC9,
    0x0804905E:0x0209, 0x08049060:0x6011, 0x08049062:0x4661,
    0x08049064:0x3188, 0x08049066:0x304A, 0x08049068:0x2200,
    0x0804906A:0x5E80, 0x0804906C:0x0200, 0x0804906E:0x6008,
    0x08049070:0x4770,
}
WORDS = {
    0x08049014:0x03000BE0,
    0x08049038:0x03000650,
    0x08049074:0x03000650,
    # Adjacent words preceding the 24-byte descriptor table; do not presume these are a header.
    0x08069FC4:0xFFFFFFFF, 0x08069FC8:0x00000000,
    0x08069FCC:0x00000000, 0x08069FD0:0x00000000,
    0x08069FD4:0x00000000, 0x08069FD8:0x00000000,
    0x08069FDC:0x00000000, 0x08069FE0:0x00000000,
    0x08069FE4:0x00000000, 0x08069FE8:0x08068968,
    # First two records, enough to cross-check stride and callback-shaped fields.
    0x08069FEC:0x00000000, 0x08069FF0:0x08069FC4,
    0x08069FF4:0x08043A0D, 0x08069FF8:0x08049A89,
    0x08069FFC:0x08049CED, 0x0806A000:0x08049DE5,
    0x0806A004:0x00000011, 0x0806A008:0x08069FC4,
}

def u16(rom, address): return struct.unpack_from('<H', rom, address - ROM_BASE)[0]
def u32(rom, address): return struct.unpack_from('<I', rom, address - ROM_BASE)[0]

def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for address, expected in HALFWORDS.items():
        if u16(rom, address) != expected: raise ValueError(f'instruction mismatch at {address:#010x}')
    for address, expected in WORDS.items():
        if u32(rom, address) != expected: raise ValueError(f'word mismatch at {address:#010x}')
    digest = hashlib.sha256(rom).hexdigest()
    return {
        'pass':66, 'rom_size':len(rom), 'rom_sha256':digest,
        'expected_original_rom_sha256':ROM_SHA256,
        'predicate_helper':'0x08049000', 'coordinate_state_writer':'0x08049040',
        'state_descriptor_table':'0x08069FEC', 'descriptor_stride_bytes':24,
        'observations':[
            '0x08049000 loads the pointer stored at 0x03000BEC, reads a halfword at pointer + 0xEC, and returns 1 when bit 0 is set or 0 otherwise; this is a boolean predicate, but the flag meaning is unknown',
            '0x08049040 stores argument r1 multiplied by 0x100 at 0x030006DC (state base + 0x8C) and r2 multiplied by 0x100 at 0x030006E0 (state base + 0x90)',
            'the same helper reads signed halfwords at source pointer + 0x48 and +0x4A, multiplies each by 0x100, and stores them at 0x030006D4 and 0x030006D8 (state base + 0x84 and +0x88)',
            'multiplication by 0x100 is a left shift by eight, consistent with converting signed integer coordinates into an 8-fractional-bit representation; exact units and consumer semantics remain unknown',
            'the eight words from 0x08069FC4 through 0x08069FE0 are a run of 0xFFFFFFFF followed by zeros, then 0x08069FE4 is zero and 0x08069FE8 points to 0x08068968; this contiguous data is recorded without assigning it a struct role',
            'the descriptor table at 0x08069FEC begins with 24-byte records; the first two entries include pointer-shaped values and code addresses, but no names or gameplay meanings are inferred',
            'no Easter egg trigger is established by these routines',
        ],
        'sha256_matches_expected_rom':digest == ROM_SHA256,
    }

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
    result=audit(a.rom.read_bytes())
    print(f"PASS: helper/data fingerprints verified ({len(HALFWORDS)} halfwords, {len(WORDS)} words)")
    print('  flag meaning and coordinate semantics remain unresolved; no Easter egg inferred')
    if a.json:
        a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(result,indent=2)+'\n')
if __name__ == '__main__': main()
