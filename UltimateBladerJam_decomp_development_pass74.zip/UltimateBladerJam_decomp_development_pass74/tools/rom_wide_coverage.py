#!/usr/bin/env python3
"""ROM-wide inventory for planning full decompilation.

This is a coverage ledger, not a disassembler: an address mention is evidence
that the repository discusses a location, not proof that the containing bytes
have been decompiled. Every ROM byte is included in the region and page stats.
"""
import argparse, hashlib, json, re
from pathlib import Path

BASE = 0x08000000
ROM_SIZE = 0x800000
EXPECTED_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
ADDR_RE = re.compile(r"(?i)\b0x(08[0-7][0-9a-f]{5})\b")
SOURCE_SUFFIXES = {".c", ".h", ".s", ".S", ".txt", ".inc", ".md", ".json", ".py"}

def build_inventory(rom: bytes, repo: Path):
    if len(rom) != ROM_SIZE:
        raise ValueError(f"expected {ROM_SIZE:#x}-byte 8 MiB ROM, got {len(rom):#x}")
    regions = []
    refs = {}
    # Scan implementation/evidence artifacts only. Exclude docs and generated
    # reports so the inventory cannot inflate its own address-reference count.
    scan_roots = [repo / name for name in ("src", "include", "asm", "data", "tools", "tests") if (repo / name).exists()]
    files = (p for scan_root in scan_roots for p in scan_root.rglob("*"))
    for p in sorted(files):
        if not p.is_file() or p.suffix not in SOURCE_SUFFIXES or ".git" in p.parts:
            continue
        try: txt = p.read_text(errors="ignore")
        except OSError: continue
        for m in ADDR_RE.finditer(txt):
            a = int(m.group(1), 16)
            if BASE <= a < BASE + ROM_SIZE:
                refs.setdefault(a, set()).add(p.relative_to(repo).as_posix())
    page_size = 0x1000
    for off in range(0, ROM_SIZE, page_size):
        chunk = rom[off:off+page_size]
        addrs = [a for a in refs if off <= a-BASE < off+page_size]
        regions.append({
            "start": f"0x{BASE+off:08X}", "end_exclusive": f"0x{BASE+off+len(chunk):08X}",
            "size_bytes": len(chunk), "zero_bytes": chunk.count(0),
            "distinct_byte_values": len(set(chunk)), "explicit_address_sites": len(addrs),
            "unique_address_values": len(addrs),
            "status": "referenced-in-repository" if addrs else "no-explicit-address-reference-found"
        })
    source_files = sorted({f for paths in refs.values() for f in paths})
    return {
      "rom_size": len(rom), "rom_sha256": hashlib.sha256(rom).hexdigest(),
      "expected_rom_sha256": EXPECTED_SHA256,
      "expected_rom_hash_matches": hashlib.sha256(rom).hexdigest() == EXPECTED_SHA256,
      "address_space": {"base": f"0x{BASE:08X}", "end_exclusive": f"0x{BASE+ROM_SIZE:08X}"},
      "page_size": page_size, "page_count": len(regions),
      "unique_rom_address_values_mentioned": len(refs),
      "source_files_with_rom_address_mentions": len(source_files),
      "coverage_warning": "Mention counts are not decompilation coverage. A referenced page can contain mostly undocumented code/data; an unreferenced page can still contain known content under non-address labels.",
      "pages": regions,
      "address_reference_samples": [{"address": f"0x{a:08X}", "files": sorted(paths)} for a, paths in sorted(refs.items())]
    }

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("rom", type=Path); ap.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--json", type=Path); args = ap.parse_args()
    result = build_inventory(args.rom.read_bytes(), args.repo)
    print(f"ROM SHA256: {result['rom_sha256']}")
    print(f"Pages inventoried: {result['page_count']} x {result['page_size']:#x} bytes")
    print(f"Unique ROM addresses mentioned: {result['unique_rom_address_values_mentioned']}")
    print(f"Source files with address mentions: {result['source_files_with_rom_address_mentions']}")
    print("Note:", result["coverage_warning"])
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2) + "\n")
if __name__ == "__main__": main()
