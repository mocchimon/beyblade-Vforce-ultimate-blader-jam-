#!/usr/bin/env python3
"""ROM-backed audit of the selector consumer at 0x08045A00 (Pass 62)."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE = 0x08000000
ROM_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
INSTRUCTIONS = {
    0x08045A04: 0xF00B, 0x08045A06: 0xFADA,
    0x08045A08: 0x4C08, 0x08045A0A: 0x1930, 0x08045A0C: 0x6800,
    0x08045A0E: 0x2804, 0x08045A10: 0xD831, 0x08045A12: 0x0080,
    0x08045A14: 0x4906, 0x08045A16: 0x1840, 0x08045A18: 0x6800,
    0x08045A1A: 0x4687,
    0x08045A48: 0x2001, 0x08045A4A: 0xF00B, 0x08045A4C: 0xFEB7,
    0x08045A4E: 0x2019,
    0x08045A56: 0x2001, 0x08045A58: 0xE000, 0x08045A5A: 0x2004,
    0x08045A5C: 0xF00B, 0x08045A5E: 0xFEAE,
    0x08045A60: 0x200F, 0x08045A62: 0xF003, 0x08045A64: 0xFB4B,
    0x08045A68: 0x2028, 0x08045A6A: 0xF003, 0x08045A6C: 0xFB47,
    0x08045A70: 0x200C, 0x08045A72: 0xF003, 0x08045A74: 0xFB43,
}
WORDS = {
    0x08045A2C: 0x000004B4,
    0x08045A30: 0x08045A34,
    0x08045A34: 0x08045A48,
    0x08045A38: 0x08045A5A,
    0x08045A3C: 0x08045A56,
    0x08045A40: 0x08045A70,
    0x08045A44: 0x08045A68,
}
def u16(b,a): return struct.unpack_from('<H',b,a-ROM_BASE)[0]
def u32(b,a): return struct.unpack_from('<I',b,a-ROM_BASE)[0]
def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for a,v in INSTRUCTIONS.items():
        if u16(rom,a) != v: raise ValueError(f'instruction mismatch at {a:#010x}')
    for a,v in WORDS.items():
        if u32(rom,a) != v: raise ValueError(f'word/table mismatch at {a:#010x}')
    digest=hashlib.sha256(rom).hexdigest()
    return {
      'pass':62, 'rom_size':len(rom), 'rom_sha256':digest,
      'expected_original_rom_sha256':ROM_SHA256,
      'routine':'0x08045A00', 'selector_field_offset':'0x4B4',
      'selector_load':'word [r6 + 0x4B4]', 'bounds_check':'selector > 4 branches to 0x08045A76',
      'jump_table':'0x08045A34',
      'targets':['0x08045A48','0x08045A5A','0x08045A56','0x08045A70','0x08045A68'],
      'observed_case_effects':[
        {'target':'0x08045A48','field_setter_argument':1,'followup_argument':25},
        {'target':'0x08045A5A','field_setter_argument':4,'followup_argument':15},
        {'target':'0x08045A56','field_setter_argument':1,'followup_argument':15},
        {'target':'0x08045A70','followup_argument':12,'field_setter':'none visible in this case block'},
        {'target':'0x08045A68','followup_argument':40,'field_setter':'none visible in this case block'},
      ],
      'interpretation_limit':'This is another consumer of selector +0x4B4, not proof of its writer or semantic meaning. The case arguments are literal numeric values; do not assign gameplay names without tracing callees and callers. No Easter egg is established.',
      'sha256_matches_expected_rom':digest==ROM_SHA256}
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
    report=audit(a.rom.read_bytes()); print('PASS: selector consumer 0x08045A00 instruction/table fingerprint verified')
    print('  upstream writer and gameplay meaning remain unresolved')
    if a.json: a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__': main()
