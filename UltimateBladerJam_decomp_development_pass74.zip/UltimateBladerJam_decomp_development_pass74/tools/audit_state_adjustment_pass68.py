#!/usr/bin/env python3
"""ROM-backed Pass 68 audit of signed step adjustment and state bit predicate."""
import argparse,hashlib,json,struct
from pathlib import Path
ROM_BASE=0x08000000
ROM_SHA256="a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
HALFWORDS={134517220: 7170, 134517222: 4051, 134517224: 10752, 134517226: 53264, 134517228: 11008, 134517230: 53250, 134517232: 16978, 134517234: 57344, 134517236: 4169, 134517238: 10496, 134517240: 53253, 134517242: 520, 134517244: 17026, 134517246: 56825, 134517248: 7178, 134517250: 10496, 134517252: 53504, 134517254: 8705, 134517256: 11008, 134517258: 53248, 134517260: 16978, 134517262: 7184, 134517264: 18288, 134516736: 18436, 134516738: 26817, 134516740: 12780, 134516742: 8193, 134516744: 34825, 134516746: 16392, 134516748: 10240, 134516750: 53507, 134516752: 8192, 134516754: 57346, 134516760: 8193, 134516762: 18288, 134516874: 6720, 134516876: 8576, 134516878: 61440, 134516880: 63657, 134516882: 320, 134516900: 6720, 134516902: 8576, 134516904: 61440, 134516906: 63644, 134516908: 320}
WORDS={134516756: 50334688, 134516940: 50333264}
def adjustment(delta, threshold=128):
    """Model the helper for normal 32-bit deltas and the observed threshold 128."""
    if delta==0: return 0
    magnitude=abs(delta)
    while threshold and magnitude <= (threshold << 8): threshold >>= 1
    step=threshold or 1
    return -step if delta < 0 else step
def audit(data):
    if len(data)!=0x800000: raise ValueError("expected 8 MiB ROM")
    for addr,value in HALFWORDS.items():
        if struct.unpack_from('<H',data,addr-ROM_BASE)[0]!=value: raise ValueError(f'instruction mismatch at {addr:#010x}')
    for addr,value in WORDS.items():
        if struct.unpack_from('<I',data,addr-ROM_BASE)[0]!=value: raise ValueError(f'literal mismatch at {addr:#010x}')
    digest=hashlib.sha256(data).hexdigest()
    return {'pass':68,'rom_sha256':digest,'sha256_matches_expected_rom':digest==ROM_SHA256,'instruction_halfwords':len(HALFWORDS),'literal_words':len(WORDS),'helper':'0x080491E4','predicate':'0x08049000'}
def main():
    p=argparse.ArgumentParser();p.add_argument('rom',type=Path);p.add_argument('--json',type=Path);a=p.parse_args()
    result=audit(a.rom.read_bytes());print(f"PASS: {len(HALFWORDS)} halfwords, {len(WORDS)} literal words")
    if a.json:
        a.json.parent.mkdir(parents=True,exist_ok=True);a.json.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
