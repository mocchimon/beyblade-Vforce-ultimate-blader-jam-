#!/usr/bin/env python3
"""Conservative, deterministic 4-KiB inventory; never equate entropy with code."""
import argparse,collections,hashlib,json,math
from pathlib import Path
SIZE=8388608
PAGE=4096
BASE=0x08000000
EXPECTED="a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
def classify(block):
    if block == bytes(len(block)): return "all_zero_fill"
    if block == bytes([255])*len(block): return "all_ff_fill"
    return "unresolved"
def audit(data):
    if len(data)!=SIZE: raise ValueError("expected 8 MiB ROM")
    result=[]
    for i in range(SIZE//PAGE):
        b=data[i*PAGE:(i+1)*PAGE]
        counts=collections.Counter(b)
        ent=-sum((n/PAGE)*math.log2(n/PAGE) for n in counts.values())
        result.append(dict(index=i,start=BASE+i*PAGE,end_exclusive=BASE+(i+1)*PAGE,kind=classify(b),entropy=round(ent,4),sha256=hashlib.sha256(b).hexdigest()))
    summary=dict(collections.Counter(p['kind'] for p in result))
    return dict(pass_number=73,rom_sha256=hashlib.sha256(data).hexdigest(),matches_expected_rom=hashlib.sha256(data).hexdigest()==EXPECTED,rom_size=SIZE,page_size=PAGE,pages=2048,counts=summary,confirmed_fill_percent=round(100*(summary.get('all_zero_fill',0)+summary.get('all_ff_fill',0))/2048,3),disclaimer="Fill classification is not decompilation completeness; unresolved pages may contain code, data, assets, or mixed regions.",page_inventory=result)
def main():
    p=argparse.ArgumentParser();p.add_argument('rom',type=Path);p.add_argument('--json',type=Path,required=True);args=p.parse_args()
    result=audit(args.rom.read_bytes());args.json.parent.mkdir(parents=True,exist_ok=True);args.json.write_text(json.dumps(result,indent=2)+'\n')
    print('Pages:',result['pages'],'Counts:',result['counts'],'Verified ROM:',result['matches_expected_rom'])
if __name__=='__main__':main()
