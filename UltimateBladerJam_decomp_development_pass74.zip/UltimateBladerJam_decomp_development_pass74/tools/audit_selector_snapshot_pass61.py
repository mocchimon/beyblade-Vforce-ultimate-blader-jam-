#!/usr/bin/env python3
"""ROM-backed audit of selector snapshots and a related five-way reader."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE = 0x08000000
ROM_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
INSTRUCTIONS = {
    # 0x08048536: read [r6 + 0x4B4], truncate to byte on store [r7 + 4]
    0x08048536: 0x4902, 0x08048538: 0x1870, 0x0804853A: 0x6800, 0x0804853C: 0x7138,
    # 0x080488B2: same snapshot pattern with different register allocation
    0x080488B2: 0x4902, 0x080488B4: 0x1878, 0x080488B6: 0x6800, 0x080488B8: 0x7130,
    # 0x08048956: third selector consumer / five-way dispatch
    0x08048956: 0x4A06, 0x08048958: 0x18B8, 0x0804895A: 0x6800,
    0x0804895C: 0x2804, 0x0804895E: 0xD843, 0x08048960: 0x0080,
    0x08048962: 0x4904, 0x08048964: 0x1840, 0x08048966: 0x6800,
    0x08048968: 0x4687,
}
WORDS = {
    0x08048540: 0x000004B4,
    0x080485E8: 0x000004B4,
    0x080488BC: 0x000004B4,
    0x08048970: 0x000004B4,
    0x08048974: 0x08048978,
    0x08048978: 0x0804898C,
    0x0804897C: 0x080489A0,
    0x08048980: 0x080489B4,
    0x08048984: 0x080489C8,
}
def u16(b,a): return struct.unpack_from('<H',b,a-ROM_BASE)[0]
def u32(b,a): return struct.unpack_from('<I',b,a-ROM_BASE)[0]
def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for a,v in INSTRUCTIONS.items():
        if u16(rom,a) != v: raise ValueError(f'instruction mismatch at {a:#010x}')
    for a,v in WORDS.items():
        if u32(rom,a) != v: raise ValueError(f'word/literal mismatch at {a:#010x}')
    digest=hashlib.sha256(rom).hexdigest()
    return {
      'rom_size':len(rom),'rom_sha256':digest,'expected_original_rom_sha256':ROM_SHA256,
      'selector_field_offset':'0x4B4',
      'snapshots':[
        {'site':'0x08048536','source':'word [r6 + 0x4B4]','destination':'byte [r7 + 4]','operation':'load word then store low byte'},
        {'site':'0x080488B2','source':'word [r7 + 0x4B4]','destination':'byte [r6 + 4]','operation':'load word then store low byte'},
      ],
      'additional_dispatch':{'site':'0x08048956','bounds':'selector > 4 branches to 0x080489E8','jump_table':'0x08048974','targets':['0x08048978','0x0804898C','0x080489A0','0x080489B4','0x080489C8']},
      'interpretation_limit':'These sites read the selector and two copy its low byte into another record. They do not identify the upstream writer or the gameplay meaning; no Easter egg is established.',
      'sha256_matches_expected_rom':digest==ROM_SHA256}
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
    report=audit(a.rom.read_bytes()); print('PASS: selector snapshot and related five-way dispatch fingerprints verified')
    print('  selector writer/semantic meaning remain unresolved')
    if a.json: a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__': main()
