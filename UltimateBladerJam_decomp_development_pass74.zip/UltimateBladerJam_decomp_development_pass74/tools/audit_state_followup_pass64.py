#!/usr/bin/env python3
"""ROM-backed audit of the state-selection follow-up at 0x080495C8."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE=0x08000000
ROM_SHA256='a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce'
# Fingerprint the prologue, state-table lookup, resource/record processing, and epilogue.
HALFWORDS={
 0x080495C8:0xB570, 0x080495CA:0xB081, 0x080495CC:0x4908,
 0x080495D0:0x30B4, 0x080495D2:0x6800, 0x080495D4:0x6842,
 0x080495D6:0x6849, 0x080495D8:0x2001, 0x080495DA:0x4240,
 0x080495DC:0x4281, 0x080495DE:0xD00B, 0x080495E0:0x0048,
 0x080495E2:0x1840, 0x080495E4:0x00C0, 0x080495E6:0x4903,
 0x080495E8:0x1840, 0x080495EA:0x6846, 0x080495F8:0x2600,
 0x08049600:0x2100, 0x08049602:0x5E40, 0x08049604:0x2800,
 0x08049606:0xD01C, 0x08049608:0x6910, 0x0804960A:0x6A85,
 0x0804960C:0x2D00, 0x0804960E:0xD018, 0x08049610:0x208B,
 0x08049616:0x6829, 0x08049618:0x686A, 0x0804961A:0x68AB,
 0x0804961C:0x68E8, 0x0804961E:0x9000, 0x08049620:0x1C20,
 0x08049622:0xF006, 0x08049624:0xFF61, 0x08049626:0x6929,
 0x08049628:0x696A, 0x0804962A:0x69AB, 0x0804962C:0x69E8,
 0x0804962E:0x9000, 0x08049630:0x1C20, 0x08049632:0xF006,
 0x08049634:0xFF7D, 0x08049636:0x6A29, 0x08049638:0x2026,
 0x0804963A:0x5E2A, 0x0804963C:0x1C20, 0x0804963E:0xF006,
 0x08049640:0xFF9D, 0x08049642:0x4C0D, 0x08049644:0x1C20,
 0x08049646:0xF7F9, 0x08049648:0xFF87, 0x0804964A:0x2E00,
 0x0804964C:0xD00F, 0x0804964E:0x6A70, 0x08049650:0x2800,
 0x08049652:0xD00C, 0x08049654:0xF7FF, 0x08049656:0xFCD4,
 0x08049658:0x0600, 0x0804965A:0x2800, 0x0804965C:0xD007,
 0x0804965E:0x21A0, 0x08049660:0x0049, 0x08049662:0x1860,
 0x08049664:0x6A72, 0x08049666:0x6811, 0x08049668:0x6852,
 0x0804966A:0xF7FF, 0x0804966C:0xFCE9, 0x0804966E:0xB001,
 0x08049670:0xBC70, 0x08049672:0xBC01, 0x08049674:0x4700,
}
WORDS={0x080495F0:0x03000650,0x080495F4:0x08069FEC,
       0x08049678:0x03000650,0x0804967C:0x00000464}
def u16(b,a): return struct.unpack_from('<H',b,a-ROM_BASE)[0]
def u32(b,a): return struct.unpack_from('<I',b,a-ROM_BASE)[0]
def audit(rom):
 if len(rom)!=0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
 for a,v in HALFWORDS.items():
  if u16(rom,a)!=v: raise ValueError(f'instruction mismatch at {a:#010x}')
 for a,v in WORDS.items():
  if u32(rom,a)!=v: raise ValueError(f'literal mismatch at {a:#010x}')
 digest=hashlib.sha256(rom).hexdigest()
 return {'pass':64,'rom_size':len(rom),'rom_sha256':digest,'expected_original_rom_sha256':ROM_SHA256,
  'routine':'0x080495C8','state_block':'0x03000650','state_descriptor_table':'0x08069FEC',
  'observations':[
   'routine reads the state-block word at +4 and treats 0xFFFFFFFF as a special no-descriptor case',
   'otherwise computes descriptor address 0x08069FEC + state_id*0x18 and loads the word at descriptor +4',
   'reads the pointer at [0x03000704] and its +4 field; this pointer/field participates in subsequent record processing',
   'checks a signed halfword at state_block+0x464 before entering a conditional record-processing path',
   'conditional path reads a pointer chain at [r2+0x10] then [that_pointer+0x28], and when non-null forwards groups of record words to 0x080504E8 and 0x08050530, plus a halfword at record offset 0x26 to 0x0805057C',
   'calls 0x08043558 on the shared path; an optional second path tests [r6+0x24], calls 0x08049000, and may call 0x08049040',
   'observations are structural; semantic names for state IDs and record types remain unconfirmed'],
  'sha256_matches_expected_rom':digest==ROM_SHA256}
def main():
 p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
 r=audit(a.rom.read_bytes()); print(f"PASS: state follow-up fingerprint verified ({len(HALFWORDS)} halfwords, {len(WORDS)} literals)")
 print('  state ID semantics and hidden-content relevance remain unresolved')
 if a.json: a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__': main()
