#!/usr/bin/env python3
"""Audit known literal-pool references to shared RAM state base 0x03000BE0."""
import argparse, hashlib, json, struct
from pathlib import Path
BASE=0x08000000
EXPECTED_SHA='a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce'
LITERALS=(0x08049014,0x08049948,0x080499B0,0x08049A18,0x08049A7C,0x08049AE4,0x08049B58,0x08049BE4,0x08049C60,0x08049CD4)
EXPECTED=0x03000BE0
# Instructions confirming indirect flag access at 0x08049000.
PREDICATE=(0x4804,0x68C1,0x31EC,0x2001,0x8809,0x4008,0x2800)
# Two explicit consumers of signed halfwords +0x48 and +0x4A, within 0x08049040.
FIELD_READS={0x08049058:0x3148,0x0804905C:0x5EC9,0x08049066:0x304A,0x0804906A:0x5E80}
def audit(data):
    if len(data)!=0x800000: raise ValueError('ROM must be exactly 8 MiB')
    for addr in LITERALS:
        if struct.unpack_from('<I',data,addr-BASE)[0]!=EXPECTED: raise ValueError(f'literal mismatch {addr:#x}')
    for i,expected in enumerate(PREDICATE):
        addr=0x08049000+2*i
        if struct.unpack_from('<H',data,addr-BASE)[0]!=expected: raise ValueError(f'predicate mismatch {addr:#x}')
    for addr,expected in FIELD_READS.items():
        if struct.unpack_from('<H',data,addr-BASE)[0]!=expected: raise ValueError(f'field read mismatch {addr:#x}')
    return {'pass':69,'rom_sha256':hashlib.sha256(data).hexdigest(),'original_rom_sha256_matches':hashlib.sha256(data).hexdigest()==EXPECTED_SHA,'state_base':'0x03000BE0','pointer_slot':'0x03000BEC','literal_references':[f'{a:#010x}' for a in LITERALS],'predicate':'0x08049000','confirmed_record_halfword_consumer':'0x08049040','field_offsets':['0x48','0x4A'],'writer_of_flag_bit0':'unresolved'}
def main():
    p=argparse.ArgumentParser();p.add_argument('rom',type=Path);p.add_argument('--json',type=Path);a=p.parse_args()
    result=audit(a.rom.read_bytes())
    if a.json:
        a.json.parent.mkdir(parents=True,exist_ok=True);a.json.write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: 10 shared-state literals, 7 predicate instructions, 4 field-read instructions')
if __name__=='__main__':main()
