#!/usr/bin/env python3
"""ROM-backed audit of the context selection/history helper at 0x080490FC."""
import argparse, hashlib, json, struct
from pathlib import Path
ROM_BASE = 0x08000000
ROM_SHA256 = "a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce"
HALFWORDS = {
  0x080490FC:0xB530, 0x080490FE:0x1C05, 0x08049100:0x4C15,
  0x08049102:0x6821, 0x08049104:0x42A9, 0x08049106:0xD023,
  0x08049108:0x6860, 0x0804910A:0x42A8, 0x0804910C:0xD020,
  0x0804910E:0x2001, 0x08049110:0x4240, 0x08049112:0x4281,
  0x08049114:0xD009, 0x08049116:0x2003, 0x08049118:0xF000,
  0x0804911A:0xF916, 0x0804911C:0x2003, 0x0804911E:0x2101,
  0x08049120:0xF7FF, 0x08049122:0xFFD6, 0x08049124:0x490D,
  0x08049126:0x2001, 0x08049128:0x7008, 0x0804912A:0x1C22,
  0x0804912C:0x327C, 0x0804912E:0x7810, 0x08049130:0x1C01,
  0x08049132:0x290E, 0x08049134:0xD809, 0x08049136:0x3001,
  0x08049138:0x7010, 0x0804913A:0x0088, 0x0804913C:0x1C21,
  0x0804913E:0x3114, 0x08049140:0x1840, 0x08049142:0x6861,
  0x08049144:0x6001, 0x08049146:0x6820, 0x08049148:0x60A0,
  0x0804914A:0x6065, 0x0804914C:0xF000, 0x0804914E:0xFA3C,
  0x08049150:0xBC30, 0x08049152:0xBC01, 0x08049154:0x4700,
  # companion restore/pop routine
  0x0804917C:0xB530, 0x0804917E:0x4C10, 0x08049180:0x1C25,
  0x08049182:0x357C, 0x08049184:0x7828, 0x08049186:0x2800,
  0x08049188:0xD015, 0x0804918A:0x2003, 0x0804918C:0xF000,
  0x0804918E:0xF8DC, 0x08049190:0x2003, 0x08049192:0x2101,
  0x08049194:0xF7FF, 0x08049196:0xFF9C, 0x08049198:0x490A,
  0x0804919A:0x2001, 0x0804919C:0x7008, 0x0804919E:0x7828,
  0x080491A0:0x3801, 0x080491A2:0x7028, 0x080491A4:0x0600,
  0x080491A6:0x0D80, 0x080491A8:0x1C21, 0x080491AA:0x3114,
  0x080491AC:0x1840, 0x080491AE:0x6800, 0x080491B0:0x6060,
  0x080491B2:0x6820, 0x080491B4:0x60A0, 0x080491B6:0xF000,
  0x080491B8:0xFA07, 0x080491BA:0xBC30, 0x080491BC:0xBC01,
  0x080491BE:0x4700,
}
WORDS = {0x08049158:0x03000650, 0x0804915C:0x03000BFC,
         0x080491C0:0x03000650, 0x080491C4:0x03000BFC}
def u16(b,a): return struct.unpack_from('<H',b,a-ROM_BASE)[0]
def u32(b,a): return struct.unpack_from('<I',b,a-ROM_BASE)[0]
def audit(rom):
    if len(rom) != 0x800000: raise ValueError('expected the 8 MiB original GBA ROM')
    for a,v in HALFWORDS.items():
        if u16(rom,a) != v: raise ValueError(f'instruction mismatch at {a:#010x}')
    for a,v in WORDS.items():
        if u32(rom,a) != v: raise ValueError(f'literal mismatch at {a:#010x}')
    digest=hashlib.sha256(rom).hexdigest()
    return {
      'pass':63, 'rom_size':len(rom), 'rom_sha256':digest,
      'expected_original_rom_sha256':ROM_SHA256,
      'select_or_push_helper':'0x080490FC', 'restore_or_pop_helper':'0x0804917C',
      'state_block':'0x03000650', 'event_flag_byte':'0x03000BFC',
      'observed_select_behavior':[
        'input argument in r0 is compared with the current state at [0x03000650] and previous state at [0x03000654]; matching either skips the state update path',
        'for a nonduplicate state, a bounded history counter at state_block+0x7C indexes a 15-entry array beginning at state_block+0x14',
        'the helper records the previous state, shifts current state to state_block+8, stores the requested state at state_block+4, and calls 0x080495C8',
        'when the previous state equals 0xFFFFFFFF, it calls 0x08049348 and 0x080490D0 with argument 3, then sets byte 0x03000BFC to 1',
      ],
      'observed_restore_behavior':[
        'companion routine returns early when history counter at state_block+0x7C is zero',
        'otherwise decrements the history counter and loads the corresponding saved state from state_block+0x14+index*4 into state_block+4',
        'copies state_block+0 into state_block+8 and calls 0x080495C8',
      ],
      'limits':'State history behavior is directly supported by instruction/literal checks. The meaning of numeric state IDs and any Easter-egg relationship remain unverified.',
      'sha256_matches_expected_rom':digest==ROM_SHA256}
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('rom',type=Path); p.add_argument('--json',type=Path); a=p.parse_args()
    report=audit(a.rom.read_bytes()); print('PASS: state select/history and restore helper fingerprints verified')
    print('  state IDs are numeric; semantic labels remain unresolved')
    if a.json: a.json.parent.mkdir(parents=True,exist_ok=True); a.json.write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__': main()
