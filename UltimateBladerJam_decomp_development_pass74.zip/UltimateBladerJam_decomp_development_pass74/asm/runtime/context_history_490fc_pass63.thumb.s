; Pass 63 ROM-backed Thumb capture.
; ROM addresses below are CPU addresses (ROM offset = address - 0x08000000).
; 0x080490FC: context/state selection and bounded history update.
080490FC: B530       PUSH {R4,R5,LR}
080490FE: 1C05       ADDS R5,R0,#0          ; requested state ID
08049100: 4C15       LDR R4,[PC,#0x54]      ; -> 0x03000650 state block
08049102: 6821       LDR R1,[R4,#0]         ; current state
08049104: 42A9       CMP R1,R5
08049106: D023       BEQ 0x08049150         ; duplicate current state: exit
08049108: 6860       LDR R0,[R4,#4]         ; previous/current slot
0804910A: 42A8       CMP R0,R5
0804910C: D020       BEQ 0x08049150         ; duplicate previous slot: exit
0804910E: 2001       MOVS R0,#1
08049110: 4240       RSBS R0,R0,#0          ; -1
08049112: 4281       CMP R1,R0
08049114: D009       BEQ 0x0804912A
; first-state setup branch
08049116: 2003       MOVS R0,#3
08049118: F000 F916  BL 0x08049348
0804911C: 2003       MOVS R0,#3
0804911E: 2101       MOVS R1,#1
08049120: F7FF FFD6  BL 0x080490D0
08049124: 490D       LDR R1,[PC,#0x34]      ; -> 0x03000BFC
08049126: 2001       MOVS R0,#1
08049128: 7008       STRB R0,[R1]
; bounded history and state shift
0804912A: 1C22       ADDS R2,R4,#0
0804912C: 327C       ADDS R2,#0x7C         ; history count
0804912E: 7810       LDRB R0,[R2]
08049130: 1C01       ADDS R1,R0,#0
08049132: 290E       CMP R1,#14
08049134: D809       BHI 0x0804914A
08049136: 3001       ADDS R0,#1
08049138: 7010       STRB R0,[R2]
0804913A: 0088       LSLS R0,R1,#2
0804913C: 1C21       ADDS R1,R4,#0
0804913E: 3114       ADDS R1,#0x14
08049140: 1840       ADDS R0,R0,R1
08049142: 6861       LDR R1,[R4,#4]
08049144: 6001       STR R1,[R0,#0]         ; history[count]
08049146: 6820       LDR R0,[R4,#0]
08049148: 60A0       STR R0,[R4,#8]
0804914A: 6065       STR R5,[R4,#4]         ; requested state becomes current slot
0804914C: F000 FA3C  BL 0x080495C8
08049150: BC30       POP {R4,R5}
08049152: BC01       POP {R0}
08049154: 4700       BX R0
08049158: 03000650   .word state block address
0804915C: 03000BFC   .word event-flag byte address

; 0x0804917C: companion history restore operation.
0804917C: B530       PUSH {R4,R5,LR}
0804917E: 4C10       LDR R4,[PC,#0x40]      ; -> 0x03000650
08049180: 1C25       ADDS R5,R4,#0
08049182: 357C       ADDS R5,#0x7C
08049184: 7828       LDRB R0,[R5]
08049186: 2800       CMP R0,#0
08049188: D015       BEQ 0x080491B6         ; empty history
0804918A: 2003       MOVS R0,#3
0804918C: F000 F8DC  BL 0x08049348
08049190: 2003       MOVS R0,#3
08049192: 2101       MOVS R1,#1
08049194: F7FF FF9C  BL 0x080490D0
08049198: 490A       LDR R1,[PC,#0x28]      ; -> 0x03000BFC
0804919A: 2001       MOVS R0,#1
0804919C: 7008       STRB R0,[R1]
0804919E: 7828       LDRB R0,[R5]
080491A0: 3801       SUBS R0,#1
080491A2: 7028       STRB R0,[R5]
080491A4: 0600       LSLS R0,R0,#24
080491A6: 0D80       LSRS R0,R0,#22
080491A8: 1C21       ADDS R1,R4,#0
080491AA: 3114       ADDS R1,#0x14
080491AC: 1840       ADDS R0,R0,R1
080491AE: 6800       LDR R0,[R0,#0]
080491B0: 6060       STR R0,[R4,#4]         ; restore prior state
080491B2: 6820       LDR R0,[R4,#0]
080491B4: 60A0       STR R0,[R4,#8]
080491B6: F000 FA07  BL 0x080495C8
080491BA: BC30       POP {R4,R5}
080491BC: BC01       POP {R0}
080491BE: 4700       BX R0
080491C0: 03000650   .word state block address
080491C4: 03000BFC   .word event-flag byte address
