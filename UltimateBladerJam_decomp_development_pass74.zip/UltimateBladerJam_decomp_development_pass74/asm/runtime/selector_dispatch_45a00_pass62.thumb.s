; Pass 62: ROM-backed Thumb excerpt at 0x08045A00.
; Source: original 8 MiB GBA ROM, SHA-256 a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce
; r6 is a context-like base in this path. The selector is loaded from [r6 + 0x4B4].
; This excerpt confirms a bounded 0..4 dispatch; it does not identify the field's writer.

08045A04: BL      0x08050FBC       ; preceding setup/helper call
08045A08: LDR     r4, [PC, #0x20]  ; literal at 0x08045A2C = 0x000004B4
08045A0A: ADDS    r0, r6, r4
08045A0C: LDR     r0, [r0]         ; selector word
08045A0E: CMP     r0, #4
08045A10: BHI     0x08045A76      ; reject selector > 4
08045A12: LSLS    r0, r0, #2
08045A14: LDR     r1, [PC, #0x18]  ; table base 0x08045A34
08045A16: ADDS    r0, r0, r1
08045A18: LDR     r0, [r0]
08045A1A: MOV     PC, r0           ; jump-table dispatch

; Jump-table order (selector 0..4):
; 0 -> 0x08045A48: setter(1), then follow-up helper(0x19)
; 1 -> 0x08045A5A: setter(4), then follow-up helper(0x0F)
; 2 -> 0x08045A56: setter(1), then follow-up helper(0x0F)
; 3 -> 0x08045A70: follow-up helper(0x0C), no setter visible in this case block
; 4 -> 0x08045A68: follow-up helper(0x28), no setter visible in this case block

; The helper names/meanings are deliberately not inferred from numeric arguments.
; No Easter egg is established by this dispatch alone.
