/* Pass 67: ROM-backed excerpts for the current/target field flow.
 * Addresses are ROM virtual addresses; offsets in state are from 0x03000650.
 * Semantic labels are provisional; no gameplay meaning is asserted.
 */

/* 0x0804901C: clear current and target pair (four 32-bit zero writes). */
0804901C: 4B06    ldr  r3, [pc, #0x18]   /* 0x03000650 */
0804901E: 1C1A    adds r2, r3, #0
08049020: 3284    adds r2, #0x84
08049022: 1C18    adds r0, r3, #0
08049024: 3088    adds r0, #0x88
08049026: 4905    ldr  r1, [pc, #0x14]   /* 0 */
08049028: 6001    str  r1, [r0]
0804902A: 6011    str  r1, [r2]
0804902C: 3208    adds r2, #8
0804902E: 3008    adds r0, #8
08049030: 6001    str  r1, [r0]
08049032: 6011    str  r1, [r2]
08049034: 4770    bx   lr

/* 0x08049040: set target pair from arguments; seed current pair from signed source fields. */
08049040: 4B0C    ldr  r3, [pc, #0x30]   /* 0x03000650 */
08049042: 469C    mov  r12, r3
08049044: 338C    adds r3, #0x8C
08049046: 0209    lsls r1, r1, #8
08049048: 6019    str  r1, [r3]
0804904A: 4661    mov  r1, r12
0804904C: 3190    adds r1, #0x90
0804904E: 0212    lsls r2, r2, #8
08049050: 600A    str  r2, [r1]
08049052: 4662    mov  r2, r12
08049054: 3284    adds r2, #0x84
08049056: 1C01    adds r1, r0, #0
08049058: 3148    adds r1, #0x48
0804905A: 2300    movs r3, #0
0804905C: 5EC9    ldrsh r1, [r1, r3]
0804905E: 0209    lsls r1, r1, #8
08049060: 6011    str  r1, [r2]
08049062: 4661    mov  r1, r12
08049064: 3188    adds r1, #0x88
08049066: 304A    adds r0, #0x4A
08049068: 2200    movs r2, #0
0804906A: 5E80    ldrsh r0, [r0, r2]
0804906C: 0200    lsls r0, r0, #8
0804906E: 6008    str  r0, [r1]
08049070: 4770    bx   lr

/* 0x08049078: update current fields toward target fields, then write integer
 * portions back to source record +0x48/+0x4A. Calls 0x080491E4 for adjustment.
 */
08049078: B570    push {r4, r5, r6, lr}
0804907A: 1C06    adds r6, r0, #0
0804907C: 4C13    ldr  r4, [pc, #0x4C]   /* 0x03000650 */
08049080: 308C    adds r0, #0x8C
08049082: 1C25    adds r5, r4, #0
08049084: 3584    adds r5, #0x84
08049086: 6800    ldr  r0, [r0]
08049088: 6829    ldr  r1, [r5]
0804908A: 1A40    subs r0, r0, r1
0804908C: 2180    movs r1, #0x80
0804908E: F000 F8A9 bl 0x080491E4
08049092: 0140    lsls r0, r0, #5
08049094: 6829    ldr  r1, [r5]
08049096: 1809    adds r1, r1, r0
08049098: 6029    str  r1, [r5]
0804909A: 1C20    adds r0, r4, #0
0804909C: 3090    adds r0, #0x90
0804909E: 3488    adds r4, #0x88
080490A0: 6800    ldr  r0, [r0]
080490A2: 6821    ldr  r1, [r4]
080490A4: 1A40    subs r0, r0, r1
080490A6: 2180    movs r1, #0x80
080490A8: F000 F89C bl 0x080491E4
080490AC: 0140    lsls r0, r0, #5
080490AE: 6822    ldr  r2, [r4]
080490B0: 1812    adds r2, r2, r0
080490B2: 6022    str  r2, [r4]
080490B4: 6828    ldr  r0, [r5]
080490B6: 1200    asrs r0, r0, #8
080490B8: 1C31    adds r1, r6, #0
080490BA: 3148    adds r1, #0x48
080490BC: 8008    strh r0, [r1]
080490BE: 1212    asrs r2, r2, #8
080490C0: 364A    adds r6, #0x4A
080490C2: 8032    strh r2, [r6]
080490C4: BC70    pop {r4, r5, r6}
080490C6: BC01    pop {r0}
080490C8: 4700    bx r0
