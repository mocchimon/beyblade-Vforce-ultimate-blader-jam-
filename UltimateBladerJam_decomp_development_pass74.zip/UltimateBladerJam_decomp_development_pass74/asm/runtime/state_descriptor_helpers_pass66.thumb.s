/* Pass 66 evidence transcription; addresses are GBA ROM addresses.
 * Names are provisional and describe observed behavior only.
 */

/* 0x08049000 — boolean bit-test helper.
 * Loads a pointer from 0x03000BE0 + 0x0C (slot 0x03000BEC), reads the
 * halfword at pointer + 0xEC, and returns 1 iff bit 0 is set, else 0.
 * The pointed-to structure and flag semantics are not known.
 */
08049000: 4804    ldr  r0, [pc, #0x10]  /* literal 0x03000BE0 */
08049002: 68C1    ldr  r1, [r0, #0x0C]
08049004: 31EC    adds r1, #0xEC
08049006: 2001    movs r0, #1
08049008: 8809    ldrh r1, [r1]
0804900A: 4008    ands r0, r1
0804900C: 2800    cmp  r0, #0
0804900E: D103    bne  0x08049018
08049010: 2000    movs r0, #0
08049012: E002    b    0x08049018
08049018: 2001    movs r0, #1
0804901A: 4770    bx   lr

/* 0x08049040 — copies/scales integer and source-record coordinates.
 * r1/r2 are shifted left by 8 and stored at 0x030006DC/+0x4.
 * Signed halfwords at [r0+0x48] and [r0+0x4A] are shifted left by 8
 * and stored at 0x030006D4 and 0x030006D8. Do not assign units yet.
 */
08049040: 4B0C    ldr  r3, [pc, #0x30]  /* literal at 0x08049074: 0x03000650 */
08049042: 469C    mov  r12, r3
08049044: 338C    adds r3, #0x8C
08049046: 0209    lsls r1, r1, #8
08049048: 6019    str  r1, [r3]
0804904A: 4661    mov  r1, r12
0804904C: 3190    adds r1, #0x90
0804904E: 0212    lsls r2, r2, #8
08049050: 600A    str  r2, [r1]
08049052: 4662    mov  r2, r12
08049054: 3284    adds r2, #0x84
08049056: 1C01    mov  r1, r0
08049058: 3148    adds r1, #0x48
0804905A: 2300    movs r3, #0
0804905C: 5EC9    ldrsh r1, [r1, r3]
0804905E: 0209    lsls r1, r1, #8
08049060: 6011    str  r1, [r2]
08049062: 4661    mov  r1, r12
08049064: 3188    adds r1, #0x88
08049066: 304A    adds r0, #0x4A
08049068: 2200    movs r2, #0
0804906A: 5E80    ldrsh r0, [r0, r2]
0804906C: 0200    lsls r0, r0, #8
0804906E: 6008    str  r0, [r1]
08049070: 4770    bx   lr
