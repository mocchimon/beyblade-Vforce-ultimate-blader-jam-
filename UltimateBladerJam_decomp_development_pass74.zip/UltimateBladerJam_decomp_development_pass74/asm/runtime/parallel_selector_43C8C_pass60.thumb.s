; Pass 60: second five-way dispatch using context word +0x4B4.
; ROM base is 0x08000000; addresses below are GBA ROM addresses.
08043C8C: 4909       LDR  r1, [PC, #0x24]      ; literal at 0x08043CB4 = 0x4B4
08043C8E: 1870       ADDS r0, r6, r1
08043C90: 6800       LDR  r0, [r0]
08043C92: 2804       CMP  r0, #4
08043C94: D825       BHI  0x08043CE2
08043C96: 0080       LSLS r0, r0, #2
08043C98: 4907       LDR  r1, [PC, #0x1C]      ; literal at 0x08043CB8 = 0x08043CBC
08043C9A: 1840       ADDS r0, r0, r1
08043C9C: 6800       LDR  r0, [r0]
08043C9E: 4687       MOV  PC, r0                ; computed branch

; Five-entry ROM jump table at 0x08043CBC.
; selector 0 -> 0x08043CD0 -> argument 0
; selector 1 -> 0x08043CD4 -> argument 3
; selector 2 -> 0x08043CD8 -> argument 4
; selector 3 -> 0x08043CDC -> argument 5
; selector 4 -> 0x08043CE0 -> argument 7
08043CD0: 2400       MOVS r4, #0
08043CD2: E006       B    0x08043CE2
08043CD4: 2403       MOVS r4, #3
08043CD6: E004       B    0x08043CE2
08043CD8: 2404       MOVS r4, #4
08043CDA: E002       B    0x08043CE2
08043CDC: 2405       MOVS r4, #5
08043CDE: E000       B    0x08043CE2
08043CE0: 2407       MOVS r4, #7

; Common action: publish selected value via 0x08063AA0, then mark 0x03000168 = 0x20.
08043CE2: 1C20       ADDS r0, r4, #0
08043CE4: F01F FEDC BL   0x08063AA0
08043CE8: 4903       LDR  r1, [PC, #0x0C]      ; literal 0x08043CF8 = 0x03000168
08043CEA: 2020       MOVS r0, #0x20
08043CEC: 6008       STR  r0, [r1]

; Note: this is a second dispatcher for the same +0x4B4 field as 0x08045A08,
; but its actions differ. Numeric meanings and any Easter-egg link are unknown.
