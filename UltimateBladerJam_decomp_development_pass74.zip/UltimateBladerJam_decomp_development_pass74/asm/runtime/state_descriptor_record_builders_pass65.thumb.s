/* ROM-backed Thumb notes; ROM addresses shown as absolute GBA addresses.
 * Evidence source: original 8 MiB ROM SHA-256
 * a8c64df585e2ed0da969b47af3369227f10ad08987cd91ba54cf7f9186fcb2ce
 */

/* 0x080495C8: shared follow-up after state selection/restoration.
 * [0x03000654] is compared with 0xFFFFFFFF. Otherwise the routine computes
 * descriptor = 0x08069FEC + state_index * 0x18 and loads descriptor[1].
 * A signed halfword at 0x03000AB4 gates the record-processing path.
 */
080495C8: PUSH {R4,R5,R6,LR}
080495CA: SUB SP, #4
080495CC: LDR R1, [PC, #0x20]       ; 0x03000650
080495D0: ADDS R0, R1, #0
080495D2: ADDS R0, #0xB4
080495D4: LDR R0, [R0]              ; pointer stored at 0x03000704
080495D6: LDR R2, [R0, #4]
080495D8: LDR R1, [R1, #4]          ; state index at 0x03000654
080495DA: MOVS R0, #1
080495DC: RSBS R0, R0, #0           ; 0xFFFFFFFF
080495DE: CMP R1, R0
080495E0: BEQ 0x080495F8
080495E0+2: LSLS R0, R1, #1
080495E2: ADDS R0, R0, R1
080495E4: LSLS R0, R0, #3           ; index * 24
080495E6: LDR R1, [PC, #0x0C]       ; 0x08069FEC
080495E8: ADDS R0, R0, R1
080495EA: LDR R6, [R0, #4]

/* 0x080504E8: repeated record builder A.
 * Signed count = halfword [argument_object + 0x0C]. Destination base is
 * [argument_object + 8]. Each iteration advances destination by 0x18.
 * Two values are multiplied by evolving fixed-point factors, arithmetic
 * shifted right 8, then stored at destination offsets 0x10 and 0x14.
 */
080504E8: PUSH {R4,R5,R6,R7,LR}
080504EA: MOV R7, R8
080504EC: PUSH {R7}
080504FC: LDR R1, [R4, #8]
08050502: MOV R0, R12
08050504: MULS R0, R5, R0
08050506: ASRS R0, R0, #8
08050508: STR R0, [R1, #0x10]
0805050A: MOV R0, R8
0805050C: MULS R0, R3, R0
0805050E: ASRS R0, R0, #8
08050510: STR R0, [R1, #0x14]
08050518: ADDS R1, #0x18
0805051A: ADDS R2, #1
0805051E: LDRSH R0, [R4, #0x0C]
08050522: BLT loop

/* 0x08050530: companion builder writes offsets 0x08 and 0x0C with same stride. */
08050530: PUSH {R4,R5,R6,R7,LR}
08050544: LDR R1, [R4, #8]
0805054A: MOV R0, R12
0805054C: MULS R0, R5, R0
0805054E: ASRS R0, R0, #8
08050550: STR R0, [R1, #8]
08050552: MOV R0, R8
08050554: MULS R0, R3, R0
08050556: ASRS R0, R0, #8
08050558: STR R0, [R1, #0x0C]
08050560: ADDS R1, #0x18
08050562: ADDS R2, #1
08050566: LDRSH R0, [R4, #0x0C]
0805056A: BLT loop

/* Small record writers. */
08050578: STRH R1, [R0, #0x0E]
0805057A: BX LR
0805057C: STR R1, [R0, #0x10]
0805057E: LSLS R2, R2, #0x10
08050580: ASRS R2, R2, #0x10
08050582: STR R2, [R0, #0x14]
08050584: BX LR
