@ Pass 68 ROM-verified locations, see docs/PASS68_DEVELOPMENT_2026-10-26.md
@ 0x080491E4 signed step quantizer: delta r0, threshold r1, signed step return r0
@ 0x08049000 predicate: pointer from 0x03000BEC, bit 0 at +0xEC
@ 0x0804908E / 0x080490A8 motion-loop call sites, threshold 0x80
@ These annotations are not yet a standalone linkable replacement.
