; Pass 61: selector reads and snapshots into a one-byte record field.
; Thumb offsets below are ROM offsets; runtime addresses add 0x08000000.

; Site 0x08048536
08048536: 4902       LDR  r1, [PC, #8]       ; literal at 0x08048540 = 0x4B4
08048538: 1870       ADDS r0, r6, r1
0804853A: 6800       LDR  r0, [r0]          ; word [r6 + 0x4B4]
0804853C: 7138       STRB r0, [r7, #4]     ; copy low byte into record

; Site 0x080488B2
080488B2: 4902       LDR  r1, [PC, #8]       ; literal at 0x080488BC = 0x4B4
080488B4: 1878       ADDS r0, r7, r1
080488B6: 6800       LDR  r0, [r0]          ; word [r7 + 0x4B4]
080488B8: 7130       STRB r0, [r6, #4]     ; copy low byte into record

; Related consumer at 0x08048956
08048956: 4A06       LDR  r2, [PC, #0x18]   ; literal at 0x08048970 = 0x4B4
08048958: 18B8       ADDS r0, r7, r2
0804895A: 6800       LDR  r0, [r0]
0804895C: 2804       CMP  r0, #4
0804895E: D843       BHI  0x080489E8
08048960: 0080       LSLS r0, r0, #2
08048962: 4904       LDR  r1, [PC, #0x10]   ; table at 0x08048974
08048964: 1840       ADDS r0, r0, r1
08048966: 6800       LDR  r0, [r0]
08048968: 4687       MOV  pc, r0

; Five valid table entries at 0x08048974..0x08048984.
; These are consumer/snapshot sites, not evidence of the field's writer.
