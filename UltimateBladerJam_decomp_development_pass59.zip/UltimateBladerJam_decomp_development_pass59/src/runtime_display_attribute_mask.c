#include <stdint.h>

/*
 * Reconstructed from the Thumb routine at 0x08059620.
 *
 * The child record contributes a tile-map base at +0x5C, a log2 stride at
 * +0x5F, and a mode bit at +0x64. The operation preserves each cell's low
 * 12 bits and replaces its upper nibble with the supplied palette/tag value.
 * Parameter names describe observed coordinate/loop roles, not original
 * source names. This routine writes the tile-map area in VRAM directly.
 */
static uint32_t arm_lsl_register(uint32_t value, uint32_t shift)
{
    shift &= 0xFFu;
    return shift >= 32u ? 0u : value << shift;
}

void RuntimeDisplay_ApplyAttributeMask(void *child_record,
                                       uint32_t y_start,
                                       uint32_t x_start,
                                       uint32_t height,
                                       uint32_t width,
                                       uint32_t palette_tag)
{
    const uint8_t *child = (const uint8_t *)child_record;
    uint16_t flags;
    uint32_t tile_base;
    uint32_t stride_shift;
    uint32_t x_end;
    uint32_t y_end;
    uint32_t palette_bits;
    uint32_t column_stride;
    uint32_t x_counter;
    uint32_t y_first;
    volatile uint16_t *tile_map;
    volatile uint16_t *column;

    palette_tag &= 0xFFu;
    tile_base = (uint32_t)child[0x5C] << 11;
    stride_shift = child[0x5F];
    tile_map = (volatile uint16_t *)(uintptr_t)(0x06000000u + tile_base +
              (arm_lsl_register(x_start, stride_shift) << 1));
    column_stride = arm_lsl_register(1u, stride_shift) & 0xFFFFu;
    flags = *(const volatile uint16_t *)(const void *)(child + 0x64);
    if ((flags & 1u) != 0) {
        return;
    }

    /* The ROM forms the end bounds before truncating loop counters to 16 bits. */
    x_end = x_start + width;
    y_end = y_start + height;
    x_counter = x_start & 0xFFFFu;
    y_first = y_start & 0xFFFFu;
    if (x_counter >= x_end || y_first >= y_end) {
        return;
    }

    palette_bits = palette_tag << 12;
    column = tile_map;
    while (x_counter < x_end) {
        uint32_t y_counter = y_first;
        while (y_counter < y_end) {
            volatile uint16_t *cell = column + y_counter;
            uint16_t old_value = *cell;
            *cell = (uint16_t)((old_value & 0x0FFFu) | palette_bits);
            y_counter = (y_counter + 1u) & 0xFFFFu;
        }
        column += column_stride;
        x_counter = (x_counter + 1u) & 0xFFFFu;
    }
}
