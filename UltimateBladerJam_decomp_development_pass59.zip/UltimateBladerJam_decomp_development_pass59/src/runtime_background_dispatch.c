#include <stdint.h>

#include "runtime_display.h"

enum {
    RECORD_BACKGROUND_ENABLE_INDEX = 0x5E,
    RECORD_BACKGROUND_STATE_POINTER = 0x88,
    RECORD_BACKGROUND_MEMORY_INDEX = 0x5D,
    BACKGROUND_MEMORY_OPERATION_SIZE = 0x8000,
};

#define BACKGROUND_MEMORY_DISPATCH_SLOT ((uintptr_t)0x0807D994u)
#define GBA_VRAM_BASE ((uintptr_t)0x06000000u)

/* The ROM calls the selected IWRAM entry through the shared Thumb BX r3
 * trampoline at 0x08065C44. Keep its operation generic: the installed target
 * is address 0x03006FAC, but its implementation is not recovered. */
typedef void (*RuntimeDisplayBackgroundOperation)(uint32_t value,
                                                   void *destination,
                                                   uint32_t size);

/* 0x0804A7EC. The record's byte at +0x5E selects the BG enable bit, which
 * this wrapper clears through RuntimeDisplay_SetBackgroundEnabled. */
void RuntimeDisplay_DisableRecordBackground(const void *record)
{
    const uint8_t *bytes = (const uint8_t *)record;

    RuntimeDisplay_SetBackgroundEnabled(bytes[RECORD_BACKGROUND_ENABLE_INDEX],
                                        0);
}

/* Source-level factoring for the two ROM call sites. The actual ROM reaches
 * this installed operation through its shared Thumb BX r3 trampoline. */
void RuntimeDisplay_InvokeInstalledBackgroundOperation(uint32_t value,
                                                       void *destination,
                                                       uint32_t operation_argument)
{
    RuntimeDisplayBackgroundOperation operation =
        (RuntimeDisplayBackgroundOperation)(uintptr_t)
        *(volatile const uint32_t *)(uintptr_t)
            BACKGROUND_MEMORY_DISPATCH_SLOT;

    operation(value, destination, operation_argument);
}

/* 0x0804A7FC. Follows the record pointer at +0x88, reads the nested byte at
 * +0x5D, and dispatches (0, destination, 0x8000) through the ROM's installed
 * operation pointer. The argument values and dispatch path are verified;
 * whether the backend clears memory or performs another operation is unknown. */
void RuntimeDisplay_InvokeRecordBackgroundOperation(const void *record)
{
    const uint8_t *bytes = (const uint8_t *)record;
    const uint8_t *background_state = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(bytes + RECORD_BACKGROUND_STATE_POINTER);
    uint8_t memory_index =
        background_state[RECORD_BACKGROUND_MEMORY_INDEX];
    uintptr_t destination = (uintptr_t)GBA_VRAM_BASE +
                           ((uintptr_t)memory_index << 14);
    RuntimeDisplay_InvokeInstalledBackgroundOperation(
        0, (void *)destination, BACKGROUND_MEMORY_OPERATION_SIZE);
}
