#include <stdint.h>

#include "child_resource_helpers.h"
#include "runtime_object_records.h"

/* 0x08059958. Clears the observed display-state bytes and scroll registers,
 * then seeds the BG2/BG3 affine transforms with zero angle and 8.8 unit scale.
 * The three IWRAM bytes retain address-based names until their wider roles are
 * established. */
void RuntimeObject_InitializeDisplayState(void)
{
    volatile uint8_t *state_03000de0 =
        (volatile uint8_t *)(uintptr_t)0x03000DE0u;
    volatile uint8_t *state_03000e40 =
        (volatile uint8_t *)(uintptr_t)0x03000E40u;
    volatile uint8_t *state_03000e3c =
        (volatile uint8_t *)(uintptr_t)0x03000E3Cu;
    uint32_t mode;

    *state_03000de0 = 0;
    *state_03000e40 = 0;
    *state_03000e3c = 32;

    for (mode = 0; mode < 4; ++mode) {
        volatile uint16_t *horizontal = (volatile uint16_t *)(uintptr_t)
            ChildResource_HorizontalOffsetRegister(mode);
        volatile uint16_t *vertical = (volatile uint16_t *)(uintptr_t)
            ChildResource_VerticalOffsetRegister(mode);

        *horizontal = 0;
        *vertical = 0;
    }

    RuntimeObject_UpdateAffineTransform(2, 0, 0x0100, 0x0100);
    RuntimeObject_UpdateAffineTransform(3, 0, 0x0100, 0x0100);
}

/* 0x080599B8. Tests the halfword at record +0x64 and returns a normalized
 * boolean, matching the ROM's AND/CMP and 0-or-1 return sequence. */
uint32_t RuntimeObject_TestFlagsAt64(const void *record, uint32_t mask)
{
    const volatile uint16_t *flags = (const volatile uint16_t *)(uintptr_t)
        ((uintptr_t)record + 0x64u);

    return ((*flags & mask) != 0u);
}
