#include <stdint.h>

#include "runtime_display_state.h"

/* 0x0805B268. Stores the supplied owner/source fields, copies source byte +5,
 * and marks the 16-byte record with halfword value 1 at +0x0E. */
void RuntimeDisplayState_InitializeRecord(void *record, uint32_t owner,
                                          const uint8_t *source,
                                          uint32_t field_04,
                                          uint32_t field_0C)
{
    uint8_t *r = (uint8_t *)record;

    *(uint32_t *)(r + 0x08) = (uint32_t)(uintptr_t)source;
    *(uint32_t *)r = owner;
    r[0x0C] = (uint8_t)field_0C;
    *(uint32_t *)(r + 0x04) = field_04;
    *(uint16_t *)(r + 0x0E) = 1;
    r[0x0D] = source[5];
}
