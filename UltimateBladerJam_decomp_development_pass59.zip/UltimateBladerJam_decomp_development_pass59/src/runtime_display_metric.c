#include <stdint.h>

#include "runtime_display.h"

enum {
    SPACE_SEQUENCE_METRIC = 5,
    SPACE_CHARACTER = 0x20,
};

#define SEQUENCE_METRIC_TABLE ((uintptr_t)0x0807D9A4u)

/* 0x0805B400. The caller uses the result when adjusting a rendered
 * sequence's origin; metric units and the table's product meaning are unknown. */
uint32_t RuntimeDisplay_ComputeSequenceMetric(const uint8_t *sequence,
                                              uint32_t metric_table_offset,
                                              uint32_t base_metric)
{
    const uint8_t *table = (const uint8_t *)(uintptr_t)SEQUENCE_METRIC_TABLE;
    uint32_t total = 0;

    for (;;) {
        uint32_t character = *sequence++;
        uint32_t contribution;

        if (character == 0)
            return total;

        if (character == SPACE_CHARACTER) {
            contribution = SPACE_SEQUENCE_METRIC;
        } else {
            uint32_t mapped = table[character];

            contribution = base_metric;
            if (metric_table_offset != 0)
                contribution -= table[metric_table_offset + mapped];
        }

        total += contribution;
    }
}
