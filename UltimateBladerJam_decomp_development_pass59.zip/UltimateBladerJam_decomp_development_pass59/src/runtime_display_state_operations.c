#include <stdint.h>

#include "runtime_display.h"
#include "runtime_display_state.h"

enum {
    RECORD_OBJECT_POINTER = 0x00,
    RECORD_OPERATION_STATE = 0x0E,
    OBJECT_SECOND_DESTINATION_INDEX = 0x5C,
    OBJECT_FIRST_DESTINATION_INDEX = 0x5D,
    OBJECT_FIRST_OPERATION_LENGTH = 0x74,
    SECOND_OPERATION_LENGTH = 0x800,
};

#define GBA_VRAM_BASE ((uintptr_t)0x06000000u)

/* 0x0805B3B8. The operation target at 0x03006FAC remains unresolved; this
 * preserves the ROM-observed arguments through the shared generic wrapper. */
void RuntimeDisplayState_InvokeRecordOperations(void *record)
{
    uint8_t *record_bytes = (uint8_t *)record;
    const uint8_t *object = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(record_bytes + RECORD_OBJECT_POINTER);
    uintptr_t first_destination;
    uintptr_t second_destination;
    uint32_t first_length;

    if (object == 0)
        return;

    first_destination = GBA_VRAM_BASE +
        ((uintptr_t)object[OBJECT_FIRST_DESTINATION_INDEX] << 14);
    first_length = *(const uint32_t *)(object + OBJECT_FIRST_OPERATION_LENGTH);
    RuntimeDisplay_InvokeInstalledBackgroundOperation(
        0, (void *)first_destination, first_length);

    second_destination = GBA_VRAM_BASE +
        ((uintptr_t)object[OBJECT_SECOND_DESTINATION_INDEX] << 11);
    RuntimeDisplay_InvokeInstalledBackgroundOperation(
        0, (void *)second_destination, SECOND_OPERATION_LENGTH);

    *(uint16_t *)(record_bytes + RECORD_OPERATION_STATE) = 1;
}
