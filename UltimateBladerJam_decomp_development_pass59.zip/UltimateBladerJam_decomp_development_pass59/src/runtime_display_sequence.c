#include <stdint.h>

#include "child_resource_helpers.h"
#include "runtime.h"
#include "runtime_display.h"
#include "runtime_display_sequence.h"
#include "runtime_display_tile_blit.h"

enum {
    RECORD_OWNER = 0x00,
    RECORD_METRIC_TABLE_OFFSET = 0x04,
    RECORD_GLYPH_DESCRIPTOR = 0x08,
    RECORD_PALETTE_BANK = 0x0C,
    RECORD_NEXT_TILE = 0x0E,
    OWNER_MAP_BLOCK = 0x5C,
    OWNER_CHARACTER_BLOCK = 0x5D,
    OWNER_BACKGROUND = 0x5E,
    DESCRIPTOR_GLYPH_WIDTH = 0x04,
    DESCRIPTOR_GLYPH_HEIGHT = 0x05,
    DESCRIPTOR_GLYPH_SHIFT = 0x06,
    DESCRIPTOR_DATA_OFFSET = 0x10,
};

enum {
    GBA_VRAM = 0x06000000u,
    MAP_BLOCK_SHIFT = 11,
    CHARACTER_BLOCK_SHIFT = 14,
    TILE_BYTES = 0x20,
    MAP_COLUMNS = 32,
    MAP_ENTRY_BYTES = 2,
    SPACE_ADVANCE = 5,
    SPACE_CHARACTER = 0x20,
};

#define SEQUENCE_GLYPH_INDEX_TABLE ((uintptr_t)0x0807D9A4u)
#define SEQUENCE_BACKGROUND_DISPATCH_MESSAGE ((uintptr_t)0x087553C0u)

static const uint8_t *RuntimeDisplaySequence_GetGlyphSource(
    const uint8_t *descriptor, uint32_t glyph_index)
{
    uint32_t shift = descriptor[DESCRIPTOR_GLYPH_SHIFT];
    uint32_t data_offset =
        *(const uint32_t *)(descriptor + DESCRIPTOR_DATA_OFFSET);
    uint32_t glyph_offset = shift < 32u ? glyph_index << shift : 0u;

    /* Register LSL produces zero when the shift amount is at least 32. */
    return descriptor + data_offset + glyph_offset;
}

static int32_t RuntimeDisplaySequence_AddWrapped(int32_t value,
                                                 uint32_t increment)
{
    return (int32_t)((uint32_t)value + increment);
}

static uint32_t RuntimeDisplaySequence_GetMetric(
    const uint8_t *record, const uint8_t *descriptor,
    const uint8_t *sequence)
{
    uint32_t table_offset =
        *(const uint32_t *)(record + RECORD_METRIC_TABLE_OFFSET);

    return RuntimeDisplay_ComputeSequenceMetric(
        sequence, table_offset, descriptor[DESCRIPTOR_GLYPH_WIDTH]);
}

static void RuntimeDisplaySequence_ReserveMapTiles(
    uint8_t *record, const uint8_t *owner, const uint8_t *descriptor,
    int32_t x, uint32_t y, uint32_t metric)
{
    uint32_t x_bits = (uint32_t)x;
    uintptr_t map_address = (uintptr_t)GBA_VRAM +
        ((uintptr_t)owner[OWNER_MAP_BLOCK] << MAP_BLOCK_SHIFT) +
        ((uintptr_t)(y & ~7u) << 3) +
        ((uintptr_t)(x_bits >> 3) << 1);
    uint32_t columns = ((x_bits & 7u) + metric + 8u) >> 3;
    uint32_t rows = descriptor[DESCRIPTOR_GLYPH_HEIGHT] >> 3;
    uint32_t row;

    if ((y & 7u) != 0u)
        ++rows;

    for (row = 0; row < rows; ++row) {
        volatile uint16_t *map = (volatile uint16_t *)map_address;
        uint32_t column;

        for (column = 0; column < columns; ++column) {
            uint16_t entry = map[column];

            if (entry == 0u) {
                uint16_t next_tile =
                    *(uint16_t *)(record + RECORD_NEXT_TILE);

                entry = next_tile;
                map[column] = entry;
                *(uint16_t *)(record + RECORD_NEXT_TILE) =
                    (uint16_t)(next_tile + 1u);
            }

            map[column] = (uint16_t)((entry & 0x0FFFu) |
                ((uint32_t)record[RECORD_PALETTE_BANK] << 12));
        }

        map_address += MAP_COLUMNS * MAP_ENTRY_BYTES;
    }
}

/* 0x0805B440. The descriptor, metric table, map allocation cursor, and
 * palette fields are the observed record layout. The indexed source-table
 * path and calls to the recovered 4bpp compositor support the glyph name;
 * language-specific control-byte meanings remain unknown. */
int32_t RuntimeDisplay_DrawGlyphSequence(void *display_record,
                                         int32_t x, uint32_t y,
                                         const uint8_t *sequence,
                                         uint32_t alignment_mode)
{
    uint8_t *record = (uint8_t *)display_record;
    const uint8_t *owner = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(record + RECORD_OWNER);
    const uint8_t *descriptor = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(record + RECORD_GLYPH_DESCRIPTOR);
    uint32_t metric;
    uint32_t initial_tile;
    uint32_t final_tile;
    uintptr_t tile_base;
    uintptr_t map_base;
    uintptr_t background_control;

    tile_base = (uintptr_t)GBA_VRAM +
        ((uintptr_t)owner[OWNER_CHARACTER_BLOCK] <<
         CHARACTER_BLOCK_SHIFT);
    map_base = (uintptr_t)GBA_VRAM +
        ((uintptr_t)owner[OWNER_MAP_BLOCK] << MAP_BLOCK_SHIFT);

    background_control = ChildResource_BackgroundControlRegister(
        owner[OWNER_BACKGROUND]);
    if (((*(volatile const uint16_t *)background_control & 0x0080u) == 0u) ||
        ((record[RECORD_PALETTE_BANK] & 1u) != 0u)) {
        /* The ROM calls this return-only entry on the same conditional path. */
        sub_08057B60((const void *)SEQUENCE_BACKGROUND_DISPATCH_MESSAGE);
    }

    metric = RuntimeDisplaySequence_GetMetric(record, descriptor, sequence);
    switch ((uint8_t)alignment_mode & 3u) {
    case 1:
        x = (int32_t)((uint32_t)x - metric);
        break;
    case 2:
        /* Thumb LSR at 0x0805B4DC is a logical, not arithmetic, shift. */
        x = (int32_t)((uint32_t)x - (metric >> 1));
        break;
    default:
        break;
    }

    initial_tile = *(uint16_t *)(record + RECORD_NEXT_TILE);
    RuntimeDisplaySequence_ReserveMapTiles(record, owner, descriptor,
                                           x, y, metric);
    final_tile = *(uint16_t *)(record + RECORD_NEXT_TILE);

    if (final_tile != initial_tile) {
        uintptr_t destination = tile_base +
            ((uintptr_t)initial_tile << 5);
        uint32_t byte_count = (final_tile - initial_tile) << 5;

        RuntimeDisplay_InvokeInstalledBackgroundOperation(
            0, (void *)destination, byte_count);
    }

    while (*sequence != 0u) {
        uint8_t character = *sequence;
        uint32_t advance = SPACE_ADVANCE;

        if (character > SPACE_CHARACTER) {
            const uint8_t *table =
                (const uint8_t *)SEQUENCE_GLYPH_INDEX_TABLE;
            uint32_t glyph_index = table[character];
            const uint8_t *glyph = RuntimeDisplaySequence_GetGlyphSource(
                descriptor, glyph_index);
            uint32_t table_offset =
                *(const uint32_t *)(record + RECORD_METRIC_TABLE_OFFSET);
            uint32_t glyph_rows =
                descriptor[DESCRIPTOR_GLYPH_HEIGHT] >> 3;
            uint32_t glyph_columns =
                descriptor[DESCRIPTOR_GLYPH_WIDTH] >> 3;
            uint32_t row;

            advance = descriptor[DESCRIPTOR_GLYPH_WIDTH];
            if (table_offset != 0u)
                advance -= table[table_offset + glyph_index];

            for (row = 0; row < glyph_rows; ++row) {
                uint32_t column;
                uint32_t glyph_y = y + (row << 3);

                for (column = 0; column < glyph_columns; ++column) {
                    int32_t glyph_x = RuntimeDisplaySequence_AddWrapped(
                        x, column << 3);
                    uintptr_t map_cell = map_base +
                        ((uintptr_t)(glyph_y & ~7u) << 3) +
                        ((uintptr_t)((uint32_t)glyph_x >> 3) << 1);

                    RuntimeDisplay_BlitIndexed4bppTile(
                        (const uint16_t *)map_cell, (uint8_t *)tile_base,
                        (const uint32_t *)glyph, glyph_x, glyph_y);
                    glyph += TILE_BYTES;
                }
            }
        }

        x = RuntimeDisplaySequence_AddWrapped(x, advance);
        if (x > 239)
            break;
        ++sequence;
    }

    return x;
}
