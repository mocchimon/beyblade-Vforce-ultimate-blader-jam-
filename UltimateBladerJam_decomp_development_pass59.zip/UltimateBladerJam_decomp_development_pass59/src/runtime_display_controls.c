#include <stdint.h>

#include "child_resource_helpers.h"
#include "gba.h"
#include "runtime_display.h"

static void RuntimeDisplay_WriteControlAtAddress(uintptr_t address,
                                                uint32_t value)
{
    volatile uint8_t *control = (volatile uint8_t *)address;
    uint8_t old_value = *control;
    uint8_t new_value = (uint8_t)((old_value & 0xFCu) |
                                  ((uint8_t)value & 3u));

    *control = new_value;
}

/* 0x08059C3C. Replaces the low two bits in the four BGxCNT registers while
 * retaining their other low-byte fields. Each argument is truncated to its
 * low two bits, as in the ROM. */
void RuntimeDisplay_SetAllBackgroundControlLowBits(uint32_t background0,
                                                    uint32_t background1,
                                                    uint32_t background2,
                                                    uint32_t background3)
{
    const uint32_t values[4] = {
        (uint8_t)background0,
        (uint8_t)background1,
        (uint8_t)background2,
        (uint8_t)background3,
    };
    uint32_t background;

    for (background = 0; background < 4; ++background) {
        uintptr_t address =
            ChildResource_BackgroundControlRegister(background);

        RuntimeDisplay_WriteControlAtAddress(address, values[background]);
    }
}

/* 0x08059CD8. Selects the BGxCNT register using the record's byte at +0x5E
 * and returns the low two bits read from that register. */
uint32_t RuntimeDisplay_GetRecordBackgroundControlLowBits(const void *record)
{
    const uint8_t *bytes = (const uint8_t *)record;
    uintptr_t address =
        ChildResource_BackgroundControlRegister(bytes[0x5E]);
    const volatile uint8_t *control = (const volatile uint8_t *)address;

    return (uint32_t)(*control & 3u);
}

/* 0x08059CEC. The ROM truncates both arguments to a byte before selecting the
 * BGxCNT register and replacing its low two bits. */
void RuntimeDisplay_SetBackgroundControlLowBits(uint32_t background,
                                                 uint32_t value)
{
    uintptr_t address =
        ChildResource_BackgroundControlRegister((uint8_t)background);

    RuntimeDisplay_WriteControlAtAddress(address, (uint8_t)value);
}

/* 0x08059D14. Returns the low two bits from the selected BGxCNT register. */
uint32_t RuntimeDisplay_GetBackgroundControlLowBits(uint32_t background)
{
    uintptr_t address =
        ChildResource_BackgroundControlRegister((uint8_t)background);
    const volatile uint8_t *control = (const volatile uint8_t *)address;

    return (uint32_t)(*control & 3u);
}

/* 0x08059D28. Sets or clears the selected background's bit in DISPCNT. The
 * ROM ignores background indices above three and treats any nonzero low byte
 * of `enabled` as true. */
void RuntimeDisplay_SetBackgroundEnabled(uint32_t background,
                                         uint32_t enabled)
{
    uint8_t index = (uint8_t)background;
    uint8_t state = (uint8_t)enabled;
    uint16_t mask;

    if (index > 3u)
        return;

    mask = (uint16_t)(0x0100u << index);
    if (state != 0u)
        REG_DISPCNT |= mask;
    else
        REG_DISPCNT &= (uint16_t)~mask;
}
