#include "runtime.h"
#include <stdint.h>

/* 0x08063A74 */
void Input_ResetMappings(void)
{
    volatile uint8_t *table = (volatile uint8_t *)0x03005E80u;
    for (int i = 0x14; i >= 0; --i)
        table[i] = 0;
}

/* 0x08063A8C */
void Input_SetMapping(uint32_t index, uint32_t value)
{
    if (index <= 0x14)
        ((volatile uint8_t *)0x03005E80u)[index] = (uint8_t)value;
}

/* 0x08063AA0 */
void Input_SetState(uint32_t state)
{
    *(volatile uint32_t *)0x03005E98u = state;
}

/*
 * 0x080517A4. ROM-faithful access path: the runtime base pointer at
 * 0x03000F48 plus 0x6B4. This may resolve to the same effective address as
 * 0x03005E98 in the initialized runtime, but the ROM routine uses the
 * indirection and offset rather than embedding 0x03005E98 directly.
 */
uint32_t Input_TestMask(uint32_t mask)
{
    volatile uint32_t *runtime_base =
        (volatile uint32_t *)(*(volatile uint32_t *)0x03000F48u);
    return runtime_base[0x6B4u / sizeof(uint32_t)] & mask;
}
