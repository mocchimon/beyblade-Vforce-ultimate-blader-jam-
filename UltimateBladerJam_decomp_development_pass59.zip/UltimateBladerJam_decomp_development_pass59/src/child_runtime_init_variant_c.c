#include <stdint.h>

#include "child_resource_helpers.h"
#include "child_runtime.h"
#include "runtime_display.h"

enum {
    CHILD_NESTED_RECORD = 0x08,
    CHILD_MEMORY_CURSOR = 0x5C,
    CHILD_MEMORY_BLOCK = 0x5D,
    CHILD_INDEX = 0x5E,
    CHILD_LAYOUT_X_BITS = 0x5F,
    CHILD_LAYOUT_Y_BITS = 0x60,
    CHILD_LAYOUT_LENGTH = 0x74,
    CHILD_LAYOUT_MODE_FLAG = 0x80,
};

#define NESTED_RECORD_TABLE ((uintptr_t)0x03000CA0u)
#define BACKGROUND_MEMORY_INDEX ((uintptr_t)0x03000DE0u)
#define BACKGROUND_MEMORY_REMAINING ((uintptr_t)0x03000E3Cu)
#define GBA_VRAM_BASE ((uintptr_t)0x06000000u)
enum {
    VRAM_BLOCK_SHIFT = 14,
    VRAM_CURSOR_SHIFT = 11,
};

/* 0x08058C98. Initializes the display state for a child that owns a
 * background-memory allocation instead of an external resource record.
 * The argument names stay neutral: ROM evidence establishes the truncation,
 * shifts and fields, but not the higher-level asset vocabulary. */
void ChildRuntime_InitVariantC(void *child, uint32_t index,
                               uint32_t dimension_value,
                               uint32_t layout_control)
{
    uint8_t *c = (uint8_t *)child;
    uint8_t child_index = (uint8_t)index;
    uint16_t control = (uint16_t)layout_control;
    uint32_t layout_length;
    uint32_t allocation_length;
    uint32_t preceding_blocks;
    uint32_t gap_in_block;
    uint32_t nested;
    uint32_t layout_cursor_units;
    uint32_t cursor_adjustment;
    uint32_t current_block;
    uint8_t available;
    uint8_t candidate_cursor;
    uintptr_t destination;
    uintptr_t bg_control;

    *(uint32_t *)(c + 0x68) = 0;
    *(uint16_t *)(c + 0x64) = 0;
    layout_length = ChildResource_SelectLayout(child, control, 0);

    nested = (uint32_t)(child_index * 0x18u) +
             *(volatile const uint32_t *)NESTED_RECORD_TABLE;
    *(uint32_t *)(c + CHILD_NESTED_RECORD) = nested;
    *(uint32_t *)(nested + 0x10) = 0;
    *(uint32_t *)(nested + 0x14) = 0;
    *(uint32_t *)nested = 0;
    *(uint32_t *)(nested + 0x08) =
        (1u << c[CHILD_LAYOUT_X_BITS]) - 1u;
    *(uint32_t *)(nested + 0x04) = 0;
    *(uint32_t *)(nested + 0x0C) =
        (1u << c[CHILD_LAYOUT_Y_BITS]) - 1u;

    *(uint32_t *)c = 0x20;
    *(uint32_t *)(c + 0x04) = 0x20;
    c[CHILD_INDEX] = child_index;
    *(uint32_t *)(c + 0x0C) = 0;
    *(uint32_t *)(c + 0x10) = 0;
    *(uint32_t *)(c + 0x14) = 0;
    *(uint32_t *)(c + 0x18) = 0;
    *(uint32_t *)(c + 0x1C) = 0;
    *(uint32_t *)(c + 0x20) = 0;
    *(uint32_t *)(c + 0x54) = 0;
    *(uint32_t *)(c + 0x58) = 0;
    *(uint32_t *)(c + 0x24) = 0x10;
    *(uint32_t *)(c + 0x40) = 0;
    *(uint32_t *)(c + 0x44) = 0;
    *(uint32_t *)(c + 0x28) = 0;
    *(uint32_t *)(c + 0x2C) = 0;
    *(uint32_t *)(c + 0x30) = 0x10000;
    *(uint32_t *)(c + 0x34) = 0x10000;
    *(uint32_t *)(c + 0x38) = 0;
    *(uint32_t *)(c + 0x3C) = 0;
    *(uint16_t *)(c + 0x48) = 0;
    *(uint16_t *)(c + 0x4A) = 0;
    *(uint32_t *)(c + 0x4C) = 0;
    *(uint32_t *)(c + 0x50) = 0;
    c[0x7C] = 0;
    *(int32_t *)(c + 0x80) = -1;
    *(uint32_t *)(c + 0x84) = 0;
    *(uint32_t *)(c + 0x6C) = 0;
    *(uint32_t *)(c + 0x70) = 0;
    *(uint32_t *)(c + 0x78) = 0;

    allocation_length = (uint16_t)dimension_value;
    allocation_length <<= (control & CHILD_LAYOUT_MODE_FLAG) ? 6 : 5;
    *(uint32_t *)(c + CHILD_LAYOUT_LENGTH) = allocation_length;
    preceding_blocks = (allocation_length - 1u) >> VRAM_BLOCK_SHIFT;
    current_block = *(volatile const uint8_t *)BACKGROUND_MEMORY_INDEX;
    c[CHILD_MEMORY_BLOCK] = (uint8_t)current_block;
    if (allocation_length != 0) {
        *(volatile uint8_t *)BACKGROUND_MEMORY_INDEX =
            (uint8_t)(current_block + preceding_blocks + 1u);
    } else {
        c[CHILD_MEMORY_BLOCK] = 0;
    }

    gap_in_block = ((preceding_blocks + 1u) << VRAM_BLOCK_SHIFT) -
                   allocation_length;
    if (allocation_length != 0 && gap_in_block >= layout_length) {
        layout_cursor_units = layout_length >> VRAM_CURSOR_SHIFT;
        cursor_adjustment = layout_cursor_units;
        if (cursor_adjustment == 0)
            cursor_adjustment = 1;
        available = *(volatile const uint8_t *)BACKGROUND_MEMORY_REMAINING;
        available = (uint8_t)(available - layout_cursor_units);
        candidate_cursor = (uint8_t)(
            (*(volatile const uint8_t *)BACKGROUND_MEMORY_INDEX << 3) -
            cursor_adjustment);
        c[CHILD_MEMORY_CURSOR] = candidate_cursor;
        if (candidate_cursor >= available) {
            *(volatile uint8_t *)BACKGROUND_MEMORY_REMAINING = available;
            c[CHILD_MEMORY_CURSOR] = available;
        }
    } else {
        available = *(volatile const uint8_t *)BACKGROUND_MEMORY_REMAINING;
        available = (uint8_t)(available -
                              (allocation_length >> VRAM_CURSOR_SHIFT));
        *(volatile uint8_t *)BACKGROUND_MEMORY_REMAINING = available;
        c[CHILD_MEMORY_CURSOR] = available;
    }

    destination = GBA_VRAM_BASE +
                  ((uintptr_t)c[CHILD_MEMORY_CURSOR] << VRAM_CURSOR_SHIFT);
    RuntimeDisplay_InvokeInstalledBackgroundOperation(
        0, (void *)destination, layout_length);

    bg_control = ChildResource_BackgroundControlRegister(child_index);
    *(volatile uint16_t *)bg_control =
        (uint16_t)(((uint16_t)c[CHILD_MEMORY_CURSOR] << 8) | control |
                   ((uint16_t)c[CHILD_MEMORY_BLOCK] << 2));
}
