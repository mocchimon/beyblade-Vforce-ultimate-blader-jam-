#include "collision_data_spline.h"

#include "runtime.h"

enum {
    COLLISION_RECORD_SOURCE = 0x00,
    COLLISION_RECORD_OFFSET_10 = 0x04,
    COLLISION_RECORD_SPLINE_BASE = 0x08,
    COLLISION_RECORD_OFFSET_18 = 0x0C,
    COLLISION_RECORD_STATE = 0x10,
    COLLISION_RECORD_SPLINE_POINTERS = 0x14,
    COLLISION_RECORD_TRAILING_STATE = 0x114,
    COLLISION_RECORD_SPLINE_COUNT_STATE = 0x230,
    COLLISION_SOURCE_SPLINE_COUNT = 0x04,
    COLLISION_SOURCE_OFFSET_10 = 0x10,
    COLLISION_SOURCE_OFFSET_14 = 0x14,
    COLLISION_SOURCE_OFFSET_18 = 0x18,
    COLLISION_SPLINE_LIMIT = 64,
    COLLISION_SPLINE_LIMIT_MESSAGE = 0x087553F4
};

/* 0x0805B8E8. The source stores relative offsets at +0x10/+0x14/+0x18;
 * the record keeps their resolved addresses. Its spline list is packed, with
 * each entry's byte stride at entry+4. The diagnostic is a ROM-confirmed
 * return-only service, so the count is still capped after it returns. */
void CollisionData_BuildSplineIndex(void *collision_record,
                                    const void *collision_source)
{
    uint8_t *record = (uint8_t *)collision_record;
    const uint8_t *source = (const uint8_t *)collision_source;
    int16_t spline_count =
        *(const int16_t *)(source + COLLISION_SOURCE_SPLINE_COUNT);
    int32_t index;
    uintptr_t source_address = (uintptr_t)source;

    *(uint32_t *)(record + COLLISION_RECORD_SOURCE) =
        (uint32_t)source_address;
    *(uint32_t *)(record + COLLISION_RECORD_OFFSET_10) =
        (uint32_t)(source_address +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_10));
    *(uint32_t *)(record + COLLISION_RECORD_SPLINE_BASE) =
        (uint32_t)(source_address +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_14));
    *(uint32_t *)(record + COLLISION_RECORD_OFFSET_18) =
        (uint32_t)(source_address +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_18));

    if (spline_count > COLLISION_SPLINE_LIMIT) {
        sub_08057B60((const void *)(uintptr_t)
            COLLISION_SPLINE_LIMIT_MESSAGE);
        spline_count = COLLISION_SPLINE_LIMIT;
    }

    for (index = 0; index < spline_count; ++index) {
        uint32_t pointer_offset = COLLISION_RECORD_SPLINE_POINTERS +
            ((uint32_t)index << 2);
        void *spline = CollisionData_GetSplineByIndex(
            record, (uint32_t)index);

        *(uint32_t *)(record + pointer_offset) =
            (uint32_t)(uintptr_t)spline;
    }

    *(uint32_t *)(record + COLLISION_RECORD_TRAILING_STATE) = 0;
    *(uint32_t *)(record + COLLISION_RECORD_STATE) = 0;
    *(uint16_t *)(record + COLLISION_RECORD_SPLINE_COUNT_STATE) = 0;
}

/* 0x0805DBA4. Walks the packed spline entries until the requested index is
 * found or the source count is exhausted. The stride is read from entry+4. */
void *CollisionData_GetSplineByIndex(const void *collision_record,
                                     uint32_t index)
{
    const uint8_t *record = (const uint8_t *)collision_record;
    const uint8_t *source = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(record + COLLISION_RECORD_SOURCE);
    const uint8_t *spline = (const uint8_t *)(uintptr_t)
        *(const uint32_t *)(record + COLLISION_RECORD_SPLINE_BASE);
    int32_t count = *(const int32_t *)(source + COLLISION_SOURCE_SPLINE_COUNT);
    int32_t current;

    for (current = 0; current < count; ++current) {
        if ((uint32_t)current == index)
            return (void *)spline;

        spline = (const uint8_t *)((uintptr_t)spline +
            *(const uint32_t *)(spline + sizeof(uint32_t)));
    }

    return 0;
}


/*
 * 0x0805B95C. Builds the same relative-pointer header as
 * CollisionData_BuildSplineIndex, then conditionally allocates an owned block
 * and routes each selected segment through the installed callback at 0x0807D998.
 *
 * The callback implementation is not present at this call site. Keep the
 * operation generic: flags bit 0 selects the source word at +0 (scaled by 16),
 * and bit 1 selects the source word at +8 (scaled by 32). The original routine
 * stores the 16-bit flags at record+0x118 and retains the allocator result at
 * record+0x10. Its subsequent spline-cache construction is instruction-for-
 * instruction equivalent in shape to the independently recovered helper.
 */
void CollisionData_InitializeOwnedSegments(void *collision_record,
                                           const void *collision_source,
                                           uint32_t flags)
{
    typedef void (*InstalledCopyOperation)(const void *source,
                                           void *destination,
                                           uint32_t byte_count);
    uint8_t *record = (uint8_t *)collision_record;
    const uint8_t *source = (const uint8_t *)collision_source;
    uint16_t selected_flags = (uint16_t)flags;
    uint32_t segment0_size = *(const uint32_t *)(source + 0x00) << 4;
    uint32_t segment1_size = *(const uint32_t *)(source + 0x08) << 5;
    uint32_t allocation_size = 0;
    uint8_t *destination_cursor;
    void *allocation;
    int16_t spline_count =
        *(const int16_t *)(source + COLLISION_SOURCE_SPLINE_COUNT);
    int32_t index;

    *(uint32_t *)(record + COLLISION_RECORD_SOURCE) =
        (uint32_t)(uintptr_t)source;
    *(uint32_t *)(record + COLLISION_RECORD_OFFSET_10) =
        (uint32_t)((uintptr_t)source +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_10));
    *(uint32_t *)(record + COLLISION_RECORD_SPLINE_BASE) =
        (uint32_t)((uintptr_t)source +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_14));
    *(uint32_t *)(record + COLLISION_RECORD_OFFSET_18) =
        (uint32_t)((uintptr_t)source +
            *(const uint32_t *)(source + COLLISION_SOURCE_OFFSET_18));
    *(uint16_t *)(record + 0x118) = selected_flags;

    if ((selected_flags & 1u) != 0)
        allocation_size += segment0_size;
    if ((selected_flags & 2u) != 0)
        allocation_size += segment1_size;

    allocation = allocation_size != 0 ? Heap_AllocAlt(allocation_size) : 0;
    *(void **)(record + 0x10) = allocation;

    /* The ROM emits the diagnostic when the result is null, including the
     * zero-size path. The service's visible effects are not recovered. */
    if (allocation == 0)
        sub_08057C5C((const void *)(uintptr_t)0x08755430u,
                     allocation_size);

    destination_cursor = (uint8_t *)allocation;
    if (allocation != 0) {
        if ((selected_flags & 1u) != 0) {
            InstalledCopyOperation operation =
                (InstalledCopyOperation)(uintptr_t)
                    *(volatile const uint32_t *)(uintptr_t)0x0807D998u;
            operation((const void *)(uintptr_t)
                          *(const uint32_t *)(record + 0x04),
                      destination_cursor, segment0_size);
            *(uint32_t *)(record + 0x04) =
                (uint32_t)(uintptr_t)destination_cursor;
            destination_cursor += segment0_size;
        }
        if ((selected_flags & 2u) != 0) {
            InstalledCopyOperation operation =
                (InstalledCopyOperation)(uintptr_t)
                    *(volatile const uint32_t *)(uintptr_t)0x0807D998u;
            operation((const void *)(uintptr_t)
                          *(const uint32_t *)(record + 0x0C),
                      destination_cursor, segment1_size);
            *(uint32_t *)(record + 0x0C) =
                (uint32_t)(uintptr_t)destination_cursor;
        }
    }

    if (spline_count > COLLISION_SPLINE_LIMIT) {
        sub_08057B60((const void *)(uintptr_t)
            COLLISION_SPLINE_LIMIT_MESSAGE);
        spline_count = COLLISION_SPLINE_LIMIT;
    }

    for (index = 0; index < spline_count; ++index) {
        uint32_t pointer_offset = COLLISION_RECORD_SPLINE_POINTERS +
            ((uint32_t)index << 2);
        void *spline = CollisionData_GetSplineByIndex(
            record, (uint32_t)index);
        *(uint32_t *)(record + pointer_offset) =
            (uint32_t)(uintptr_t)spline;
    }

    *(uint32_t *)(record + COLLISION_RECORD_TRAILING_STATE) = 0;
}
