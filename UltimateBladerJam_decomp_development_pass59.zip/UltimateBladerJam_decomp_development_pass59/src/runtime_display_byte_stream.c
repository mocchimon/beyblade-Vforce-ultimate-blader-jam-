#include "runtime_display_byte_stream.h"

#include "runtime_display_sequence.h"

enum {
    RECORD_STREAM_PALETTE = 0x0C,
    RECORD_STREAM_LINE_STEP = 0x0D,
    STREAM_CONTROL_LINE_STEP = 0xFB,
    STREAM_CONTROL_PALETTE = 0xFC,
    STREAM_CONTROL_END = 0xFF,
    STREAM_LINE_FEED = 0x0A,
    STREAM_SCRATCH_BYTES = 64
};

/* 0x0805B824. The stack frame reserves 0x44 bytes and the temporary string
 * starts at SP+4, leaving 64 bytes for the buffered span. The ROM performs
 * no explicit length check, so this source model likewise assumes the game
 * stream fits that observed scratch area. */
void RuntimeDisplay_ProcessByteStream(void *display_record,
                                      int32_t start_x, int32_t start_y,
                                      const uint8_t *stream,
                                      uint32_t alignment_mode)
{
    uint8_t *record = (uint8_t *)display_record;
    uint8_t span[STREAM_SCRATCH_BYTES];
    uint32_t span_length = 0;
    uint8_t mode = (uint8_t)alignment_mode;
    int32_t origin_x = (int16_t)start_x;
    int32_t x = origin_x;
    int32_t y = (int16_t)start_y;

    /* The entry has an early empty-string return; later NUL bytes flush. */
    if (stream == 0 || *stream == 0)
        return;

    for (;;) {
        uint8_t value = *stream++;

        if (value == STREAM_CONTROL_LINE_STEP) {
            record[RECORD_STREAM_LINE_STEP] = *stream++;
            continue;
        }

        if (value == STREAM_CONTROL_PALETTE) {
            span[span_length] = 0;
            x = RuntimeDisplay_DrawGlyphSequence(
                record, x, (uint32_t)y, span, mode);
            record[RECORD_STREAM_PALETTE] = *stream++;
            span_length = 0;
            continue;
        }

        if (value == 0 || value == STREAM_CONTROL_END) {
            span[span_length] = 0;
            (void)RuntimeDisplay_DrawGlyphSequence(
                record, x, (uint32_t)y, span, mode);
            return;
        }

        if (value == STREAM_LINE_FEED) {
            span[span_length] = 0;
            (void)RuntimeDisplay_DrawGlyphSequence(
                record, x, (uint32_t)y, span, mode);
            span_length = 0;
            x = origin_x;
            y += record[RECORD_STREAM_LINE_STEP];
            continue;
        }

        /* Bytes 0xFD and 0xFE follow the ordinary glyph-byte path. */
        span[span_length++] = value;
    }
}
