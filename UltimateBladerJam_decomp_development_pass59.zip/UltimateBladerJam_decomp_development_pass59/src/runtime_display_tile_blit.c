#include <stdint.h>

#include "runtime_display_state.h"
#include "runtime_display_tile_blit.h"

/* 0x0805B2A4. Each source word contains one 8-pixel 4bpp row. The function
 * shifts that 8x8 block by the pixel remainders and ORs its fragments into
 * as many as four map-selected 32-byte destination tiles. */
void RuntimeDisplay_BlitIndexed4bppTile(const uint16_t *map_cell,
                                        uint8_t *tile_base,
                                        const uint32_t *source_rows,
                                        int32_t x, uint32_t y)
{
    uint8_t *top_left;
    uint8_t *top_right;
    uint8_t *bottom_left;
    uint8_t *bottom_right;
    uint32_t x_remainder;
    uint32_t y_remainder;
    uint32_t x_shift;
    int32_t tile_x;
    uint32_t source_row;

    /* The ROM accepts x values from -7 through 239 and y values 0 through
     * 152. Unsigned addition preserves the original left-edge clipping test. */
    if ((uint32_t)x + 7u > 246u || y > 152u)
        return;

    top_left = RuntimeDisplayState_GetIndexedBlockAddress(
        tile_base, map_cell[0]);
    top_right = RuntimeDisplayState_GetIndexedBlockAddress(
        tile_base, map_cell[1]);
    bottom_left = RuntimeDisplayState_GetIndexedBlockAddress(
        tile_base, map_cell[32]);
    bottom_right = RuntimeDisplayState_GetIndexedBlockAddress(
        tile_base, map_cell[33]);

    x_remainder = (uint32_t)x & 7u;
    y_remainder = y & 7u;
    x_shift = x_remainder << 2;
    /* The only negative x coordinates that pass the ROM guard are -7..-1. */
    tile_x = x < 0 ? -1 : x / 8;

    for (source_row = 0; source_row < 8u; ++source_row) {
        uint32_t destination_row = source_row + y_remainder;
        uint8_t *left_tile;
        uint8_t *right_tile;
        uint32_t *left_word;
        uint32_t *right_word;
        uint32_t pixels = source_rows[source_row];
        uint32_t left_pixels = pixels << x_shift;
        uint32_t right_pixels = x_shift == 0u
            ? 0u : pixels >> (32u - x_shift);

        if (destination_row < 8u) {
            left_tile = top_left;
            right_tile = top_right;
        } else {
            destination_row -= 8u;
            left_tile = bottom_left;
            right_tile = bottom_right;
        }

        left_word = (uint32_t *)(left_tile + (destination_row << 2));
        right_word = (uint32_t *)(right_tile + (destination_row << 2));

        if (tile_x >= 0)
            *left_word |= left_pixels;
        if (tile_x <= 28)
            *right_word |= right_pixels;
    }
}
