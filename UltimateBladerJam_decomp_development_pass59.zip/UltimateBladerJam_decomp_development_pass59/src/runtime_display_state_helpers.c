#include <stdint.h>

#include "runtime_display_state.h"

/* 0x0805B284. The order below follows the observed stores; field names remain
 * offset-based because the wider owner of this record is not recovered. */
void RuntimeDisplayState_SetFields_0805B284(void *record, uint32_t field_08,
                                            uint32_t field_04,
                                            uint32_t field_0C)
{
    uint8_t *r = (uint8_t *)record;

    *(uint32_t *)(r + 0x08) = field_08;
    r[0x0C] = (uint8_t)field_0C;
    *(uint32_t *)(r + 0x04) = field_04;
}

/* 0x0805B28C. */
void RuntimeDisplayState_SetByteAtOffset0D(void *record, uint32_t value)
{
    ((uint8_t *)record)[0x0D] = (uint8_t)value;
}

/* 0x0805B290. */
void RuntimeDisplayState_SetByteAtOffset0C(void *record, uint32_t value)
{
    ((uint8_t *)record)[0x0C] = (uint8_t)value;
}

/* 0x0805B294. The four observed call sites pass the same base and four
 * halfword indices; the high six index bits are discarded by the ROM. */
uint8_t *RuntimeDisplayState_GetIndexedBlockAddress(uint8_t *base,
                                                    uint32_t index)
{
    return base + ((index & 0x03FFu) << 5);
}
