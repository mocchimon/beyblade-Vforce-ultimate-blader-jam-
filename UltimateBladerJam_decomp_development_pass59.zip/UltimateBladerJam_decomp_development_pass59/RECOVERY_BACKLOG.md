## Pass 41 findings

The known ARM image `[0x080641B8, 0x08064EDC)` is `0xD24` bytes. If it were
mapped at the hypothetical base `0x030061B8`, `0x03006FAC` and `0x03007034`
would lie `0xD0` and `0x158` bytes beyond it. The base remains unproven; this
only eliminates that image/base pairing as the source of those two targets.
See `docs/PASS41_DEVELOPMENT_2026-10-20.md` and
`tools/audit_runtime_image_bounds.py`.

# Unresolved linkage recovery backlog

Generate the current inventory with `make triage-unresolved`; its machine-
readable report is written to `build/reports/unresolved_triage.json`. Build
reports are regenerated artifacts and are not included in this source archive.
This is an inventory, **not** ROM matching.

## Pass 40 findings

The callback slot `0x0807D998` contains the ARM IWRAM target `0x03007034`. The
row-copy caller at `0x08063210` and collision-segment caller at `0x0805B95C`
share a verified `(source, destination, byte_count)` contract via `0x08065C44`.
The callback implementation/installer remains open. Matching ROM is still
blocked by fixed layout, original toolchain/codegen, and unrecovered code/data;
see `docs/PASS40_DEVELOPMENT_2026-10-20.md` and `docs/MATCHING_ROM_PLAN.md`.

## Prioritization

1. **Address-named game routines:** inspect `sub_08...` callers in a freshly
   generated linkage report, then compare against original ROM disassembly.
   Assembly filename hits are only filename clues, not proof of function identity.
   `RuntimeObject_UpdateRecordArray` (`0x08050A74`) and
   `RuntimeObject_UpdateRecord` (`0x08058F18`) now replace the address-named
   gap in the caller at `0x080494F4`; exact local call targets are checked by
   `make verify-runtime-object-records ROM=...`. `RuntimeObject_InitializeEntryTable`
   (`0x08050AA0`) and the byte lookup at `0x08063AC4` are also recovered and
   checked by `make verify-runtime-object-selection ROM=...`. The builder's
   callees at `0x080609E8`, `0x08060A04`, `0x08060B8C`, and `0x080611B4` now
   have source definitions. Check them with
   `make verify-resource-node-selection ROM=...`. The wrapper at
   `0x08061684` now has a source definition, and `0x080614E0` is now recovered
   as `RuntimeObjectSelection_Finalize`, and `0x08061260` is now recovered as
   `RuntimeObjectSelection_ApplyLayout`. Resource-node allocation and
   resizing at `0x08060C40` and `0x08060DBC` are source-defined and checked by
   `make verify-resource-node-chain-ops ROM=...`. The embedded-subcontext
   release at `0x08060D00` is `ResourceNode_ReleaseChain`, checked by
   `make verify-resource-node-release-chain ROM=...`. The packed-field helpers
   at `0x08061154`, `0x08061170`, `0x0806117C`, `0x08061184`, and `0x0806118C`
   are source-defined and checked by `make verify-runtime-object-dispatch ROM=...`.
   The finalizer's code counter at `0x08064F5C` is also source-defined. Its
   instructions and call edges are checked by
   `make verify-runtime-object-selection-finalize ROM=...`.
   The layout loop and its flags wrapper are checked by
   `make verify-runtime-object-selection-layout ROM=...`.
   `0x08058F84` is now source-defined as `RuntimeObject_ApplyRecordTransform`.
   Its affine-table builder and GBA register helpers at `0x08059B24`,
   `0x08059A8C`, `0x08059ADC`, and `0x08059FC4` are also source-defined and
   checked by `make verify-runtime-object-record-transform ROM=...`.
   The other updater callee, `0x080596D0`, is now
   `RuntimeObject_UpdateDisplayRegion`; its frame wrapper and BG register
   selectors are checked by `make verify-runtime-object-display-region ROM=...`.
   The adjacent display-state initializer at `0x08059958` and record mask
   helper at `0x080599B8` are source-defined and checked by
   `make verify-runtime-object-display-init ROM=...`. The initializer's three
   direct caller bodies remain unrecovered; the flags helper has no known
   direct caller. The three state-byte meanings remain address-based.
   BG control access at `0x08059C3C`, `0x08059CD8`, `0x08059CEC`,
   `0x08059D14`, and `0x08059D28` is now source-defined and checked by
   `make verify-runtime-display-controls ROM=...`. The record-based wrappers
   at `0x0804A7EC` and `0x0804A7FC` are now source-defined and checked by
   `make verify-runtime-background-dispatch ROM=...`; the latter preserves the
   indirect call through the Thumb `BX r3` trampoline at `0x08065C44` to the
   even IWRAM pointer stored at `0x0807D994`. `ChildRuntime_InitVariantC`
   (`0x08058C98`) is now source-defined with its nested-record initialization,
   background-memory cursor updates, indirect operation dispatch, and BGxCNT
   write checked by `make verify-child-runtime-init-variant-c ROM=...`. The
   callback's behavior remains unresolved. Three display-control caller bodies
   remain open, including the larger caller at `0x0804A748`; its caller-side
   ABI remains open even though its argument setup for `0x08058C98` is verified.
   No direct ROM caller was found for the standalone BG control reader at
   `0x08059D14`.
   The adjacent record initializer at `0x0805B268` is now source-defined and
   its only observed direct call setup is checked by
   `make verify-runtime-display-state-record ROM=...`.
   The neighboring setters and indexed-address helper at `0x0805B284`–
   `0x0805B294` are now source-defined. Their four direct call edges and mask
   literal are checked by `make verify-runtime-display-state-helpers ROM=...`;
   the containing routine at `0x0805B2A4` is now source-defined as a
   map-indexed 8x8 packed-pixel compositor. Its full body, caller setup,
   internal calls, and branch targets are checked by
   `make verify-runtime-display-tile-blit ROM=...`. The adjacent
   `0x0805B3B8` routine now has a conservative source implementation for its
   two dispatch argument sets and status store; verify it with
   `make verify-runtime-display-state-operations ROM=...`. Its incoming
   caller and the installed IWRAM operation remain unresolved. The adjacent
   sequence-metric helper at `0x0805B400` is now source-defined and checked by
   `make verify-runtime-display-metric ROM=...`. The caller at `0x0805B440` is
   now recovered as `RuntimeDisplay_DrawGlyphSequence`; its descriptor lookup
   helper, five call setups, map reservation, indexed tile lookup, and calls to
   the 4bpp compositor are checked by
   `make verify-runtime-display-sequence ROM=...`. The shared operation
   backend and language-specific control-byte meanings remain open.
   The containing byte-stream routine at `0x0805B824` is now recovered as
   `RuntimeDisplay_ProcessByteStream`, including its `0xFB`/`0xFC` control
   paths, newline behavior, and final flush. The entry has no direct Thumb
   `BL`/branch reference or stored Thumb pointer in the full-ROM scans, so
   identify its indirect dispatch or confirm whether it is reached through a
   code address before closing its incoming-linkage gap. Its record bytes
   `+0x0C/+0x0D` are tracked only by offset; semantic names remain open.
   The adjacent collision-data routines at `0x0805B8E8` and `0x0805DBA4` now
   have source definitions; the ROM scan found nine direct callers for each.
   The allocator/copy routine at `0x0805B95C` remains open: it allocates the
   collision block and reaches the installed callback at `0x0807D998` through
   the row-copy dispatch at `0x08065C44`. Recover that callback's installation
   and behavior before assigning semantics to the copy operation.
2. **Resource tables:** `ResourceTable_Generate`, `Transform`, and `Combine`
   form a missing group; verify input/output layout before implementing.
3. **Rasterizer:** `ArmRaster_ProcessPrimitiveEdges`, `ArmRaster_DrawRows`,
   `ArmRaster_ApplyVertexParameters`, `ArmRaster_TransformVertexRows`, and the two sample emitters now have C
   behavior reconstructions. Compare their output against rendering fixtures
   before assigning broader meaning, and recover the dynamic entry callers.
4. **Error and runtime services:** `ResourceNode_ValidateActiveList` and the
   record-manager diagnostics now bind to ROM-confirmed return-only entries.
   Former `FatalError` calls were also mapped to `sub_08057B60` or
   `sub_08057C5C`; keep auditing the unresolved-symbol report for remaining
   address-named helpers. `RuntimeRange_Release` has a C implementation.
5. **ARM/Thumb and ROM build:** regenerate ARM objects, run `make partial-link`,
   and recover the original section layout and toolchain before attempting a
   candidate `.gba`.

The source-level name mismatch at `0x08050388` is resolved:
`GameState_FramePrepare` calls `RuntimeRecord_Clear`, whose writes preserve
the alternate-heap descriptor at manager `+0x00`. The initializer and updater
at `0x08050398`/`0x08050420` now track the saved linked-list, descriptor/payload,
and boundary-handling behavior. The `0x08049268` source recovery
also now uses the disassembly-confirmed context base `0x03000650` and keeps the
separate object pointer at `0x03000FB0`. This is not an object-level
unresolved-symbol audit; that report still requires the unavailable object
build and symbol tools.

Do not invent behavior for unresolved functions to make a link succeed. The
return-only routines at `0x08057B60` and `0x08057C5C` were added only after
their ROM instructions confirmed no visible effects. The arithmetic,
resource-dispatch, and return-only service recoveries are documented in
`docs/PASS11_DEVELOPMENT_2026-10-15.md` and
`docs/EXTERNAL_NOOP_FINDINGS.md`; rasterizer work is in
`docs/ARM_RASTERIZER_PRIMITIVE_RECOVERY.md`. The historical 54% source-recovery
estimate remains unchanged and is not a measured coverage value. Current
rasterizer source and verification limits are recorded in
`docs/ARM_RASTERIZER_PRIMITIVE_RECOVERY.md` and
`docs/ARM_RASTERIZER_ROW_DRAWING_RECOVERY.md` and
`docs/ARM_RASTERIZER_VERTEX_PARAMETERS_RECOVERY.md` and
`docs/ARM_RASTERIZER_VERTEX_ROWS_RECOVERY.md`.

## Pass 42 findings

The mixed pointer table at `0x0807D920..0x0807D9A4` has a ROM-backed inventory
in `tools/audit_iwram_function_table.py`. It confirms the unresolved callback
at `0x03007034` sits between IWRAM entries `0x03006FAC`, `0x030070B8`, and
`0x0300711C`, with further IWRAM targets through `0x03007478`. This supports
investigating a shared runtime-code installation path, but does not prove that
the functions are contiguous or share one source image. Run
`make audit-iwram-function-table ROM=/path/to/original.gba` and see
`docs/PASS42_DEVELOPMENT_2026-10-20.md`. The callback body/installer remains
unresolved and matching-ROM progress remains 0% verified.

## Pass 43 findings

The new `tools/audit_iwram_install_candidates.py` scan found 23 Thumb
LDR-literal candidates in the supplied ROM (8 upper-IWRAM address literals and
15 DMA-register references). No direct literal-load reference to
`0x03007034` was found. This makes computed/descriptor-driven setup, BIOS
compression, or copied resource code the remaining hypotheses; none is proven.
Run `make audit-iwram-install-candidates ROM=...`; details are in
`docs/PASS43_DEVELOPMENT_2026-10-20.md`.

## Pass 44 findings

The direct Thumb-BL inventory found two callers of the `System_LZ77UnCompWram`
wrapper (`0x08055CA8`, `0x080572F8`), one caller of the startup IWRAM installer
(`0x080505B2`), one caller of the CpuSet wrapper, and three callers of the DMA3
transfer backend. The decompression destinations are loaded through runtime
fields; no connection to `0x03007034` is yet established. Use
`make audit-runtime-copy-paths ROM=...`; details and limitations are in
`docs/PASS44_DEVELOPMENT_2026-10-20.md`.

## Pass 45 findings

The ARM runtime image at `0x080641B8..0x08064EDC` is now checked by
`tools/audit_arm_runtime_module.py`. It validates the `0xD24`-byte image, the
32-word offset table at `0x08064EDC..0x08064F5C`, 29 loader-consumed slots, and
the 12 named routine offsets already supported by the function map. The table
value `0xD24` is a one-past-end pointer and is not treated as a function entry.
This tightens the known ARM-module evidence but does not identify the separate
IWRAM installer or callback at `0x03007034`. See
`docs/PASS45_DEVELOPMENT_2026-10-20.md`.

## Pass 46 findings

`0x08057968` is now fingerprinted as a small startup DMA3 setup routine. It
uses ROM source `0x08000168`, IWRAM destination `0x03000FE0`, endpoint constant
`0x0800026C`, and computes a `0x49`-word transfer control value `0x84000049`.
This is not the installer for the later function-pointer targets around
`0x0300616C`–`0x03007478`, so that loader remains open. Use
`make audit-startup-iwram-installer ROM=...` and
`make test-startup-iwram-installer` to repeat the checks. See
`docs/PASS46_DEVELOPMENT_2026-10-20.md`.

## Pass 47 findings

`0x08059620` is now reconstructed as `RuntimeDisplay_ApplyAttributeMask`, a
VRAM tile-map halfword updater. It preserves each cell's low 12 bits and
replaces the upper nibble, with a no-op guard on child `+0x64` bit 0. Its
instruction fingerprint is checked by `make verify-runtime-display-attribute-mask
ROM=...`; five focused tests pass. No direct Thumb BL caller was found, so the
incoming dispatch and exact semantic naming remain provisional. This source
recovery does not alter matching-ROM status (still 0% verified).
