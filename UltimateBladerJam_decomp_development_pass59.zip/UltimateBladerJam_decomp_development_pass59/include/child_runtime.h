#ifndef UBJ_CHILD_RUNTIME_H
#define UBJ_CHILD_RUNTIME_H

#include <stdint.h>

/* 0x08058C98. Initializes an internally allocated child display record. */
void ChildRuntime_InitVariantC(void *child, uint32_t index,
                               uint32_t dimension_value,
                               uint32_t layout_control);

#endif
