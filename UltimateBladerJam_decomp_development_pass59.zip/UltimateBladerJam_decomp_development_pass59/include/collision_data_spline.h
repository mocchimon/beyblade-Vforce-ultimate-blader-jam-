#ifndef UBJ_COLLISION_DATA_SPLINE_H
#define UBJ_COLLISION_DATA_SPLINE_H

#include <stdint.h>

/* 0x0805B8E8. Builds the spline pointer index in a collision-data record. */
void CollisionData_BuildSplineIndex(void *record, const void *source);

/* 0x0805DBA4. Finds a packed spline record by its zero-based index. */
void *CollisionData_GetSplineByIndex(const void *record, uint32_t index);

/* 0x0805B95C. Initializes relative fields and selected owned segments. */
void CollisionData_InitializeOwnedSegments(void *record, const void *source,
                                           uint32_t flags);

#endif
