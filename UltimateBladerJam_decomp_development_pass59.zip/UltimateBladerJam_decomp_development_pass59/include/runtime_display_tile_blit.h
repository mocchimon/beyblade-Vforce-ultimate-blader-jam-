#ifndef UBJ_RUNTIME_DISPLAY_TILE_BLIT_H
#define UBJ_RUNTIME_DISPLAY_TILE_BLIT_H

#include <stdint.h>

/* 0x0805B2A4. ORs one packed-nibble 8x8 source block into map-selected tiles. */
void RuntimeDisplay_BlitIndexed4bppTile(const uint16_t *map_cell,
                                        uint8_t *tile_base,
                                        const uint32_t *source_rows,
                                        int32_t x, uint32_t y);

#endif
