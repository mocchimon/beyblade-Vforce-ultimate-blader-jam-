#ifndef UBJ_RUNTIME_DISPLAY_BYTE_STREAM_H
#define UBJ_RUNTIME_DISPLAY_BYTE_STREAM_H

#include <stdint.h>

/* 0x0805B824. Consumes a NUL-terminated display byte stream and forwards
 * buffered spans to RuntimeDisplay_DrawGlyphSequence. */
void RuntimeDisplay_ProcessByteStream(void *record, int32_t start_x,
                                      int32_t start_y,
                                      const uint8_t *stream,
                                      uint32_t alignment_mode);

#endif
