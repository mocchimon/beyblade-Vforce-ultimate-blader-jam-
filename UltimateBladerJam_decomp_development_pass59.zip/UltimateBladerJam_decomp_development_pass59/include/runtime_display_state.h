#ifndef UBJ_RUNTIME_DISPLAY_STATE_H
#define UBJ_RUNTIME_DISPLAY_STATE_H

#include <stdint.h>

/* 0x0805B268. Initializes the observed 16-byte child display-state record. */
void RuntimeDisplayState_InitializeRecord(void *record, uint32_t owner,
                                          const uint8_t *source,
                                          uint32_t field_04,
                                          uint32_t field_0C);

/* 0x0805B3B8. Dispatches the two installed operations described by the
 * referenced object, then stores halfword 1 at record +0x0E. */
void RuntimeDisplayState_InvokeRecordOperations(void *record);

/* 0x0805B284. Stores the supplied word/byte fields at +0x08, +0x04, +0x0C. */
void RuntimeDisplayState_SetFields_0805B284(void *record, uint32_t field_08,
                                            uint32_t field_04,
                                            uint32_t field_0C);

/* ROM entry points store the low byte of the second argument at +0x0D/+0x0C. */
void RuntimeDisplayState_SetByteAtOffset0D(void *record, uint32_t value);
void RuntimeDisplayState_SetByteAtOffset0C(void *record, uint32_t value);

/* 0x0805B294: base + ((index & 0x03FF) * 0x20). */
uint8_t *RuntimeDisplayState_GetIndexedBlockAddress(uint8_t *base,
                                                    uint32_t index);

#endif
