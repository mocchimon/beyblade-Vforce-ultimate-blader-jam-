#ifndef UBJ_RUNTIME_DISPLAY_H
#define UBJ_RUNTIME_DISPLAY_H

#include <stdint.h>

void RuntimeDisplay_SetAllBackgroundControlLowBits(uint32_t background0,
                                                    uint32_t background1,
                                                    uint32_t background2,
                                                    uint32_t background3);
uint32_t RuntimeDisplay_GetRecordBackgroundControlLowBits(const void *record);
void RuntimeDisplay_SetBackgroundControlLowBits(uint32_t background,
                                                 uint32_t value);
uint32_t RuntimeDisplay_GetBackgroundControlLowBits(uint32_t background);
void RuntimeDisplay_SetBackgroundEnabled(uint32_t background,
                                         uint32_t enabled);
void RuntimeDisplay_DisableRecordBackground(const void *record);
void RuntimeDisplay_InvokeInstalledBackgroundOperation(uint32_t value,
                                                       void *destination,
                                                       uint32_t operation_argument);
void RuntimeDisplay_InvokeRecordBackgroundOperation(const void *record);
uint32_t RuntimeDisplay_ComputeSequenceMetric(const uint8_t *sequence,
                                              uint32_t metric_table_offset,
                                              uint32_t base_metric);

#endif
