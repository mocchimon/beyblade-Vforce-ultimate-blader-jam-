#ifndef UBJ_RUNTIME_DISPLAY_SEQUENCE_H
#define UBJ_RUNTIME_DISPLAY_SEQUENCE_H

#include <stdint.h>

/* 0x0805B440. Draws a zero-terminated indexed glyph sequence into the
 * record's tile map and returns the resulting horizontal position. */
int32_t RuntimeDisplay_DrawGlyphSequence(void *record, int32_t x,
                                         uint32_t y,
                                         const uint8_t *sequence,
                                         uint32_t alignment_mode);

#endif
