import unittest,sys,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from audit_runtime_helpers_pass57 import audit,HALFWORDS,WORDS,BASE
class TestPass57(unittest.TestCase):
 def setUp(self):
  self.data=bytearray(0x800000)
  for a,v in HALFWORDS.items():struct.pack_into('<H',self.data,a-BASE,v)
  for a,v in WORDS.items():struct.pack_into('<I',self.data,a-BASE,v)
 def test_verified_geometry(self):
  r=audit(self.data);self.assertEqual(r['helper_08051744']['stride'],'0x18');self.assertEqual(r['helper_08051704']['stride'],'0x8')
 def test_callback_indirection(self):self.assertEqual(audit(self.data)['callback']['ram_pointer_slot'],'0x03006FAC')
 def test_bitmask_field(self):self.assertEqual(audit(self.data)['bitmask_helper_080517A4']['initial_state_after_08051120'],0)
 def test_mutated_opcode_rejected(self):
  self.data[0x51744]^=1
  with self.assertRaises(ValueError):audit(self.data)
 def test_mutated_literal_rejected(self):
  self.data[0x7d994]^=1
  with self.assertRaises(ValueError):audit(self.data)
if __name__=='__main__':unittest.main()
