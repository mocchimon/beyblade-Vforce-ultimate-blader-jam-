import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    'audit_input_mask_semantics_pass51',
    ROOT / 'tools' / 'audit_input_mask_semantics_pass51.py')
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


class TestInputMaskSemanticsPass51(unittest.TestCase):
    def synthetic_rom(self):
        rom = bytearray(0x80000)
        struct.pack_into('<' + 'H' * len(AUDIT.MASK_CODE), rom,
                         AUDIT.MASK_ENTRY - AUDIT.ROM_BASE, *AUDIT.MASK_CODE)
        struct.pack_into('<' + 'H' * len(AUDIT.SETTER_CODE), rom,
                         AUDIT.SETTER_ENTRY - AUDIT.ROM_BASE, *AUDIT.SETTER_CODE)
        for address, value in {
            AUDIT.MASK_GLOBAL_LITERAL: AUDIT.GLOBAL_POINTER,
            AUDIT.MASK_OFFSET_LITERAL: AUDIT.STATE_OFFSET,
            AUDIT.SETTER_GLOBAL_LITERAL: AUDIT.GLOBAL_POINTER,
            AUDIT.SETTER_OFFSET_LITERAL: AUDIT.STATE_OFFSET,
        }.items():
            struct.pack_into('<I', rom, address - AUDIT.ROM_BASE, value)
        return bytes(rom)

    def test_thumb_literal_address_alignment(self):
        self.assertEqual(AUDIT.literal_target(0x080517A6, 3), 0x080517B4)
        self.assertEqual(AUDIT.literal_target(0x080517AA, 3), 0x080517B8)
        self.assertEqual(AUDIT.literal_target(0x080517BC, 2), 0x080517C8)
        self.assertEqual(AUDIT.literal_target(0x080517C0, 2), 0x080517CC)

    def test_audit_recovers_indirect_base_offset_access(self):
        result = AUDIT.audit(self.synthetic_rom())
        self.assertEqual(result['input_mask']['offset_literal_value'], '0x000006B4')
        self.assertEqual(result['adjacent_setter']['entry'], '0x080517BC')

    def test_bad_adjacent_entry_rejected(self):
        rom = bytearray(self.synthetic_rom())
        struct.pack_into('<H', rom, AUDIT.SETTER_ENTRY - AUDIT.ROM_BASE, 0x0000)
        with self.assertRaises(ValueError):
            AUDIT.audit(bytes(rom))


if __name__ == '__main__':
    unittest.main()
