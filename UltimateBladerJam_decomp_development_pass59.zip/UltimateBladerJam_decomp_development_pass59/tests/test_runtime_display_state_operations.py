import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_state_operations",
    ROOT / "tools" / "verify_runtime_display_state_operations.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayStateOperationsTests(unittest.TestCase):
    def test_listing_covers_the_complete_routine_and_literal(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_both_indirect_calls_use_the_shared_thumb_arm_thunk(self):
        self.assertEqual(VERIFY.CALL_TARGETS, {
            0x0805B3D8: 0x08065C44,
            0x0805B3EE: 0x08065C44,
        })

    def test_source_keeps_the_backend_generic_and_preserves_observed_fields(self):
        source = (ROOT / "src" /
                  "runtime_display_state_operations.c").read_text()
        header = (ROOT / "include" / "runtime_display_state.h").read_text()
        self.assertIn("object[OBJECT_FIRST_DESTINATION_INDEX]", source)
        self.assertIn("object[OBJECT_SECOND_DESTINATION_INDEX]", source)
        self.assertIn("OBJECT_FIRST_OPERATION_LENGTH", source)
        self.assertIn("SECOND_OPERATION_LENGTH", source)
        self.assertEqual(source.count(
            "RuntimeDisplay_InvokeInstalledBackgroundOperation("), 2)
        self.assertIn("RECORD_OPERATION_STATE) = 1", source)
        self.assertIn("RuntimeDisplayState_InvokeRecordOperations", header)

    def test_verifier_detects_modified_instructions_and_literal(self):
        words = VERIFY._listing_halfwords()
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")

        report = VERIFY.verify(rom)
        self.assertEqual(report["halfwords"], 36)
        self.assertEqual(report["calls"], 2)
        self.assertEqual(report["branches"], 1)
        self.assertEqual(report["literals"], 1)

        rom[0x0805B3D8 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
