import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_object_display_init",
    ROOT / "tools" / "verify_runtime_object_display_init.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeObjectDisplayInitTests(unittest.TestCase):
    def test_listing_covers_every_saved_rom_range(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_initializer_call_graph_and_state_pointers(self):
        self.assertEqual(sum(target == 0x08059958
                             for target in VERIFY.CALL_TARGETS.values()), 3)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08059970], 0x080599CC)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08059978], 0x08059A0C)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08059994], 0x08059B24)
        self.assertEqual(VERIFY.CALL_TARGETS[0x080599A0], 0x08059B24)
        self.assertEqual(set(VERIFY.LITERALS.values()),
                         {0x03000DE0, 0x03000E40, 0x03000E3C})

    def test_source_matches_scroll_affine_and_flag_access(self):
        source = (ROOT / "src" / "runtime_object_display_init.c").read_text()
        header = (ROOT / "include" / "runtime_object_records.h").read_text()
        self.assertIn("RuntimeObject_InitializeDisplayState(void)", source)
        self.assertIn("mode < 4", source)
        self.assertIn("RuntimeObject_UpdateAffineTransform(2, 0, 0x0100, 0x0100)",
                      source)
        self.assertIn("RuntimeObject_UpdateAffineTransform(3, 0, 0x0100, 0x0100)",
                      source)
        self.assertIn("(uintptr_t)record + 0x64u", source)
        self.assertIn("RuntimeObject_TestFlagsAt64", header)

    def test_verifier_checks_listing_calls_and_literals(self):
        words = VERIFY._listing_halfwords()
        end = max(max(stop for _, stop in VERIFY.RANGES),
                  max(VERIFY.LITERALS) + 4)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        counts = VERIFY.verify(rom)
        self.assertEqual(counts["halfwords"], 63)
        self.assertEqual(counts["calls"], 7)
        self.assertEqual(counts["literals"], 3)

        rom[0x08059958 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
