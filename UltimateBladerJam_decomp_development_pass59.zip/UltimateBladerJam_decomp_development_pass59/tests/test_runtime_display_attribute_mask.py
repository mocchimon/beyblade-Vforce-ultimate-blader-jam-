import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_attribute_mask",
    ROOT / "tools" / "verify_runtime_display_attribute_mask.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayAttributeMaskTests(unittest.TestCase):
    def test_saved_listing_covers_full_instruction_range(self):
        words = VERIFY.listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)),
                             set(a for a in words if start <= a < end))
        self.assertEqual(len(words), 85)

    def test_expected_control_flow_and_literal(self):
        self.assertEqual(VERIFY.LITERALS, {0x080596CC: 0xFFF})
        self.assertEqual(len(VERIFY.BRANCH_TARGETS), 5)
        self.assertEqual(VERIFY.BRANCH_TARGETS[0x080596AC], 0x08059696)

    def _synthetic_rom(self):
        end = max(max(stop for _, stop in VERIFY.RANGES),
                  max(VERIFY.LITERALS) + 4)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, value in VERIFY.listing_halfwords().items():
            rom[address - VERIFY.ROM_BASE:address - VERIFY.ROM_BASE + 2] = value.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            rom[address - VERIFY.ROM_BASE:address - VERIFY.ROM_BASE + 4] = value.to_bytes(4, "little")
        for address, target in VERIFY.BRANCH_TARGETS.items():
            displacement = (target - (address + 4)) // 2
            insn = 0xD000 | ((displacement & 0xFF))
            rom[address - VERIFY.ROM_BASE:address - VERIFY.ROM_BASE + 2] = insn.to_bytes(2, "little")
        # Keep the real listing halfwords at branch locations, so the synthetic
        # branch target checks use the exact original opcodes.
        for address, value in VERIFY.listing_halfwords().items():
            rom[address - VERIFY.ROM_BASE:address - VERIFY.ROM_BASE + 2] = value.to_bytes(2, "little")
        return rom

    def test_verifier_accepts_saved_fingerprint(self):
        # Synthetic test validates verifier logic independently of a ROM file.
        rom = self._synthetic_rom()
        # Branch halfwords in the listing encode the saved destinations.
        self.assertEqual(VERIFY.verify(rom)["halfwords"], 85)

    def test_verifier_rejects_changed_instruction(self):
        rom = self._synthetic_rom()
        rom[0x08059640 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)

    def test_source_preserves_mask_and_mode_guard(self):
        source = (ROOT / "src" / "runtime_display_attribute_mask.c").read_text()
        self.assertIn("flags & 1u", source)
        self.assertIn("old_value & 0x0FFFu", source)
        self.assertIn("palette_bits", source)
        self.assertIn("child[0x5F]", source)


if __name__ == "__main__":
    unittest.main()
