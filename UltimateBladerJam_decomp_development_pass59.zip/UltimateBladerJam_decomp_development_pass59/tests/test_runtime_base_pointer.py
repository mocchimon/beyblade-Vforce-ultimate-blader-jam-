import struct
import unittest
from tools.audit_runtime_base_pointer import ROM_BASE, RUNTIME_BASE_SLOT, scan


def put16(buf, off, val):
    struct.pack_into('<H', buf, off, val)


def put32(buf, off, val):
    struct.pack_into('<I', buf, off, val)


class RuntimeBasePointerTests(unittest.TestCase):
    def test_finds_pc_relative_literal_reference(self):
        rom = bytearray(0x400)
        # Instruction at offset 0x20: PC aligns to 0x24, imm8=3 -> literal 0x30.
        put16(rom, 0x20, 0x4803)
        put32(rom, 0x30, RUNTIME_BASE_SLOT)
        result = scan(bytes(rom))
        self.assertEqual(result['candidate_thumb_ldr_literal_references'], 1)
        hit = result['references'][0]
        self.assertEqual(hit['instruction_address'], f'0x{ROM_BASE + 0x20:08X}')
        self.assertEqual(hit['literal_address'], f'0x{ROM_BASE + 0x30:08X}')
        self.assertEqual(hit['destination_register'], 'r0')

    def test_ignores_other_literal_values(self):
        rom = bytearray(0x400)
        put16(rom, 0x20, 0x4803)
        put32(rom, 0x30, 0x03000F44)
        result = scan(bytes(rom))
        self.assertEqual(result['candidate_thumb_ldr_literal_references'], 0)

    def test_reports_evidence_limit(self):
        rom = bytearray(0x400)
        put16(rom, 0x20, 0x4803)
        put32(rom, 0x30, RUNTIME_BASE_SLOT)
        result = scan(bytes(rom))
        self.assertIn('does not establish', result['interpretation'])
        self.assertIn('Find a write to the slot', ' '.join(result['next_questions']))

    def test_rejects_odd_length_image(self):
        with self.assertRaises(ValueError):
            scan(bytes(0x201))


if __name__ == '__main__':
    unittest.main()
