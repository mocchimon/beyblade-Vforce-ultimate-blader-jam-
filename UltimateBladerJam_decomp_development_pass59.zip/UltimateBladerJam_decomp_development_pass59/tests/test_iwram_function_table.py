import importlib.util
import pathlib
import struct
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_iwram_function_table', ROOT / 'tools/audit_iwram_function_table.py')
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)

class IwramFunctionTableTests(unittest.TestCase):
    def synthetic_rom(self):
        rom = bytearray(0x80000)
        for address, value in mod.EXPECTED.items():
            struct.pack_into('<I', rom, address - mod.ROM_BASE, value)
        return rom

    def test_table_entries_and_targets_are_reported(self):
        result = mod.audit(self.synthetic_rom())
        self.assertEqual(result['verified_entries'], len(mod.EXPECTED))
        self.assertIn('0x03007034', result['iwram_targets'])
        self.assertIn('0x0300711C', result['iwram_targets'])
        self.assertTrue(all(row['semantics'] == 'unresolved' for row in result['entries']))

    def test_changed_callback_target_is_rejected(self):
        rom = self.synthetic_rom()
        struct.pack_into('<I', rom, 0x0807D998 - mod.ROM_BASE, 0x03007030)
        with self.assertRaisesRegex(ValueError, 'table mismatch'):
            mod.audit(rom)

    def test_truncated_rom_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'too short'):
            mod.audit(bytes(32))

if __name__ == '__main__':
    unittest.main()
