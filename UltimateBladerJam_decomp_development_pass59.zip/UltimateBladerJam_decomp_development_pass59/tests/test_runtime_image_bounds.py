import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("audit_runtime_image_bounds", ROOT / "tools/audit_runtime_image_bounds.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

class RuntimeImageBoundsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rom = bytearray(MODULE.IMAGE_END - MODULE.ROM_BASE)
        start = MODULE.IMAGE_START - MODULE.ROM_BASE
        cls.rom[start:start + 4] = b'\x01\x02\x03\x04'

    def test_known_image_bounds_and_size(self):
        result = MODULE.audit(self.rom)
        self.assertEqual(result['image_size'], 0xD24)
        self.assertEqual(result['image_end_exclusive'], '0x08064EDC')
        self.assertFalse(result['base_is_proven'])

    def test_only_two_render_targets_fit_hypothetical_mapping(self):
        rows = {row['name']: row for row in MODULE.audit(self.rom)['targets']}
        self.assertTrue(rows['render_backend_a']['inside_image_if_base_assumed'])
        self.assertTrue(rows['render_backend_b']['inside_image_if_base_assumed'])
        self.assertFalse(rows['background_operation']['inside_image_if_base_assumed'])
        self.assertFalse(rows['runtime_copy_callback']['inside_image_if_base_assumed'])
        self.assertEqual(rows['background_operation']['distance_outside_image'], 0xD0)
        self.assertEqual(rows['runtime_copy_callback']['distance_outside_image'], 0x158)

    def test_rejects_truncated_rom(self):
        with self.assertRaises(ValueError):
            MODULE.audit(self.rom[:-1])

if __name__ == '__main__':
    unittest.main()
