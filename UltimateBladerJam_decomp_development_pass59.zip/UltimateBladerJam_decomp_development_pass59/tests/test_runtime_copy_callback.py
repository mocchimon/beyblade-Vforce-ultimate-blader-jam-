import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_copy_callback", ROOT / "tools" / "verify_runtime_copy_callback.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeCopyCallbackTests(unittest.TestCase):
    def make_rom(self):
        end = max(max(VERIFY.EXPECTED_HALFWORDS), max(VERIFY.LITERALS)) + 4
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in VERIFY.EXPECTED_HALFWORDS.items():
            struct.pack_into("<H", rom, address - VERIFY.ROM_BASE, halfword)
        for address, word in VERIFY.LITERALS.items():
            struct.pack_into("<I", rom, address - VERIFY.ROM_BASE, word)
        # Encode BL instructions from the listed call sites to the shared thunk.
        for address in (0x08063236, 0x0805B9E4, 0x0805B9FE):
            displacement = VERIFY.TRAMPOLINE - (address + 4)
            encoded = displacement & 0x00FFFFFF
            upper = 0xF000 | ((encoded >> 12) & 0x7FF)
            lower = 0xF800 | ((encoded >> 1) & 0x7FF)
            struct.pack_into("<HH", rom, address - VERIFY.ROM_BASE, upper, lower)
        struct.pack_into("<H", rom, VERIFY.TRAMPOLINE - VERIFY.ROM_BASE, 0x4718)
        return rom

    def test_both_callers_share_same_three_argument_callback(self):
        result = VERIFY.verify(self.make_rom())
        self.assertEqual(result["callback_target"], 0x03007034)
        self.assertEqual(result["call_sites"], 3)

    def test_slot_corruption_is_rejected(self):
        rom = self.make_rom()
        struct.pack_into("<I", rom, VERIFY.SLOT - VERIFY.ROM_BASE, 0x03007038)
        with self.assertRaisesRegex(ValueError, "word differs"):
            VERIFY.verify(rom)

    def test_instruction_corruption_is_rejected(self):
        rom = self.make_rom()
        rom[0x08063234 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "instruction differs"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
