import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_sequence",
    ROOT / "tools" / "verify_runtime_display_sequence.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplaySequenceTests(unittest.TestCase):
    def test_listing_covers_renderer_helper_and_all_five_callers(self):
        halfwords, data_words = VERIFY._listing()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & halfwords.keys(),
                             set(range(start, end, 2)))
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805B70C], 0x0805B440)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805B7FE], 0x0805B440)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805B884], 0x0805B440)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805B896], 0x0805B440)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805B8B4], 0x0805B440)
        self.assertEqual(data_words[0x0805B688], bytes.fromhex("a4 d9 07 08"))

    def test_source_preserves_map_reservation_callback_and_blitter_boundaries(self):
        source = (ROOT / "src" / "runtime_display_sequence.c").read_text()
        self.assertIn("RuntimeDisplay_ComputeSequenceMetric", source)
        self.assertIn("((entry & 0x0FFFu)", source)
        self.assertIn("RuntimeDisplay_InvokeInstalledBackgroundOperation", source)
        self.assertIn("RuntimeDisplay_BlitIndexed4bppTile", source)
        self.assertIn("descriptor + data_offset + glyph_offset", source)
        self.assertIn("shift < 32u ? glyph_index << shift : 0u", source)
        self.assertIn("((uintptr_t)(y & ~7u) << 3)", source)
        self.assertIn("if (x > 239)", source)

    def test_alignment_uses_logical_half_metric_and_sequence_returns_x(self):
        source = (ROOT / "src" / "runtime_display_sequence.c").read_text()
        self.assertIn("x = (int32_t)((uint32_t)x - (metric >> 1))", source)
        self.assertIn("return x;", source)

    def test_rom_verifier_checks_bytes_calls_branches_and_literals(self):
        halfwords, _ = VERIFY._listing()
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE + 4)
        for address, halfword in halfwords.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        report = VERIFY.verify(rom)
        self.assertEqual(report["halfwords"], 333)
        self.assertEqual(report["calls"], 11)
        self.assertEqual(report["conditional_branches"], 20)
        self.assertEqual(report["unconditional_branches"], 3)
        self.assertEqual(report["literals"], 4)

        rom[0x0805B638 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
