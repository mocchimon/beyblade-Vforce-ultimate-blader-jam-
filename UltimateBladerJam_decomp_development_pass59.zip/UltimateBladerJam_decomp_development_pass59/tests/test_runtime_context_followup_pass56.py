import struct, unittest
from tools.audit_runtime_context_followup_pass56 import ROM_BASE, EXPECTED_HALFWORDS, EXPECTED_WORDS, audit, read_u16, read_u32

def synthetic_rom():
    rom=bytearray(0x800000)
    for a,v in EXPECTED_HALFWORDS.items(): struct.pack_into('<H',rom,a-ROM_BASE,v)
    for a,v in EXPECTED_WORDS.items(): struct.pack_into('<I',rom,a-ROM_BASE,v)
    return bytes(rom)
class RuntimeContextFollowupPass56Tests(unittest.TestCase):
    def test_reads_known_instructions_and_literals(self):
        rom=synthetic_rom(); self.assertEqual(read_u16(rom,0x0805114A),0x6002); self.assertEqual(read_u32(rom,0x0805117C),0x03000F48)
    def test_audit_records_overwrite_and_loops(self):
        r=audit(synthetic_rom()); facts=' '.join(x['fact'] for x in r['findings'])
        self.assertIn('clears word at runtime base + 0x6B4',facts); self.assertIn('0 through 55',facts); self.assertIn('0 through 9',facts)
    def test_detects_instruction_mismatch(self):
        rom=bytearray(synthetic_rom()); struct.pack_into('<H',rom,0x0805114A-ROM_BASE,0)
        with self.assertRaisesRegex(ValueError,'ROM evidence mismatch'): audit(bytes(rom))
    def test_rejects_odd_rom(self):
        with self.assertRaises(ValueError): audit(bytes(0x201))
    def test_rejects_out_of_bounds(self):
        with self.assertRaises(ValueError): read_u32(bytes(0x200),0x08051100)
if __name__=='__main__': unittest.main()
