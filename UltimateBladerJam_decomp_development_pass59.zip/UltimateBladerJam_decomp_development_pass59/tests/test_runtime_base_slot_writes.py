import struct
import unittest
from tools.audit_runtime_base_slot_writes import ROM_BASE, RUNTIME_BASE_SLOT, scan


def put16(buf, off, value):
    struct.pack_into('<H', buf, off, value)


def put32(buf, off, value):
    struct.pack_into('<I', buf, off, value)


class RuntimeBaseSlotWriteTests(unittest.TestCase):
    def test_detects_store_using_loaded_slot_address(self):
        rom = bytearray(0x200)
        # LDR r3, [PC, #0x14] at 0x20 -> literal word at 0x38.
        put16(rom, 0x20, 0x4B05)
        put16(rom, 0x22, 0x6821)  # unrelated LDR r1, [r4, #0]
        put16(rom, 0x24, 0x6019)  # STR r1, [r3, #0]
        put32(rom, 0x38, RUNTIME_BASE_SLOT)
        result = scan(bytes(rom))
        self.assertEqual(result['candidate_store_count'], 1)
        hit = result['candidates'][0]
        self.assertEqual(hit['slot_address_load'], f'0x{ROM_BASE + 0x20:08X}')
        self.assertEqual(hit['store_address'], f'0x{ROM_BASE + 0x24:08X}')
        self.assertEqual(hit['slot_register'], 'r3')
        self.assertEqual(hit['stored_source_register'], 'r1')

    def test_does_not_match_wrong_literal(self):
        rom = bytearray(0x200)
        put16(rom, 0x20, 0x4B05)
        put16(rom, 0x22, 0x6019)
        put32(rom, 0x38, 0x03000F44)
        self.assertEqual(scan(bytes(rom))['candidate_store_count'], 0)

    def test_dereference_stops_candidate_window(self):
        rom = bytearray(0x200)
        put16(rom, 0x20, 0x4B05)
        put16(rom, 0x22, 0x681B)  # LDR r3, [r3, #0]
        put16(rom, 0x24, 0x6019)
        put32(rom, 0x38, RUNTIME_BASE_SLOT)
        self.assertEqual(scan(bytes(rom))['candidate_store_count'], 0)

    def test_rejects_odd_rom(self):
        with self.assertRaises(ValueError):
            scan(bytes(0x201))


if __name__ == '__main__':
    unittest.main()
