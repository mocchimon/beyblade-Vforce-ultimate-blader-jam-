import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_collision_data_spline",
    ROOT / "tools" / "verify_collision_data_spline.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class CollisionDataSplineTests(unittest.TestCase):
    def test_listing_covers_initializer_lookup_and_nine_call_sites(self):
        halfwords, data_words = VERIFY._listing()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & halfwords.keys(),
                             set(range(start, end, 2)))
        self.assertEqual(len(halfwords), 145)
        self.assertEqual(len(VERIFY.CONSTRUCTOR_CALLERS), 9)
        self.assertEqual(len(VERIFY.HELPER_CALLERS), 9)
        self.assertEqual(data_words[0x0805B958],
                         bytes.fromhex("f4 53 75 08"))

    def test_source_tracks_relative_fields_packed_stride_and_limit(self):
        source = (ROOT / "src" / "collision_data_spline.c").read_text()
        self.assertIn("COLLISION_SPLINE_LIMIT = 64", source)
        self.assertIn("COLLISION_SPLINE_LIMIT_MESSAGE = 0x087553F4", source)
        self.assertIn("source_address +", source)
        self.assertIn("COLLISION_RECORD_SPLINE_POINTERS +", source)
        self.assertIn("spline + sizeof(uint32_t)", source)
        self.assertIn("spline_count = COLLISION_SPLINE_LIMIT", source)
        self.assertIn("COLLISION_RECORD_SPLINE_COUNT_STATE", source)

    def test_rom_verifier_matches_edges_and_detects_corruption(self):
        halfwords, _ = VERIFY._listing()
        rom_end = max(end for _, end in VERIFY.RANGES)
        rom = bytearray(rom_end - VERIFY.ROM_BASE + 4)
        for address, halfword in halfwords.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        result = VERIFY.verify(rom)
        self.assertEqual(result["halfwords"], 145)
        self.assertEqual(result["calls"], 19)
        self.assertEqual(result["conditional_branches"], 6)
        self.assertEqual(result["unconditional_branches"], 1)
        self.assertEqual(result["constructor_callers"], 9)
        self.assertEqual(result["helper_callers"], 9)

        rom[0x0805B924 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
