import importlib.util
import pathlib
import struct
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_arm_runtime_module', ROOT / 'tools/audit_arm_runtime_module.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class ArmRuntimeModuleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rom = bytearray(MODULE.TABLE_END - MODULE.ROM_BASE)
        image_start = MODULE.IMAGE_START - MODULE.ROM_BASE
        words = (0xE2014CFF, 0xE0433002, 0xE1A03403, 0xE1A02402, 0xE0822204)
        for i, word in enumerate(words):
            struct.pack_into('<I', cls.rom, image_start + 4 * i, word)
        table_start = MODULE.TABLE_START - MODULE.ROM_BASE
        values = [0] * MODULE.TABLE_WORDS
        values[0] = 0x1AC
        values[1] = 0x60
        values[2] = 0
        values[3] = 0xA80
        values[27] = MODULE.IMAGE_SIZE
        for i, value in enumerate(values):
            struct.pack_into('<I', cls.rom, table_start + 4 * i, value)

    def test_known_bounds_and_loader_slots(self):
        result = MODULE.audit(self.rom)
        self.assertTrue(result['pass'])
        self.assertEqual(result['image_size'], 0xD24)
        self.assertEqual(result['table_word_count'], 32)
        self.assertEqual(result['loader_consumed_slot_count'], 29)

    def test_one_past_end_is_valid_not_an_entry(self):
        result = MODULE.audit(self.rom)
        row = result['table'][27]
        self.assertTrue(row['one_past_end'])
        self.assertIsNone(row['known_entry'])
        self.assertEqual(row['target_rom_address'], '0x08064EDC')

    def test_rejects_bad_arm_fingerprint(self):
        damaged = bytearray(self.rom)
        struct.pack_into('<I', damaged, MODULE.IMAGE_START - MODULE.ROM_BASE, 0)
        self.assertFalse(MODULE.audit(damaged)['pass'])

    def test_rejects_truncated_rom(self):
        with self.assertRaises(ValueError):
            MODULE.audit(self.rom[:-1])


if __name__ == '__main__':
    unittest.main()
