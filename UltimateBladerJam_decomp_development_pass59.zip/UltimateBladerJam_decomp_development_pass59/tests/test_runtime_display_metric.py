import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_metric",
    ROOT / "tools" / "verify_runtime_display_metric.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayMetricTests(unittest.TestCase):
    def test_listing_covers_helper_and_observed_caller_setup(self):
        words, data_words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))
        self.assertEqual(data_words[0x0805B43C], bytes.fromhex("a4 d9 07 08"))

    def test_caller_passes_sequence_table_offset_and_base_metric(self):
        self.assertEqual(VERIFY.CALL_TARGETS, {0x0805B4C0: 0x0805B400})

    def test_source_preserves_terminator_space_and_optional_table_adjustment(self):
        source = (ROOT / "src" / "runtime_display_metric.c").read_text()
        header = (ROOT / "include" / "runtime_display.h").read_text()
        self.assertIn("if (character == 0)", source)
        self.assertIn("if (character == SPACE_CHARACTER)", source)
        self.assertIn("contribution = SPACE_SEQUENCE_METRIC", source)
        self.assertIn("if (metric_table_offset != 0)", source)
        self.assertIn("table[metric_table_offset + mapped]", source)
        self.assertIn("RuntimeDisplay_ComputeSequenceMetric", header)

    def test_verifier_checks_rom_bytes_and_branch_edges(self):
        words, _ = VERIFY._listing_halfwords()
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        rom[0x0805B43C - VERIFY.ROM_BASE:
            0x0805B440 - VERIFY.ROM_BASE] = bytes.fromhex("a4 d9 07 08")

        report = VERIFY.verify(rom)
        self.assertEqual(report["halfwords"], 51)
        self.assertEqual(report["calls"], 1)
        self.assertEqual(report["branches"], 6)
        self.assertEqual(report["literals"], 1)

        rom[0x0805B416 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
