import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "audit_iwram_target_03006fac",
    ROOT / "tools" / "audit_iwram_target_03006fac.py")
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


class IwramTargetAuditTests(unittest.TestCase):
    def _rom(self):
        rom = bytearray(AUDIT.TABLE_SLOT - AUDIT.ROM_BASE + 8)
        offset = AUDIT.TABLE_SLOT - AUDIT.ROM_BASE
        rom[offset:offset + 4] = struct.pack("<I", AUDIT.TARGET)
        return rom

    def test_unique_target_pointer_is_at_the_runtime_configuration_slot(self):
        result = AUDIT.audit(self._rom())
        self.assertEqual(result["target_word_locations"], (AUDIT.TABLE_SLOT,))
        self.assertEqual(result["slot_address_occurrences"], 0)

    def test_rejects_changed_slot_value(self):
        rom = self._rom()
        rom[AUDIT.TABLE_SLOT - AUDIT.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "dispatch slot"):
            AUDIT.audit(rom)

    def test_rejects_another_copy_of_the_target_pointer_word(self):
        rom = self._rom()
        rom[0:4] = struct.pack("<I", AUDIT.TARGET)
        with self.assertRaisesRegex(ValueError, "unexpected ROM locations"):
            AUDIT.audit(rom)

    def test_rejects_a_rom_that_ends_before_the_dispatch_slot(self):
        with self.assertRaisesRegex(ValueError, "too short"):
            AUDIT.audit(b"\0" * 16)


if __name__ == "__main__":
    unittest.main()
