import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_background_dispatch",
    ROOT / "tools" / "verify_runtime_background_dispatch.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeBackgroundDispatchTests(unittest.TestCase):
    def test_listing_covers_all_verified_code_and_literal_words(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_rom_dispatch_uses_record_indices_and_preserves_arm_target_state(self):
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A7F4], 0x08059D28)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A818], 0x08065C44)
        self.assertEqual(VERIFY.LITERALS[0x0804A820], 0x0807D994)
        self.assertEqual(VERIFY.LITERALS[0x0807D994], 0x03006FAC)
        self.assertEqual(VERIFY._listing_halfwords()[0x08065C44],
                         VERIFY.THUMB_BX_R3)
        self.assertEqual(VERIFY.LITERALS[0x0807D994] & 1, 0)
        words = VERIFY._listing_halfwords()
        for register in range(3, 15):
            address = 0x08065C44 + (register - 3) * 4
            self.assertEqual(words[address], 0x4700 | (register << 3))
            self.assertEqual(words[address + 2], 0x46C0)

    def test_source_keeps_backend_semantics_unknown(self):
        source = (ROOT / "src" / "runtime_background_dispatch.c").read_text()
        header = (ROOT / "include" / "runtime_display.h").read_text()
        self.assertIn("bytes[RECORD_BACKGROUND_ENABLE_INDEX]", source)
        self.assertIn("bytes + RECORD_BACKGROUND_STATE_POINTER", source)
        self.assertIn("background_state[RECORD_BACKGROUND_MEMORY_INDEX]", source)
        self.assertIn("((uintptr_t)memory_index << 14)", source)
        self.assertIn("BACKGROUND_MEMORY_OPERATION_SIZE", source)
        self.assertIn("operation(value, destination, operation_argument)", source)
        self.assertIn("RuntimeDisplay_InvokeInstalledBackgroundOperation(\n        0, (void *)destination", source)
        self.assertIn("RuntimeDisplay_DisableRecordBackground", header)
        self.assertIn("RuntimeDisplay_InvokeRecordBackgroundOperation", header)
        self.assertIn("backend clears memory", source)

    def test_background_dispatch_uses_default_thumb_source_set(self):
        makefile = (ROOT / "Makefile").read_text()
        arm_sources = next(line for line in makefile.splitlines()
                           if line.startswith("ARM_STATE_SOURCES :="))
        self.assertNotIn("runtime_background_dispatch.c", arm_sources)
        self.assertIn("C_SOURCES := $(wildcard src/*.c)", makefile)

    def test_verifier_checks_instructions_calls_and_pointer_state(self):
        words = VERIFY._listing_halfwords()
        end = max(max(stop for _, stop in VERIFY.RANGES),
                  max(VERIFY.LITERALS) + 4)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        counts = VERIFY.verify(rom)
        self.assertEqual(counts["halfwords"], 52)
        self.assertEqual(counts["calls"], 2)
        self.assertEqual(counts["callback_address"], 0x03006FAC)
        self.assertEqual(counts["thunks"], 12)

        rom[0x08065C44 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
