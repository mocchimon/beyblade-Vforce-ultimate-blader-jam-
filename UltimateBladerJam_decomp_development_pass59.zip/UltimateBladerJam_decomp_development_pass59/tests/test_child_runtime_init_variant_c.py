import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_child_runtime_init_variant_c",
    ROOT / "tools" / "verify_child_runtime_init_variant_c.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class ChildRuntimeInitVariantCTests(unittest.TestCase):
    def test_listing_covers_initializer_caller_and_interworking_entry(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_rom_edges_and_iwram_globals_are_pinned(self):
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A76E], 0x08058C98)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08058CC6], 0x080592A8)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08058E08], 0x08065C44)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08058E0E], 0x08059A4C)
        self.assertEqual(VERIFY.LITERALS[0x08058D68], 0x03000CA0)
        self.assertEqual(VERIFY.LITERALS[0x08058D9C], 0x03000DE0)
        self.assertEqual(VERIFY.LITERALS[0x08058DE0], 0x03000E3C)
        self.assertEqual(VERIFY.LITERALS[0x0807D994], 0x03006FAC)
        self.assertEqual(VERIFY._listing_halfwords()[0x08065C44],
                         VERIFY.THUMB_BX_R3)

    def test_source_preserves_observed_initializer_and_opaque_callback(self):
        source = (ROOT / "src" / "child_runtime_init_variant_c.c").read_text()
        header = (ROOT / "include" / "child_runtime.h").read_text()
        self.assertIn("ChildResource_SelectLayout(child, control, 0)", source)
        self.assertIn("(allocation_length - 1u) >> VRAM_BLOCK_SHIFT", source)
        self.assertIn("layout_length >> VRAM_CURSOR_SHIFT", source)
        self.assertIn("(control & CHILD_LAYOUT_MODE_FLAG) ? 6 : 5", source)
        self.assertIn("RuntimeDisplay_InvokeInstalledBackgroundOperation(", source)
        self.assertIn("ChildResource_BackgroundControlRegister(child_index)", source)
        self.assertIn("ChildRuntime_InitVariantC", header)
        self.assertIn("higher-level asset vocabulary", source)

    def test_shared_background_dispatch_stays_a_thumb_source(self):
        makefile = (ROOT / "Makefile").read_text()
        arm_sources = next(line for line in makefile.splitlines()
                           if line.startswith("ARM_STATE_SOURCES :="))
        self.assertNotIn("child_runtime_init_variant_c.c", arm_sources)
        self.assertIn("C_SOURCES := $(wildcard src/*.c)", makefile)

    def test_verifier_checks_bytes_calls_literals_and_state(self):
        words = VERIFY._listing_halfwords()
        end = max(max(stop for _, stop in VERIFY.RANGES),
                  max(VERIFY.LITERALS) + 4)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        counts = VERIFY.verify(rom)
        self.assertEqual(counts["halfwords"], 233)
        self.assertEqual(counts["calls"], 4)
        self.assertEqual(counts["callback_address"], 0x03006FAC)

        rom[0x08058C98 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
