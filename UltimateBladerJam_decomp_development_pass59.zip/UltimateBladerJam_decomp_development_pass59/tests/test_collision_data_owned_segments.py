import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_collision_data_owned_segments",
    ROOT / "tools" / "verify_collision_data_owned_segments.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class CollisionOwnedSegmentsTests(unittest.TestCase):
    def test_listing_covers_code_and_literals(self):
        halfwords, data_words = VERIFY._listing()
        self.assertEqual(sum((end - start) // 2 for start, end in VERIFY.RANGES) +
                         len(VERIFY.PADDING_HALFWORDS), len(halfwords))
        self.assertEqual(len(VERIFY.CALL_TARGETS), 6)
        self.assertEqual(len(VERIFY.CONDITIONAL_BRANCHES), 9)
        self.assertEqual(len(VERIFY.UNCONDITIONAL_BRANCHES), 2)
        self.assertEqual(data_words[0x0805B9CC],
                         bytes.fromhex("30 54 75 08"))
        self.assertEqual(data_words[0x0805BA58],
                         bytes.fromhex("98 d9 07 08"))

    def test_source_keeps_flags_allocation_and_callback_generic(self):
        source = (ROOT / "src" / "collision_data_spline.c").read_text()
        self.assertIn("CollisionData_InitializeOwnedSegments", source)
        self.assertIn("segment0_size = *(const uint32_t *)(source + 0x00) << 4",
                      source)
        self.assertIn("segment1_size = *(const uint32_t *)(source + 0x08) << 5",
                      source)
        self.assertIn("0x0807D998u", source)
        self.assertIn("*(uint16_t *)(record + 0x118) = selected_flags", source)
        self.assertIn("Heap_AllocAlt(allocation_size)", source)

    def test_rom_verifier_detects_corruption(self):
        halfwords, _ = VERIFY._listing()
        size = max(max(end for _, end in VERIFY.RANGES),
                   max(VERIFY.LITERALS) + 4) - VERIFY.ROM_BASE
        rom = bytearray(size + 4)
        for address, halfword in halfwords.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")
        result = VERIFY.verify(rom)
        self.assertEqual(result["halfwords"], 123)
        self.assertEqual(result["calls"], 6)
        self.assertEqual(result["literal_loads"], 4)
        rom[0x0805B9B0 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
