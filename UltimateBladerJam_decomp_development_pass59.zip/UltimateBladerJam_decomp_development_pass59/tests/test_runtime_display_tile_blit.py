import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_tile_blit",
    ROOT / "tools" / "verify_runtime_display_tile_blit.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayTileBlitTests(unittest.TestCase):
    def test_listing_covers_the_function_and_caller_setup(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertTrue(all(address in words for address in range(start, end, 2)))

    def test_call_graph_has_four_index_lookups_and_the_observed_entry_call(self):
        self.assertEqual([VERIFY.CALL_TARGETS[a] for a in sorted(VERIFY.CALL_TARGETS)],
                         [0x0805B294] * 4 + [0x0805B2A4])
        self.assertEqual(len(VERIFY.BRANCH_TARGETS), 10)

    def test_source_models_map_stride_clipping_and_bitwise_composition(self):
        source = (ROOT / "src" / "runtime_display_tile_blit.c").read_text()
        header = (ROOT / "include" / "runtime_display_tile_blit.h").read_text()
        self.assertIn("map_cell[32]", source)
        self.assertIn("map_cell[33]", source)
        self.assertIn("(uint32_t)x + 7u > 246u", source)
        self.assertIn("y > 152u", source)
        self.assertIn("pixels << x_shift", source)
        self.assertIn("pixels >> (32u - x_shift)", source)
        self.assertIn("*left_word |= left_pixels", source)
        self.assertIn("*right_word |= right_pixels", source)
        self.assertIn("RuntimeDisplay_BlitIndexed4bppTile", header)

    def _synthetic_rom(self):
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in VERIFY._listing_halfwords().items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        return rom

    def test_verifier_accepts_saved_function_bytes_edges_and_cfg(self):
        result = VERIFY.verify(self._synthetic_rom())
        self.assertEqual(result["halfwords"], 150)
        self.assertEqual(result["calls"], 5)
        self.assertEqual(result["branches"], 10)

    def test_verifier_rejects_modified_instruction(self):
        rom = self._synthetic_rom()
        rom[0x0805B32A - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
