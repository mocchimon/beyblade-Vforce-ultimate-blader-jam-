import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_runtime_state_setter_pass58', ROOT / 'tools' / 'audit_runtime_state_setter_pass58.py')
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)

class TestRuntimeStateSetterPass58(unittest.TestCase):
    def synthetic_rom(self):
        rom = bytearray(0x80000)
        for i, value in enumerate(AUDIT.SETTER_CODE):
            struct.pack_into('<H', rom, AUDIT.SETTER - AUDIT.ROM_BASE + 2*i, value)
        for address, value in AUDIT.LITERALS.items():
            struct.pack_into('<I', rom, address - AUDIT.ROM_BASE, value)
        # Value loads and BL-shaped call pairs at the verified call paths.
        for address, value in {0x08045A48: 0x2001, 0x08045A56: 0x2001, 0x08045A5A: 0x2004}.items():
            struct.pack_into('<H', rom, address - AUDIT.ROM_BASE, value)
        for address, first, second in [(0x08045A4A, 0xF00B, 0xFEB7), (0x08045A5C, 0xF00B, 0xFEAE)]:
            off = address - AUDIT.ROM_BASE
            struct.pack_into('<HH', rom, off, first, second)
        return bytes(rom)

    def test_setter_and_call_targets(self):
        result = AUDIT.audit(self.synthetic_rom())
        self.assertEqual(result['setter'], '0x080517BC')
        self.assertEqual(result['callsite_1']['argument'], 1)
        self.assertEqual(result['callsite_2']['argument_paths'], [1, 4])

    def test_rejects_changed_setter_instruction(self):
        rom = bytearray(self.synthetic_rom())
        struct.pack_into('<H', rom, AUDIT.SETTER - AUDIT.ROM_BASE, 0)
        with self.assertRaises(ValueError):
            AUDIT.audit(bytes(rom))

    def test_rejects_changed_offset_literal(self):
        rom = bytearray(self.synthetic_rom())
        struct.pack_into('<I', rom, 0x080517CC - AUDIT.ROM_BASE, 0x6B0)
        with self.assertRaises(ValueError):
            AUDIT.audit(bytes(rom))

    def test_rejects_bad_callsite(self):
        rom = bytearray(self.synthetic_rom())
        struct.pack_into('<H', rom, 0x08045A4A - AUDIT.ROM_BASE + 2, 0)
        with self.assertRaises(ValueError):
            AUDIT.audit(bytes(rom))

    def test_rejects_odd_length_rom(self):
        with self.assertRaises(ValueError):
            AUDIT.audit(b'\x00' * 513)

if __name__ == '__main__':
    unittest.main()
