import importlib.util
import pathlib
import struct
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_startup_iwram_installer', ROOT / 'tools/audit_startup_iwram_installer.py')
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


def synthetic_rom():
    rom = bytearray(0x800000)
    for i, halfword in enumerate(MOD.HALFWORDS):
        struct.pack_into('<H', rom, MOD.ENTRY - MOD.ROM_BASE + 2 * i, halfword)
    for address, value in MOD.LITERALS.items():
        struct.pack_into('<I', rom, address - MOD.ROM_BASE, value)
    return rom


class StartupIwramInstallerTests(unittest.TestCase):
    def test_exact_instruction_and_literal_fingerprint(self):
        result = MOD.audit(synthetic_rom())
        self.assertEqual(result['instruction_halfwords_verified'], 21)
        self.assertEqual(result['transfer']['source_rom'], '0x08000168')
        self.assertEqual(result['transfer']['destination_iwram'], '0x03000FE0')
        self.assertEqual(result['transfer']['word_count'], 0x49)
        self.assertEqual(result['transfer']['control_word'], '0x84000049')

    def test_rejects_instruction_mutation(self):
        rom = synthetic_rom()
        struct.pack_into('<H', rom, MOD.ENTRY - MOD.ROM_BASE, 0x0000)
        with self.assertRaisesRegex(ValueError, 'instruction mismatch'):
            MOD.audit(rom)

    def test_rejects_literal_mutation(self):
        rom = synthetic_rom()
        struct.pack_into('<I', rom, 0x0805799C - MOD.ROM_BASE, 0x03007034)
        with self.assertRaisesRegex(ValueError, 'literal mismatch'):
            MOD.audit(rom)

    def test_rejects_short_rom(self):
        with self.assertRaisesRegex(ValueError, 'too short'):
            MOD.audit(b'\0' * 0x100)


if __name__ == '__main__':
    unittest.main()
