import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_state_record",
    ROOT / "tools" / "verify_runtime_display_state_record.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayStateRecordTests(unittest.TestCase):
    def test_listing_covers_record_initializer_and_call_setup(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_observed_caller_targets_the_record_initializer(self):
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A780], 0x0805B268)

    def test_source_writes_the_observed_fields_and_copied_byte(self):
        source = (ROOT / "src" / "runtime_display_state_record.c").read_text()
        header = (ROOT / "include" / "runtime_display_state.h").read_text()
        self.assertIn("(r + 0x08)", source)
        self.assertIn("(r + 0x04)", source)
        self.assertIn("r[0x0C]", source)
        self.assertIn("r[0x0D] = source[5]", source)
        self.assertIn("*(uint16_t *)(r + 0x0E) = 1", source)
        self.assertIn("RuntimeDisplayState_InitializeRecord", header)

    def test_verifier_detects_modified_instructions(self):
        words = VERIFY._listing_halfwords()
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        report = VERIFY.verify(rom)
        self.assertEqual(report["halfwords"], 22)
        self.assertEqual(report["calls"], 1)

        rom[0x0805B268 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
