import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_state_helpers",
    ROOT / "tools" / "verify_runtime_display_state_helpers.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayStateHelperTests(unittest.TestCase):
    def test_listing_covers_each_observed_range(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertTrue(all(address in words for address in range(start, end, 2)))

    def test_all_four_call_sites_target_the_index_helper(self):
        self.assertEqual(set(VERIFY.CALL_TARGETS.values()), {0x0805B294})
        self.assertEqual(len(VERIFY.CALL_TARGETS), 4)

    def test_source_models_offsets_byte_truncation_and_32_byte_stride(self):
        source = (ROOT / "src" / "runtime_display_state_helpers.c").read_text()
        header = (ROOT / "include" / "runtime_display_state.h").read_text()
        self.assertIn("*(uint32_t *)(r + 0x08) = field_08", source)
        self.assertIn("*(uint32_t *)(r + 0x04) = field_04", source)
        self.assertIn("r[0x0C] = (uint8_t)field_0C", source)
        self.assertIn("[0x0D] = (uint8_t)value", source)
        self.assertIn("[0x0C] = (uint8_t)value", source)
        self.assertIn("((index & 0x03FFu) << 5)", source)
        self.assertIn("RuntimeDisplayState_GetIndexedBlockAddress", header)

    def _synthetic_rom(self):
        end = max(stop for _, stop in VERIFY.RANGES)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in VERIFY._listing_halfwords().items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        return rom

    def test_verifier_accepts_observed_bytes_and_edges(self):
        result = VERIFY.verify(self._synthetic_rom())
        self.assertEqual(result["halfwords"], 22)
        self.assertEqual(result["calls"], 4)
        self.assertEqual(result["literals"], 1)

    def test_verifier_rejects_modified_helper_or_mask_literal(self):
        rom = self._synthetic_rom()
        rom[0x0805B294 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)

        rom = self._synthetic_rom()
        rom[0x0805B2A0 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "literal"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
