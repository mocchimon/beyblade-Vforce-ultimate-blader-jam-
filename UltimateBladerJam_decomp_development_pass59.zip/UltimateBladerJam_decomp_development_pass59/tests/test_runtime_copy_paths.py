import importlib.util
import struct
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / 'tools' / 'audit_runtime_copy_paths.py'
spec = importlib.util.spec_from_file_location('audit_runtime_copy_paths', SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def put_bl(buf, call_addr, target):
    off = call_addr - module.ROM_BASE
    disp = target - (call_addr + 4)
    assert disp % 2 == 0
    signed = disp
    hi = (signed >> 12) & 0x7FF
    lo = (signed >> 1) & 0x7FF
    struct.pack_into('<HH', buf, off, 0xF000 | hi, 0xF800 | lo)


class RuntimeCopyPathAuditTests(unittest.TestCase):
    def test_finds_known_lz77_wrapper_call(self):
        rom = bytearray(0x800000)
        put_bl(rom, 0x08050000, 0x080578F4)
        result = module.audit(rom)
        self.assertEqual(result['call_count'], 1)
        self.assertEqual(result['calls'][0]['target_name'], 'System_LZ77UnCompWram_wrapper')

    def test_excludes_unrecognized_targets(self):
        rom = bytearray(0x800000)
        put_bl(rom, 0x08050000, 0x080578F4)
        put_bl(rom, 0x08050010, 0x08057900)
        result = module.audit(rom)
        self.assertEqual(result['call_count'], 1)

    def test_rejects_too_short_rom(self):
        with self.assertRaises(ValueError):
            module.audit(b'\x00' * 100)

    def test_context_window_is_bounded(self):
        rom = bytearray(0x800000)
        put_bl(rom, 0x08050000, 0x080578F4)
        result = module.audit(rom, context_halfwords=3)
        self.assertEqual(result['calls'][0]['context_halfwords_each_side'], 3)
        self.assertLessEqual(len(result['calls'][0]['instruction_window']), 8)


if __name__ == '__main__':
    unittest.main()
