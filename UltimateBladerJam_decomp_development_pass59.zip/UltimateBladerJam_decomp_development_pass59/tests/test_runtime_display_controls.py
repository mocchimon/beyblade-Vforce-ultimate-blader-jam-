import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_controls",
    ROOT / "tools" / "verify_runtime_display_controls.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayControlTests(unittest.TestCase):
    def test_listing_covers_every_saved_rom_range(self):
        words = VERIFY._listing_halfwords()
        for start, end in VERIFY.RANGES:
            self.assertEqual(set(range(start, end, 2)) & words.keys(),
                             set(range(start, end, 2)))

    def test_direct_calls_bind_the_control_helpers(self):
        self.assertEqual(VERIFY.CALL_TARGETS[0x0805EAAE], 0x08059C3C)
        self.assertEqual(VERIFY.CALL_TARGETS[0x08057F5A], 0x08059CD8)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A7CC], 0x08059CEC)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A7D4], 0x08059D28)
        self.assertEqual(VERIFY.CALL_TARGETS[0x0804A7F4], 0x08059D28)
        self.assertEqual(sum(target == 0x08059A4C
                             for target in VERIFY.CALL_TARGETS.values()), 7)

    def test_rom_masks_clear_one_dispcnt_enable_bit_each(self):
        self.assertEqual(list(VERIFY.LITERALS.values()),
                         [0x0000FEFF, 0x0000FDFF,
                          0x0000FBFF, 0x0000F7FF])

    def test_source_preserves_control_bits_and_enable_masking(self):
        source = (ROOT / "src" / "runtime_display_controls.c").read_text()
        header = (ROOT / "include" / "runtime_display.h").read_text()
        self.assertIn("old_value & 0xFCu", source)
        self.assertIn("((uint8_t)value & 3u)", source)
        self.assertIn("bytes[0x5E]", source)
        self.assertIn("REG_DISPCNT |= mask", source)
        self.assertIn("REG_DISPCNT &= (uint16_t)~mask", source)
        self.assertIn("RuntimeDisplay_SetBackgroundEnabled", header)

    def test_control_translation_unit_uses_the_default_thumb_path(self):
        makefile = (ROOT / "Makefile").read_text()
        arm_sources = next(line for line in makefile.splitlines()
                           if line.startswith("ARM_STATE_SOURCES :="))
        self.assertNotIn("runtime_display_controls.c", arm_sources)
        self.assertIn("C_SOURCES := $(wildcard src/*.c)", makefile)

    def test_verifier_checks_instructions_calls_and_literals(self):
        words = VERIFY._listing_halfwords()
        end = max(max(stop for _, stop in VERIFY.RANGES),
                  max(VERIFY.LITERALS) + 4)
        rom = bytearray(end - VERIFY.ROM_BASE)
        for address, halfword in words.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")
        for address, value in VERIFY.LITERALS.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 4] = value.to_bytes(4, "little")

        counts = VERIFY.verify(rom)
        self.assertEqual(counts["halfwords"], 218)
        self.assertEqual(counts["calls"], 12)
        self.assertEqual(counts["literals"], 4)

        rom[0x08059C3C - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)


if __name__ == "__main__":
    unittest.main()
