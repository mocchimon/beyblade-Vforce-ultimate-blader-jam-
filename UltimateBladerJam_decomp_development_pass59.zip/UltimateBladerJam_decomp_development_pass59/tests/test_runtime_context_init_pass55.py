import struct
import unittest
from tools.audit_runtime_context_init_pass55 import (
    ROM_BASE, EXPECTED_HALFWORDS, EXPECTED_WORDS, audit, read_u16, read_u32,
)


def synthetic_rom():
    rom = bytearray(0x800000)
    for addr, value in EXPECTED_HALFWORDS.items():
        struct.pack_into('<H', rom, addr - ROM_BASE, value)
    for addr, value in EXPECTED_WORDS.items():
        struct.pack_into('<I', rom, addr - ROM_BASE, value)
    return bytes(rom)


class RuntimeContextInitPass55Tests(unittest.TestCase):
    def test_reads_rom_values_little_endian(self):
        rom = synthetic_rom()
        self.assertEqual(read_u16(rom, 0x08051096), 0xF009)
        self.assertEqual(read_u32(rom, 0x08051104), 0x03000F48)

    def test_audit_reports_all_expected_evidence(self):
        result = audit(synthetic_rom())
        self.assertEqual(result['checked_halfwords'], len(EXPECTED_HALFWORDS))
        self.assertEqual(result['checked_literal_words'], len(EXPECTED_WORDS))
        self.assertIn('0x03000F48', result['interpretation'])

    def test_detects_instruction_mismatch(self):
        rom = bytearray(synthetic_rom())
        struct.pack_into('<H', rom, 0x080510AC - ROM_BASE, 0x0000)
        with self.assertRaisesRegex(ValueError, 'ROM evidence mismatch'):
            audit(bytes(rom))

    def test_rejects_odd_rom(self):
        with self.assertRaises(ValueError):
            audit(bytes(0x201))

    def test_rejects_out_of_bounds_address(self):
        with self.assertRaises(ValueError):
            read_u32(bytes(0x200), 0x08051000)

if __name__ == '__main__':
    unittest.main()
