import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime_display_byte_stream",
    ROOT / "tools" / "verify_runtime_display_byte_stream.py")
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class RuntimeDisplayByteStreamTests(unittest.TestCase):
    def test_listing_covers_complete_parser(self):
        halfwords = VERIFY._listing()
        start, end = VERIFY.RANGES[0]
        self.assertEqual(set(range(start, end, 2)), set(halfwords))
        self.assertEqual(len(halfwords), 97)

    def test_source_captures_control_fields_flushes_and_line_reset(self):
        source = (ROOT / "src" / "runtime_display_byte_stream.c").read_text()
        self.assertIn("STREAM_CONTROL_LINE_STEP = 0xFB", source)
        self.assertIn("STREAM_CONTROL_PALETTE = 0xFC", source)
        self.assertIn("STREAM_CONTROL_END = 0xFF", source)
        self.assertIn("record[RECORD_STREAM_PALETTE] = *stream++", source)
        self.assertIn("record[RECORD_STREAM_LINE_STEP] = *stream++", source)
        self.assertIn("y += record[RECORD_STREAM_LINE_STEP]", source)
        self.assertIn("x = origin_x", source)
        self.assertIn("value == 0 || value == STREAM_CONTROL_END", source)

    def test_rom_verifier_checks_calls_branches_and_absent_static_entry(self):
        halfwords = VERIFY._listing()
        start, end = VERIFY.RANGES[0]
        rom = bytearray(end - VERIFY.ROM_BASE + 4)
        for address, halfword in halfwords.items():
            offset = address - VERIFY.ROM_BASE
            rom[offset:offset + 2] = halfword.to_bytes(2, "little")

        report = VERIFY.verify(rom)
        self.assertEqual(report["halfwords"], 97)
        self.assertEqual(report["calls"], 3)
        self.assertEqual(report["conditional_branches"], 9)
        self.assertEqual(report["unconditional_branches"], 5)
        self.assertEqual(report["direct_entry_calls"], 0)
        self.assertEqual(report["direct_entry_branches"], 0)
        self.assertEqual(report["stored_entry_pointers"], 0)

        rom[0x0805B8B4 - VERIFY.ROM_BASE] ^= 1
        with self.assertRaisesRegex(ValueError, "Thumb bytes differ"):
            VERIFY.verify(rom)

    def test_byte_stream_signature_is_public(self):
        header = (ROOT / "include" / "runtime_display_byte_stream.h").read_text()
        self.assertIn("RuntimeDisplay_ProcessByteStream", header)
        self.assertIn("uint32_t alignment_mode", header)


if __name__ == "__main__":
    unittest.main()
