import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('audit_input_mask_callers', ROOT / 'tools' / 'audit_input_mask_callers.py')
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


class TestInputMaskCallerAudit(unittest.TestCase):
    def test_decodes_forward_thumb_bl(self):
        # BL at 0x08000100 to 0x08000120: offset is 0x1C from PC=site+4.
        first = 0xF000
        second = 0xF80E
        self.assertEqual(AUDIT.decode_thumb_bl_target(0x08000100, first, second), 0x08000120)

    def test_rejects_non_bl_pair(self):
        self.assertIsNone(AUDIT.decode_thumb_bl_target(0x08000100, 0x2000, 0x4770))

    def test_audit_checks_fingerprint_and_literal(self):
        rom = bytearray(0x80000)
        off = AUDIT.MASK_HELPER - AUDIT.ROM_BASE
        struct.pack_into('<' + 'H' * len(AUDIT.MASK_HALFWORDS), rom, off, *AUDIT.MASK_HALFWORDS)
        struct.pack_into('<I', rom, AUDIT.MASK_LITERAL_ADDRESS - AUDIT.ROM_BASE, AUDIT.MASK_LITERAL_VALUE)
        struct.pack_into('<I', rom, AUDIT.OVERLAPPED_WORD_ADDRESS - AUDIT.ROM_BASE, AUDIT.OVERLAPPED_WORD_VALUE)
        result = AUDIT.audit(bytes(rom))
        self.assertEqual(result['instruction_halfwords_verified'], 8)
        self.assertEqual(result['candidate_count'], 0)

    def test_corrupt_fingerprint_rejected(self):
        rom = bytearray(0x80000)
        off = AUDIT.MASK_HELPER - AUDIT.ROM_BASE
        struct.pack_into('<' + 'H' * len(AUDIT.MASK_HALFWORDS), rom, off, *AUDIT.MASK_HALFWORDS)
        struct.pack_into('<I', rom, AUDIT.MASK_LITERAL_ADDRESS - AUDIT.ROM_BASE, AUDIT.MASK_LITERAL_VALUE)
        struct.pack_into('<I', rom, AUDIT.OVERLAPPED_WORD_ADDRESS - AUDIT.ROM_BASE, AUDIT.OVERLAPPED_WORD_VALUE)
        struct.pack_into('<H', rom, off, 0x0000)
        with self.assertRaises(ValueError):
            AUDIT.audit(bytes(rom))


if __name__ == '__main__':
    unittest.main()
