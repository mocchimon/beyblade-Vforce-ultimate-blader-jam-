; ROM-backed Thumb reconstruction. Addresses are CPU addresses (ROM base 0x08000000).
; Setter: 0x080517BC
080517BC: 4902       ldr  r1, [pc, #8]       ; literal 0x080517C8 = 0x03000F48
080517BE: 6809       ldr  r1, [r1, #0]       ; runtime_base = *(u32*)0x03000F48
080517C0: 4A02       ldr  r2, [pc, #8]       ; literal 0x080517CC = 0x000006B4
080517C2: 1889       adds r1, r1, r2
080517C4: 6008       str  r0, [r1, #0]       ; runtime_base[0x6B4] = value
080517C6: 4770       bx   lr

; Callsite A: 0x08045A48 movs r0,#1; 0x08045A4A BL 0x080517BC
; Callsite B: branch paths at 0x08045A56/0x08045A5A load r0=#1 or #4,
;             converge on 0x08045A5C BL 0x080517BC.
; These calls prove values 1 and 4 are written on distinct paths; semantics unknown.
