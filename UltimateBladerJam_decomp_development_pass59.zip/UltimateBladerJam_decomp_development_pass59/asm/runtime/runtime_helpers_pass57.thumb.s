@ Pass 57. ROM addresses are 0x08000000 + shown file offsets.
@ 0x08051704: r0=index, r0=*(0x03000F48)+0x544+8*index
@ 51704 ldr r1, =0x03000F48
@ 51706 lsls r0,r0,#3
@ 51708 ldr r2, =0x544
@ 5170A adds r0,r0,r2
@ 5170C ldr r1,[r1]
@ 5170E adds r1,r1,r0
@ 51710 adds r0,r1,#0
@ 51712 bx lr
@ 0x08051744: r0=index, r0=*(0x03000F48)+4+24*index
@ 51744 ldr r2,=0x03000F48
@ 51746 lsls r1,r0,#1
@ 51748 adds r1,r1,r0
@ 5174A lsls r1,r1,#3
@ 5174C adds r1,#4
@ 5174E ldr r0,[r2]
@ 51750 adds r0,r0,r1
@ 51752 bx lr
@ 0x08065C44: bx r3 (trampoline; no callback semantics implied)
@ 0x0807D994: .word 0x03006FAC (RAM callback pointer slot)
@ 0x080517A4: returns input mask AND *(runtime_base+0x6B4)
