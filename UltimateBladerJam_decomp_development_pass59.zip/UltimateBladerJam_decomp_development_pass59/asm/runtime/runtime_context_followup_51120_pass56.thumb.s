/* ROM-backed Thumb capture for the follow-on initializer at 0x08051120.
 * Checked fingerprint/literals: docs/runtime_context_followup_pass56.json.
 * Unknown field and callback semantics intentionally remain unnamed.
 */
08051120: B5F0       push {r4,r5,r6,r7,lr}
08051122: 4B16       ldr r3,[pc,#0x58]   ; 0x0805117C = 0x03000F48
08051124: 6818       ldr r0,[r3]
08051126: 2200       movs r2,#0
08051128: 7002       strb r2,[r0]      ; clear +0
0805112A: 6818       ldr r0,[r3]
0805112C: 24DD       movs r4,#0xDD
0805112E: 00E4       lsls r4,r4,#3     ; +0x6E8
08051130: 1901       adds r1,r0,r4
08051132: 800A       strh r2,[r1]      ; clear +0x6E8
08051134: 4912       ldr r1,[pc,#0x48] ; 0x08051180 = 0x6AB
08051136: 1840       adds r0,r0,r1
08051138: 2101       movs r1,#1
0805113A: 7001       strb r1,[r0]      ; +0x6AB = 1
0805113C: 6819       ldr r1,[r3]
0805113E: 23D8       movs r3,#0xD8
08051140: 00DB       lsls r3,r3,#3     ; +0x6C0
08051142: 18C8       adds r0,r1,r3
08051144: 6002       str r2,[r0]      ; clear +0x6C0
08051146: 3C2C       subs r4,#0x2C    ; +0x6B4
08051148: 1908       adds r0,r1,r4
0805114A: 6002       str r2,[r0]      ; clear +0x6B4 (overwrites Pass55 seed=1)
0805114C: 480D       ldr r0,[pc,#0x34] ; 0x08051184 = 0x6EA
0805114E: 1809       adds r1,r1,r0
08051150: 480D       ldr r0,[pc,#0x34] ; 0x08051188 = 0xFFFF
08051152: 8008       strh r0,[r1]      ; +0x6EA = 0xFFFF
08051154: 2500       movs r5,#0
08051156: 4E0D       ldr r6,[pc,#0x34] ; 0x0805118C = 0x0807D994
08051158: 1C28       adds r0,r5,#0
0805115A: F000 FAF3 bl 0x08051744
0805115E: 1C04       adds r4,r0,#0
08051160: 20D0       movs r0,#0xD0
08051162: 1C29       adds r1,r5,#0
08051164: 4341       muls r1,r0,r1
08051166: 480A       ldr r0,[pc,#0x28] ; 0x08051190 = 0x08075B70
08051168: 1809       adds r1,r1,r0
0805116A: 60E1       str r1,[r4,#0xC]
0805116C: 6848       ldr r0,[r1,#4]
0805116E: 6060       str r0,[r4,#4]
08051170: 6888       ldr r0,[r1,#8]
08051172: 60A0       str r0,[r4,#8]
08051174: 2D00       cmp r5,#0
08051176: DC0D       bgt 0x08051194
08051178: 2006       movs r0,#6
0805117A: E00C       b 0x08051196
/* 0x0805117C..0x08051190 are literal pool words. */
08051194: 2004       movs r0,#4
08051196: 8020       strh r0,[r4]
08051198: 1C21       adds r1,r4,#0
0805119A: 3110       adds r1,#0x10
0805119C: 6833       ldr r3,[r6]
0805119E: 2000       movs r0,#0
080511A0: 2204       movs r2,#4
080511A2: F014 FD4F bl 0x08065C44
080511A6: 1C21       adds r1,r4,#0
080511A8: 3114       adds r1,#0x14
080511AA: 6833       ldr r3,[r6]
080511AC: 2000       movs r0,#0
080511AE: 2204       movs r2,#4
080511B0: F014 FD48 bl 0x08065C44
080511B4: 3501       adds r5,#1
080511B6: 2D37       cmp r5,#0x37
080511B8: DDCE       ble 0x08051158 ; indices 0..55
080511BA: 2500       movs r5,#0
080511BC: 2600       movs r6,#0
080511BE: 2400       movs r4,#0
080511C0: 4F25       ldr r7,[pc,#0x94] ; 0x08051258 = 0x08075850
080511C2: 1C28       adds r0,r5,#0
080511C4: F000 FA9E bl 0x08051704
080511C8: 19E1       adds r1,r4,r7
080511CA: 6041       str r1,[r0,#4]
080511CC: 7006       strb r6,[r0]
080511CE: 8046       strh r6,[r0,#2]
080511D0: 3450       adds r4,#0x50
080511D2: 3501       adds r5,#1
080511D4: 2D09       cmp r5,#9
080511D6: DDF4       ble 0x080511C2 ; indices 0..9
