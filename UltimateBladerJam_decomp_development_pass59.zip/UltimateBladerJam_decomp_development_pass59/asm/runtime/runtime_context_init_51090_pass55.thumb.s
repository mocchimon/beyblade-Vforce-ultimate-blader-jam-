/* ROM-backed Thumb capture for 0x08051090..0x080510F8.
 * Source ROM fingerprint and checked literals: docs/runtime_context_init_pass55.json.
 * Semantic field names are intentionally not invented.
 */
08051090: B530       push {r4,r5,lr}
08051092: 4D1A       ldr  r5, [pc,#0x68]   ; 0x080510FC = 0x00000C6C
08051094: 1C28       adds r0,r5,#0
08051096: F009 F9D5 bl   0x0805A444      ; Heap_AllocAlt(size)
0805109A: 1C04       adds r4,r0,#0
0805109C: 2C00       cmp  r4,#0
0805109E: D103       bne  0x080510A8
080510A0: 4817       ldr  r0,[pc,#0x5C]   ; 0x08051100 = 0x087293E4
080510A2: 1C29       adds r1,r5,#0
080510A4: F006 FDDA bl   0x08057C5C      ; return-only diagnostic stub
080510A8: 4B16       ldr  r3,[pc,#0x58]   ; 0x08051104 = 0x03000F48
080510AA: 6821       ldr  r1,[r4,#0]      ; descriptor->payload base
080510AC: 6019       str  r1,[r3,#0]      ; runtime-base slot = payload base
080510AE: 22D6       movs r2,#0xD6
080510B0: 00D2       lsls r2,r2,#3        ; +0x6B0
080510B2: 1888       adds r0,r1,r2
080510B4: 6004       str  r4,[r0,#0]      ; payload + 0x6B0 = descriptor
080510B6: 2400       movs r4,#0
080510B8: 700C       strb r4,[r1,#0]
080510BA: 681A       ldr  r2,[r3,#0]
080510BC: 4812       ldr  r0,[pc,#0x48]   ; 0x08051108 = 0x6B4
080510BE: 1811       adds r1,r2,r0
080510C0: 2001       movs r0,#1
080510C2: 6008       str  r0,[r1,#0]      ; payload + 0x6B4 = 1
080510C4: 7094       strb r4,[r2,#2]
080510C6: 6819       ldr  r1,[r3,#0]
080510C8: 4810       ldr  r0,[pc,#0x40]   ; 0x0805110C = 0x6E6
080510CA: 180A       adds r2,r1,r0
080510CC: 2080       movs r0,#0x80
080510CE: 8010       strh r0,[r2,#0]     ; payload + 0x6E6 = 0x80
080510D0: 480F       ldr  r0,[pc,#0x3C]   ; 0x08051110 = 0x6E4
080510D2: 180A       adds r2,r1,r0
080510D4: 20FF       movs r0,#0xFF
080510D6: 8010       strh r0,[r2,#0]     ; payload + 0x6E4 = 0xFF
080510D8: 4A0E       ldr  r2,[pc,#0x38]   ; 0x08051114 = 0x6AC
080510DA: 1888       adds r0,r1,r2
080510DC: 8004       strh r4,[r0,#0]     ; clear +0x6AC
080510DE: 3202       adds r2,#2
080510E0: 1888       adds r0,r1,r2
080510E2: 8004       strh r4,[r0,#0]     ; clear +0x6AE
080510E4: 4A0C       ldr  r2,[pc,#0x30]   ; 0x08051118 = 0xC64
080510E6: 1888       adds r0,r1,r2
080510E8: 6004       str  r4,[r0,#0]      ; clear +0xC64
080510EA: 480C       ldr  r0,[pc,#0x30]   ; 0x0805111C = 0xC68
080510EC: 1809       adds r1,r1,r0
080510EE: 600C       str  r4,[r1,#0]      ; clear +0xC68
080510F0: F000 F816 bl   0x08051120      ; follow-on initializer
080510F4: BC30       pop  {r4,r5}
080510F6: BC01       pop  {r0}
080510F8: 4700       bx   r0

/* Literal pool, values read from the original ROM. */
080510FC: 00000C6C   .word 0x00000C6C
08051100: 087293E4   .word 0x087293E4
08051104: 03000F48   .word 0x03000F48
08051108: 000006B4   .word 0x000006B4
0805110C: 000006E6   .word 0x000006E6
08051110: 000006E4   .word 0x000006E4
08051114: 000006AC   .word 0x000006AC
08051118: 00000C64   .word 0x00000C64
0805111C: 00000C68   .word 0x00000C68
