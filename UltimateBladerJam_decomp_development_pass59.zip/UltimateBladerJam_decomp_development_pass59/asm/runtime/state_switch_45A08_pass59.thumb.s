; Pass 59 — verified Thumb switch-like dispatch at ROM 0x08045A08.
; Input: r6 points to an enclosing context (semantic type unknown).
; Selector: word [r6 + 0x4B4], values 0..4 index a ROM pointer table.
; Values > 4 branch to the common epilogue at 0x08045A76.
08045A08: 4C08       LDR  r4, [PC, #0x20]       ; literal 0x08045A2C = 0x4B4
08045A0A: 1930       ADDS r0, r6, r4
08045A0C: 6800       LDR  r0, [r0]
08045A0E: 2804       CMP  r0, #4
08045A10: D831       BHI  0x08045A76
08045A12: 0080       LSLS r0, r0, #2
08045A14: 4906       LDR  r1, [PC, #0x18]       ; table base 0x08045A34
08045A16: 1840       ADDS r0, r0, r1
08045A18: 6800       LDR  r0, [r0]
08045A1A: 4687       MOV  PC, r0                ; computed branch

; ROM table at 0x08045A34 (five 32-bit Thumb code addresses)
; selector 0 -> 0x08045A48: set runtime +0x6B4 = 1; select context 0x19
; selector 1 -> 0x08045A5A: set runtime +0x6B4 = 4; select context 0x0F
; selector 2 -> 0x08045A56: set runtime +0x6B4 = 1; select context 0x0F
; selector 3 -> 0x08045A70: select context 0x0C
; selector 4 -> 0x08045A68: select context 0x28

; These are observed dispatch actions only; do not infer game/secret semantics.
