## Pass 59 — five-way context selector dispatch

The routine at `0x08045A08` reads `[r6 + 0x4B4]`, rejects values greater than four, and jumps through a five-entry table at `0x08045A34`. Cases 0–2 invoke the verified runtime `+0x6B4` setter with values 1 or 4 before selecting contexts `0x19` or `0x0F`; cases 3–4 select `0x0C` and `0x28`. Semantic labels and any Easter-egg connection remain unresolved. See `docs/PASS59_DEVELOPMENT_2026-10-25.md`.

# Reverse-engineering progress

## Pass 55 — runtime-base initializer

ROM evidence now confirms that `0x08051090` calls `Heap_AllocAlt(0xC6C)`,
stores the allocation descriptor's payload address at `0x03000F48`, preserves
the descriptor pointer at payload offset `+0x6B0`, seeds several fields, and
calls `0x08051120` for further initialization. The field meanings and the
zero-allocation path remain unresolved. See
`docs/PASS55_DEVELOPMENT_2026-10-25.md` and
`docs/runtime_context_init_pass55.json`. No Easter egg has been confirmed.

## Pass 1 — boot and entry

`08000000` → `087FE7B4` relocation stub → `020000C0` relocated startup → `080505A9` Thumb entry.

## Pass 2 — high-level entry

The high-level startup at `0x080505A8` is mapped through its first persistent loop. It initializes platform state, control state, several runtime/resource subsystems, then enters a VBlank-driven polling loop.

## Pass 3 — recovered low-level systems

### Input mapping

- `08063A74` — clears 0x15-byte mapping table at `0x03005E80`.
- `08063A8C` — writes a mapping byte when index <= 0x14.
- `08063AA0` — stores a 32-bit input state at `0x03005E98`.
- `080517A4` — tests a mask against that state.

### Control state

`0805A890` is now treated as `ControlState_Init`, not merely `Input_Init`. It reads `KEYINPUT`, mirrors the inverted state into control globals, clears queue/counter fields, and initializes ten 0x18-byte records at `0x03005CB0`.

### Heap allocator

The cluster `0805A3CC`–`0805A608` is a linked free-list allocator. Recovered operations include allocation front-ends, block splitting/insertion, free/unlink, and free-block search. Exact original type names remain unknown.

### Runtime pools

`08060544` caps two counts at `0x80` and `0x20`, allocates backing storage with the game's heap, and is called at startup and repeatedly from the frame loop. This strongly suggests per-frame/runtime pool setup rather than one-time hardware initialization.

### Resource descriptor

`0805FEF4` is called from startup as `(2, 0x10, 3)` and constructs a descriptor containing derived pointers and dimensions. Its exact subsystem ownership is still unresolved, so the source uses the neutral `ResourceDescriptor` name.

## Pass 4 — current targets

1. Resolve `08062370` / `08062490` and the `0x03005Exx` resource table.
2. Resolve `08062E94` and its two heap allocations (`0xC400` and `0x1400`).
3. Trace `0805EFC0` and `08052538` from the first persistent-loop iteration.
4. Resolve `08062814`, including its 0x28-byte record/ring-buffer behavior.
5. Continue outward through the call graph until the game-state machine is identified.

## Pass 4 — resource/runtime structures

### Resource table (`080623CC`)

The routine beginning at `0x080623CC` iterates exactly `0x80` entries. It
loads a table base from `0x03000D98`, calls a helper chain to derive a value,
and stores one 32-bit result per entry. After the loop it updates the timing/
resource globals at `0x03000D90`, `0x03000D94`, `0x03000DA0`, and `0x03000DA2`.
The semantic identity of the generated values is intentionally unresolved.

### Runtime memory initialization (`08062E94`)

The first routine in the `0x08062E94` cluster clears three globals and obtains
backing storage of `0xC400` and `0x1400` bytes from the game's allocator. The
pointers are then installed into the runtime descriptor globals. This is now
separated from the later 0x28-byte object-table initializer.

### Frame/event service (`08062814`)

The entry performs two global-state checks before entering its timing/event
logic. The routine contains a state-dependent dispatch and is not yet named as
an ordinary gameplay tick. Further reconstruction is required before assigning
it to a specific game subsystem.

### Important correction

The earlier pass described `08062370` and `08062490` too broadly as a single
resource initializer. The new pass separates the routines by their actual
entry points and records the observed 0x80-entry table construction and the
0x28-byte object allocation path independently.

## Pass 5 — persistent-loop/event tracing

Resolved several previously opaque direct call targets from the startup loop:

- `08049268` — large state-context preparation/reset routine.
- `0804945C` — state/context dispatch routine with VBlank and event/object checks.
- `080512D0` — indexed control/event state scan.
- `0805A6DC` — queued 16-bit control/event stream consumer.
- `08062B44` — one-word runtime context setter.
- `08062BCC` — deferred-event table lookup/start routine.

Also corrected `src/main.c` so the second VBlank/`08062814` phase and direct `08049268`/`0804945C` calls are represented instead of being hidden behind comments.

## Pass 7

Recovered the `0x0804901C–0x0804945C` state/context cluster: context history, pending-index handling, signed fixed-point scaling, frame preparation, and a five-way indirect state dispatcher. See `docs/PASS7_FINDINGS.md` and `src/game_state.c`.

## Pass 8

Refined the state dispatcher after checking its target addresses directly. The
five entries at `0x08049348` are shared-tail continuations, not independent C
handlers. Also traced `0x0804A284` and recovered the structural behavior of
`0x08050398`, including its `0x18`-byte record stride and heap allocation.

## Pass 9

Recovered the resource/handle lifecycle around `0x0804AF08` and
`0x0804AF60`, including the selector field at `0x03000FB0 + 0xC26`, handle
field at `+0xC2C`, ROM resource table at `0x08075640`, and the 0x28-byte
runtime-entry search/status helpers around `0x08062A74`.

## Continued object/render runtime recovery

Direct disassembly of the child initializer at `0x08057C7C` confirms that the
`0xC4`-byte child record initializes a command/event queue at `+0x74`:

- `+0x6C` is cleared.
- `+0x70` receives the caller-supplied initial activity/timing value.
- `+0x74` is initialized to `-1` (queue uninitialized).
- `+0x78` and `+0x7C` are cleared and later hold the 0x40-byte queue pointer
  and its allocation respectively.
- `+0x80` is initialized to zero, `+0x84` to `-1`, and several nearby control
  bytes/words are cleared.
- `+0xA0`..`+0xA5` are initialized by the child setup path.
- `+0xA8`..`+0xAE` receive four halfword transform/control values through
  `0x0805861C`.
- `+0xB8` is cleared, `+0xBC` is cleared as a halfword, and `+0xC0` is cleared.

`0x080587B8` is now characterized as a four-slot queue append routine. It
allocates exactly `0x40` bytes on first use, treats that allocation as four
`0x10`-byte entries, searches for an empty entry once the queue reaches four
entries, and wraps to slot zero if all four are occupied. The four entry words
are populated from the routine's four value arguments; their semantic meaning
is still intentionally unresolved.

`0x08058900` clears the first word of each active queue entry and resets the
queue count to zero. It does not free the 0x40-byte allocation.

`0x08058400` reads a referenced resource/descriptor and copies its small
metadata fields into the child record, while `0x080584DC` advances the child's
three fixed-point position/step accumulators and handles its activity timer.
These routines are strong evidence that the child structure is part of a
render/animation-oriented runtime object, but no game-specific name is being
assigned yet.

## Verification cleanup

The cumulative C source tree now passes an ARMv4T/Thumb freestanding syntax
check with clang. Remaining diagnostics are qualifier/narrowing warnings in
older provisional files, not syntax failures. `runtime_entries.c` also had an
incorrect placeholder assignment in `RuntimeEntry_InitIndexed`; it has been
corrected to store the source-table pointer at entry `+0x1C`, matching the ROM.

## Continued render/runtime recovery

The cluster `0x08058948..0x08058E3C` was disassembled directly from the ROM.
Two small table helpers at `0x08058948`/`0x08058960` were recovered, and the
larger initializer family at `0x0805898C`, `0x08058A4C`, `0x08058ACC`, and
`0x08058C98` was mapped. `0x08058ACC` is represented by a conservative
field-level reconstruction, and `0x08058C98` is now source-defined as
`ChildRuntime_InitVariantC`; unresolved helper semantics remain explicit
rather than guessed.

## Runtime pointer/configuration table pass

Started the next pass by following the literal-pool reference to `0x0807D920`.
The region is structured mixed data: runtime-global addresses, Thumb code
pointers, scalar configuration values, and compact lookup-table bytes coexist
near one another. A PC-relative load in the `0x080602xx` region references the
block; the literal is at `0x080602C0`, with a load site at `0x0806027E`.

The `0x0300646C` word appears at `0x0807D968`, while code reads that global at
`0x08059254` and `0x080593FC`. This supports the function-pointer-slot
interpretation but does not yet prove the store/initializer or final target.
Details and explicit confidence boundaries are in
`docs/RUNTIME_POINTER_TABLE_FINDINGS.md`.


## Runtime configuration consumer follow-up

Disassembly around `0x0806027E` now establishes a concrete use of the mixed
block: the routine loads `0x0807D920`, dereferences its first word (`0x0300717C`),
and branches indirectly through the `0x08065C38` trampoline (`bx r0`). This
means at least some entries may point into IWRAM runtime code; they should not
all be described as ordinary global-variable addresses. The block's exact
record layout and the write to `0x0300646C` remain unresolved. Evidence is
recorded in `docs/RUNTIME_CONFIG_CONSUMER_FINDINGS.md` and
`asm/runtime/runtime_config_consumer_60170.s`.

### 2026-10-09 — renderer-slot literal scan

- Reconstructed the consumer sequence at `0x0805921C`: it loads the address of `0x0300646C`, dereferences the mutable slot, and invokes the resulting target via `0x08065C48` (`bx r4`).
- Scanned the complete ROM for the aligned word `0x0300646C`: its sole occurrence is the mixed-data word at `0x0807D968`; no direct Thumb literal-load reference to that word was found. This suggests indirect/base-relative or data-driven initialization, but does not prove the writer is absent.
- Added a table of known words from `0x0807D920` to the runtime config findings document, preserving uncertainty around record boundaries and semantics.
- Next: reconstruct the setup/copy routine(s) for the `0x03006xxx` runtime region and search for stores through base/index addressing; keep `0x08059428` as a candidate backend until the slot value is proven.


## Render dispatch re-check

Re-read the raw Thumb instructions around `0x08059334–0x08059428` and corrected an earlier overconfident backend association. `0x08059520` is directly selected when child `+0x64` bit 0 is set. Other branches use IWRAM targets `0x0300646C` and `0x0300682C`; their installation/source has not yet been found. `0x08059428` is now neutrally named `sub_08059428` until a byte-copy or assignment relationship is demonstrated.


## Startup IWRAM install correction

Re-disassembly of `0x08057968` corrected a misleading legacy name/comment: the function programs DMA3 to copy `0x104` bytes from ROM `0x08000168` into IWRAM `0x03000FE0`, then records the destination at `0x03007FFC`. The destination range ends at `0x030010E4`, so it does not explain the unresolved renderer targets at `0x0300646C` and `0x0300682C`. Source and function-map labels were updated to `System_InstallIwramBlock`; details are in `docs/IWRAM_INSTALL_FINDINGS.md`.


## IWRAM target interpretation correction

Instruction-level review corrected a prior misconception: `0x0300646C` and `0x0300682C` are direct IWRAM branch targets supplied by ROM words at `0x0807D968` and `0x0807D96C`, not RAM variables containing function pointers. `0x0805921C` loads `0x0807D968`, reads `0x0300646C` from the ROM table, then dispatches through `bx r4`; the clipping path similarly routes through `bx r9`. The code-install source for these IWRAM addresses remains unresolved. See `docs/IWRAM_TARGET_INSTALL_FINDINGS.md`.

## Copy-site audit follow-up

Audited the full ROM's Thumb disassembly for direct calls to the known LZ77 wrapper `0x080578F4`: only `0x08055CA8` and `0x080572F8` call it directly, and both callers pass allocator-returned destinations for resource data. The only direct call to `System_CpuSet` at `0x080578E4` is `0x0805070A`, with zero source/destination and control `0x40000000`, consistent with a clear/fill operation rather than ROM-to-IWRAM code installation. This does not find the writer for `0x0300646C` / `0x0300682C`; custom copy loops and descriptor-driven DMA remain open. See `docs/IWRAM_COPY_SITE_AUDIT.md`.

## 2026-10-09 — Follow-up DMA destination audit

Expanded the DMA3-site audit beyond literal-address scans. The setup sequence at `0x0805EFF8` uses a runtime descriptor for destination and length while sourcing from a ROM address loaded into `r6`, making it a stronger candidate for a data-driven copy than routines whose destinations are clearly VRAM or hardware state. This candidate remains unproven: the descriptor producer and destination range have not yet been traced. The sequence at `0x08062ED0` uses a stack source and control value `0x05000000`, so it is currently classified as a fill/state-transfer path, not code installation. Added these distinctions to `docs/IWRAM_COPY_SITE_AUDIT.md` and kept both IWRAM render targets unresolved.

## 2026-10-09 — DMA candidate caller trace

Traced the DMA setup site at `0x0805EFF8` back to its containing routine (`0x0805EFC0`) and startup caller (`0x08050644`). The caller passes `*(0x03000FB0) + 0xBA0` and zero, before the frame loop. The routine allocates a `0xD24`-byte context-associated block, configures DMA3 from runtime fields, and builds pointer-like fields by adding offsets from a ROM table. This supports classifying it as startup context/table setup, but does not prove it installs executable code into the unresolved IWRAM targets. The target-source question remains open.


## 2026-10-09 — ARM-mode runtime image identified

Re-disassembly of `0x0805EFC0` and inspection of the source region established an ARM-state image at `0x080641B8` with length `0xD24`, ending exactly at `0x08064EDC`. The bytes at `0x08064EDC` form an offset/relocation table; the loader copies the image using the allocated block descriptor's address and size, then rebases selected internal offsets into runtime context fields. This is strong evidence for a relocatable ARM-mode runtime module.

A potentially important address correspondence emerged: if the image were based at `0x030061B8`, the renderer's IWRAM targets `0x0300646C` and `0x0300682C` would map to ROM offsets `0x0806446C` and `0x0806482C` (offsets `0x2B4` and `0x674`). Both are inside the ARM-mode image and decode as ARM instructions. However, the currently traced loader uses a heap block descriptor and its actual destination has not been proven to equal `0x030061B8`. The correspondence is therefore recorded as a high-value hypothesis, not a confirmed alias. See `docs/ARM_RUNTIME_IMAGE_FINDINGS.md` and `asm/runtime/arm_runtime_image_641b8.s`.

## 2026-10-09 — checked the ARM-image/IWRAM offset hypothesis

Re-disassembled heap initialization at `0x0805A374`. It initializes the primary heap arena from `0x02000000` (EWRAM), with adjacent boundaries around `0x02000200` and `0x02000400`. The loader at `0x0805EFC0` allocates `0xD24` bytes through that allocator and copies the ARM-state image at `0x080641B8` into the allocated block. This means the tempting correspondence between image offsets `0x2B4` / `0x674` and IWRAM targets `0x0300646C` / `0x0300682C` is not established by this loader and is now explicitly downgraded as a likely false lead. See `docs/IWRAM_IMAGE_HYPOTHESIS_CHECK.md`.

Next: find a separate writer/copy loop for the upper IWRAM region and continue the renderer target trace.

## Completion estimate

**Overall traditional decompilation: approximately 15% (rough engineering estimate, not a line-count metric).** Boot path and several runtime subsystems are mapped, but gameplay states, audio, much of the asset/data semantics, many function bodies, and build/matching-ROM work remain. A reproducible build that matches the original ROM is **0% complete**: the current project is a research/source-reconstruction scaffold, not yet a full buildable matching decompilation. Keep this estimate conservative and revise it when whole subsystems or a verified build milestone are completed.

## 2026-10-09 — ARM rasterizer image semantic recovery

Re-disassembled the complete ARM-state image `0x080641B8–0x08064EDB` using ARM decoding (rather than Thumb). Recovered a conservative routine map for sample generation at `+0x000`, packed byte-sample generation at `+0x060`, a three-record primitive/edge processor at `+0x1AC`, an alternate edge path at `+0x434`, span clamping at `+0x56C`, row stepping at `+0x698`, and compact vertex/attribute processing at `+0x85C`. The row routine advances output by `0x40` bytes per row; the sample routine packs four byte samples per word; the edge processor consumes records at `0x10`-byte stride and uses fixed-point slope/table operations. These findings establish that this is a software rasterization/primitive-processing subsystem. They do not establish that it supplies the separate IWRAM targets `0x0300646C` / `0x0300682C`.

Added `docs/ARM_RASTERIZER_FINDINGS.md` and `asm/runtime/arm_rasterizer_641b8_64edc.dis.txt`. Next: isolate the remaining entry points from the relocation table and trace descriptor producers/callers.

## Completion estimate update

Overall traditional decompilation estimate remains conservative at **17%**. The ARM rendering module is now semantically mapped beyond a generic relocatable image, but gameplay state logic, audio, broad data classification, a complete build system, and matching-ROM verification remain substantial unfinished work. Matching-ROM build milestone remains **0%**.

## 2026-10-09 — ARM rasterizer copy helper reconstructed in C

Isolated the function entry at `0x08064E54` (the preceding `0x08064E50` word is zero/padding) and translated its gather-copy behavior into `src/arm_rasterizer.c`. Each output block contains eight 8-byte slices gathered from source rows separated by `r1` stride; the routine advances through 8-column groups and applies a `stride * 8 - 64` correction after each eight chunks. This is consistent with tile/swizzle preparation, but the caller's data format is not yet established. Added `docs/ARM_RASTERIZER_COPY_HELPER.md`, corrected the function map, and updated the rasterizer notes.

## Completion estimate update

Overall traditional decompilation estimate: **18%**. This pass converted a previously documented ARM helper into a C source reconstruction and clarified its exact entry boundary. The build/matching-ROM milestone remains **0%**; the project is still not a complete matching decompilation.

## 2026-10-10 — ARM rasterizer list processing recovered

Translated three ARM entries into source: `0x08064C38` as
`ArmRaster_InsertBucketItem`, `0x08064C8C` as `ArmRaster_BuildEdgeBuckets`,
and `0x08064DE0` as `ArmRaster_ProcessEdgeBuckets`. The insertion routine
creates/appends four-byte linked-list nodes with a signed-halfword sentinel;
the builder handles selected/default primitive ranges, applies a signed
orientation test, derives a 32-level bucket from fixed-point attributes, and
inserts accepted record indices; the dispatcher follows bucket chains,
resolves primitive records, invokes primitive-edge processing, and conditionally
dispatches row drawing. Added `docs/ARM_RASTERIZER_LISTS.md` and updated the function map.

Added a compile-only Makefile that builds all C translation units for ARM7TDMI,
using ARM state for the rasterizer image source and Thumb state for the other
units. This is a reproducible source-compilation milestone, not a ROM link or
matching build. Remaining work includes validating the rasterizer builder against a reference
emulator or disassembly-level test, recovering the rasterizer's caller and
descriptors, and replacing many unresolved runtime/gameplay functions.

## Completion estimate update — 2026-10-10

Overall traditional decompilation: **22%** (rough engineering estimate).
This pass adds source reconstructions for a linked-list primitive, its
primitive-bucket builder, and its bucket-chain dispatcher, plus a repeatable
ARM7TDMI compile-only target. The
matching-ROM build remains **0%**; compile-only object output must not be
mistaken for a linkable game or a byte-matching ROM.


## 2026-10-10 — relocatable ARM image loader recovered

Translated `0x0805EFC0` into `src/arm_rasterizer_loader.c`. The function either
allocates a `0xD24` heap descriptor and programs DMA3 to copy the ARM image, or
reuses an existing descriptor passed indirectly. It then rebases the specific
pointer fields selected by the table at `0x08064EDC`, leaving context offsets
`+0x40`, `+0x50`, and `+0x54` untouched. The loader's field-by-field map is
recorded in `docs/ARM_RASTERIZER_LOADER.md`, and startup now calls the recovered
working name rather than `sub_0805EFC0`.

The source compile target now covers 25 C translation units without compiler
warnings. This remains object compilation only; the heap allocator is still
incomplete, the project is not linkable as a game, and matching-ROM progress
remains 0%.

## Completion estimate update — 2026-10-10

Overall traditional decompilation: **24%** (rough engineering estimate). The
loader and three of its rasterizer support routines now have source-level
reconstructions, and all 25 current C units compile for ARM7TDMI. The matching-
ROM build remains **0%**.

## 2026-10-10 — dual-heap allocator reconstruction

Recovered both descriptor-backed allocator configurations from the `0x0805A3CC–0x0805A608` cluster. The main heap uses 32 descriptors from `0x02000000` and an IWRAM arena at `0x03001160` of size `0x4B20`; the alternate heap uses 32 descriptors from `0x02000200` and an EWRAM arena beginning at `0x02000400` with size `0x3FC00`. Reconstructed first-fit-by-address-gap insertion, descriptor-slot search, list unlink, and allocation counters.

A caller audit found an important representation error: both allocator front-ends return descriptor pointers, not payload pointers. Corrected `src/object_record.c` and `src/child_queue.c` to use descriptor `+0x00` for the payload while retaining the descriptor where the original structure expects it. See `docs/HEAP_FINDINGS.md` for addresses, layouts, and confidence boundaries.

Validation: clean ARM7TDMI object compilation of all 25 C source files, with no compiler warnings. This remains compile-only validation, not a matching-ROM build.

### Runtime-entry indexed initializer correction

Re-read `0x08062974` instruction-by-instruction. Its index is a signed halfword at `secondary_table + 0`, used to select a 32-bit value from `source_table`; the entry's `+0x08` field is loaded from the first word of the table rooted at `0x03000D98`. Corrected `RuntimeEntry_InitIndexed` accordingly. The previous C draft incorrectly treated the secondary-table pointer itself as an index into `0x03000D98`, which could select the wrong resource value.

## Pass 10 — object-table allocation correction (2026-10-10)

Rechecked `0x08062370` and `0x08062490` directly against Thumb instructions.
The helper at `0x080661E4` is an unsigned division routine, not an allocator.
The object-table initializer now computes the aligned quotient
`round_up(base / 0x28, 0x10)`, stores its positive and negative halfword forms,
and allocates `3*n + 40*count` bytes through `Heap_Alloc`. The auxiliary
`0x440`-byte block is allocated through `Heap_AllocAlt`. Both returned values
are heap descriptors; payload addresses are read from descriptor offset zero.

Also implemented the observed cleanup path at `0x08062370`: it stops the
associated hardware registers, frees the stored descriptors (not payload
pointers), and clears the corresponding runtime pointer globals. Full evidence
and remaining semantic uncertainty are in `docs/PASS10_OBJECT_TABLE_FIX.md`.

## Pass 11 — runtime record allocation recovered (2026-10-10)

Translated `0x0805AC4C` into `src/runtime_record.c`. The routine allocates a
0x10-byte alternate-heap record, dereferences the heap descriptor to get its
payload, then writes the four incoming values into fields at `+0x00`, `+0x04`,
`+0x08` (halfword), and `+0x0C`. Startup calls it with four zero arguments.
Also recovered the direct global setter at `0x0805AC80`, which stores a pointer
at `0x03005DC0`. Names remain neutral because the higher-level record purpose
is not yet proven. Evidence is in `docs/RUNTIME_RECORD_FINDINGS.md` and the
matching disassembly artifact.

Validation: source-level structure size is enforced with `_Static_assert`; a
clean ARM7TDMI object compilation is required before archiving. This pass adds
one compact but concrete runtime helper cluster. Matching-ROM build remains
0%.

## Completion estimate update

Overall traditional decompilation estimate: **31%**. This reflects one more
recovered runtime record allocator/setter and its exact field layout, not a
claim that 31% of ROM bytes are translated. Matching-ROM build remains **0%**.


## Pass 12 — surface/context constructor recovered (2026-10-10)

Replaced the `0x0805FEF4` interface stub with a field-by-field C reconstruction.
The routine allocates `0x44 + 2*width*height + 2*height` bytes from the alternate
heap, installs the payload at `0x03005DC4`, stores the descriptor pointer at
payload `+0x0C`, initializes observed fields and region pointers through `+0x40`,
computes the `+0x10` interval value using the internal division helper, and
reproduces the halfword writes at `0x04000134` and `0x04000128`. Exact graphics
semantics and peripheral register roles remain open. Evidence: `docs/SURFACE_CONTEXT_FINDINGS.md`.

## Pass 12 validation and completion estimate — 2026-10-10

The surface/context constructor is now source-level rather than a declaration-only
stub. Its function-specific disassembly is retained separately, the C structure
has compile-time offset/size assertions, and the entire 26-unit source set passes
ARM7TDMI compile-only validation with `-Wall -Wextra` and no warnings.

Overall traditional decompilation estimate: **32%**. This pass recovers one
medium-sized constructor and its memory/register contract; it does not yet
provide a linkable game or matching ROM. Matching-ROM build remains **0%**.

## 2026-10-10 — runtime-entry service pass

Recovered the per-entry service path at `0x080627CC` into `src/runtime_entry_service.c`: status gating, resource-record boundary calculations, terminal-status clearing, and the cursor-delta helper call are represented explicitly. Also corrected `FrameEvent_Service` to use the actual gate globals at `0x03005E1C` and `0x03005E44`, iterate the 0x28-byte runtime-entry table rooted at `0x03005E24`, and preserve the still-unresolved timing/transfer tail behind a clearly named helper. Added the matching disassembly and `docs/RUNTIME_ENTRY_SERVICE_FINDINGS.md`.

The helper at `0x0806625C` and the final timing/transfer tail remain unresolved. This pass increases the source-recovered surface but does not yet establish a matching-ROM build.

Current rough engineering estimate after this pass: **33% traditional decompilation**. This is a judgment-based estimate of recovered source/behavior, not a byte-count. Matching-ROM build remains **0% complete**.

### Runtime modulo helper resolved

Followed the call from `0x080627CC` into `0x0806625C`. Its behavior is unsigned remainder, including a zero-divisor path that returns zero. Added `src/math_runtime.c` with an equivalent shift/subtract implementation and replaced the provisional cursor-delta helper with `Math_ModuloUnsigned`. The relevant instructions are preserved in `asm/runtime/math_modulo_6625c.dis.txt`.

Current rough engineering estimate after the modulo-helper recovery: **34% traditional decompilation**. Matching-ROM build remains **0% complete**.

## Pass 13 — timer-window service and indirect callback ABI (2026-10-10)

Reconstructed the previously isolated tail of `0x08062814`. The routine samples
Timer0 at `0x04000100`, rounds its value to an even count, handles the wrap
sentinel, computes one or two elapsed segments, services the `0x28`-byte entry
pool, and dispatches segment callbacks through the pointer at `0x03000D8C`.
The second segment begins at `cursor - interval`; the final cursor is normalized
when it equals `context + interval`. The callback is kept neutral because its
higher-level role is not established.

A caller/callee ABI audit also corrected `RuntimeEntry_ServiceOne` at
`0x080627CC`: its caller passes `(entry, elapsed_window, threshold)` in `r0-r2`,
and the routine branches through the function pointer stored at ROM address
`0x0807D988` (currently `0x03006C60`). The previous source incorrectly treated
the ROM slot address as a context argument and used a four-argument helper.
The callback's IWRAM installation/source remains unresolved.

Added `docs/RUNTIME_ENTRY_TIMING_FINDINGS.md` and
`asm/runtime/runtime_entry_timing_627cc_62934.thumb.dis.txt`. Added host-side
exhaustive small-range and edge tests for `Math_ModuloUnsigned`; they pass.
The full 28-unit ARM7TDMI compile check also passes with no warnings.

Current rough engineering estimate: **35% traditional decompilation**. This is
an estimate of recovered source and behavior, not ROM-byte coverage. A linked
or matching-ROM build remains **0% complete**.

## Pass 14 — runtime script interpreter recovered (2026-10-10)

Translated the command loop at `0x08062C48` into `RuntimeScript_Service` in `src/runtime_script.c`.
Recovered its countdown pacing, 16-bit fixed-point delay commands, the `0x8`
entry-removal family, the `0x9` entry-creation family, `0xB0` saved-cursor jump,
`0xB1` skip, `0xB2` big-endian step update, `0xB3` error path, `0xC` source-record
selection, and `0xD` skip family. The script's 16 records are 0x24 bytes each;
each contains four 8-byte runtime-entry slots. The code uses existing entry
allocation/status/limit helpers rather than duplicating them.

Added `docs/RUNTIME_SCRIPT_FINDINGS.md` and the complete original instruction
region in `asm/runtime/runtime_script_62c48_62e74.thumb.dis.txt`. The C code
compiles cleanly, but the bytecode interpreter has not yet been exercised in a
GBA emulator, so runtime equivalence remains unverified.

Current rough engineering estimate: **38% traditional decompilation**. This is
an engineering estimate of recovered source and connected behavior, not a ROM
byte percentage. Matching-ROM build remains **0% complete**.

### Runtime script lifecycle controls

Continued through the adjacent routines at `0x08062B44`, `0x08062B50`, and
`0x08062BCC`. Added descriptor installation, stop/cleanup, and indexed start to
`src/runtime_script.c`. Start validates the index against descriptor offset
`+0`, loads two cursor words from its `+8` table, clears countdown/step state,
and enables the interpreter. Stop deactivates occupied script-owned entries
across the 16-record table before clearing the interpreter state. Original
instructions are retained in `asm/runtime/runtime_script_control_62b44_62c48.thumb.dis.txt`.

Updated estimate: **40% traditional decompilation**. The runtime script cluster
is now represented from descriptor setup and lifecycle through command
execution and per-frame timing integration. Emulator execution and matching-ROM
verification remain outstanding.

## Pass 15 — runtime buffer descriptor and row-copy path (2026-10-10)

Recovered `0x080631D4` and `0x08063210` into the new `src/runtime_buffer_descriptor.c`.
The constructor aligns its two dimension arguments down to even values, allocates
`2 * aligned_stride * row_count` bytes through the game's descriptor-returning
heap API, and stores both the heap descriptor and its payload address. The row
routine bounds-checks a signed row index, computes the source row using a
halfword stride, offsets the destination in halfword units, and dispatches the
copy through the callback slot at `0x0807D998` via the shared `bx r3` trampoline
at `0x08065C44`.

Added `docs/RUNTIME_BUFFER_DESCRIPTOR_FINDINGS.md` and preserved the exact
Thumb instructions in `asm/runtime/runtime_buffer_descriptor_631d4_63244.thumb.dis.txt`.
The concrete callback backend and broader semantic role of the descriptor are
still unknown; the source does not assign either one a guessed identity.

Validation: all 30 C translation units compile for ARM7TDMI without warnings;
`make test-all` passes the existing modulo and runtime-script host tests. These
checks do not establish emulator equivalence or a matching-ROM build.

Updated rough engineering estimate: **41% traditional decompilation**. The
matching-ROM build remains **0% complete**.

## Pass 16 — runtime block lookup helpers (2026-10-10)

Recovered three more routines from the 0xC4-stride runtime block manager into
`src/runtime_block_helpers.c`: the 256-slot free-descriptor scan at `0x08062FCC`,
the next-link tail walk at `0x0806307C`, and the bounds-checked payload-record
resolver at `0x080631B4`. Added field-layout assertions, an instruction dump, and
`docs/RUNTIME_BLOCK_HELPERS_FINDINGS.md`. The more complex insertion/release
routines remain evidence-backed disassembly rather than guessed C.

Validation: 31 C translation units compile for ARM7TDMI; existing host-side
modulo and script tests pass. The estimate is now **42% traditional
decompilation**; matching-ROM build remains **0% complete**.

## Pass 17 — runtime block allocator (`0x08062F20`)

Recovered the block-allocation front end into `src/runtime_block_allocate.c`.
It reserves an unused descriptor, appends allocations when the 0x100-slot
high-water limit permits, and delegates overflow/gap placement to the observed
`RuntimeBlock_Insert` routine. It records the payload address as the 0xC4-stride
pool base plus the selected slot offset and returns the descriptor, consistent
with the game's descriptor-based heap APIs. Added an instruction-level note in
`docs/RUNTIME_BLOCK_ALLOCATE_FINDINGS.md`.

Validation: all 32 C translation units compile for ARM7TDMI without warnings;
`make test-all` continues to pass. The gap insertion routine is still an
assembly-backed dependency, so full allocator runtime behavior is not yet
claimed as tested. Updated estimate: **43% traditional decompilation**; matching-
ROM build remains **0% complete**.


## Pass 18 — runtime block gap insertion (`0x08063090`)

Translated the linked-list insertion routine into `src/runtime_block_insert.c`.
It searches between adjacent occupied 0xC4-slot ranges, inserts a descriptor
when an interior gap is large enough, repairs both neighbor links, and returns
the first slot of the gap. It intentionally does not allocate at the head or tail;
those cases are handled (or rejected) by the original allocator's surrounding
logic. Added host tests for interior-gap placement, list-link updates, too-small
gaps, and the no-tail-gap behavior.

Validation: 33 C translation units compile for ARM7TDMI; `make test-all` passes
modulo, script-interpreter, and block-list tests. The release/destructor path is
still unresolved, and no ROM link/match has been achieved. Updated estimate: **45%
traditional decompilation**; matching-ROM build remains **0% complete**.

## Pass 19 — runtime block release (`0x08063004`)

Translated the release path into `src/runtime_block_free.c`. It calls the
existing child cleanup routine for each 0xC4-byte child, unlinks the block
record, preserves the observed high-water decrement and reset calls, and clears
only the payload field used by the free-descriptor scan. Added a findings note
that explicitly records the unusual global-update paths rather than silently
correcting them to a conventional linked-list allocator.

Validation: all 34 C translation units compile for ARM7TDMI without warnings;
`make test-all` passes. The block free path has compile validation only, not
emulator execution. Updated estimate: **46% traditional decompilation**; matching-
ROM build remains **0% complete**.

## Pass 20 — indexed table allocator and entry-status query (2026-10-10)

Recovered `0x08062C20` into `src/runtime_table_copy.c`: it checks the indexed
entry against the descriptor count, resolves the source pointer through the
`+0x0C` pointer table, and invokes the existing runtime-entry allocator. Also
added `RuntimeEntry_IsActive` for `0x08062E74`, preserving the behavior that any
nonzero status counts as active. Added separate findings notes and corrected the
function map to describe allocation rather than a generic copy operation.

Validation: all 35 C translation units compile for ARM7TDMI without warnings;
`make test-all` passes all current host tests. Updated estimate: **48% traditional
decompilation**; matching-ROM build remains **0% complete**.

## Pass 21 — child record cleanup (`0x080588CC`)

Recovered `ObjectChild_Cleanup` in `src/child_queue.c`, connecting the runtime
block release path to its actual per-child cleanup. It releases the resource
handle at `+0xB8` through the existing `0x08060AB8` boundary, frees the queue's
heap descriptor, and resets the queue state at `+0x74/+0x78/+0x7C`. Added
`docs/CHILD_CLEANUP_FINDINGS.md`; the resource-node unlink implementation itself
remains unresolved and is not guessed.

Validation: all 35 C translation units compile for ARM7TDMI without warnings;
all host tests pass. Updated estimate: **49% traditional decompilation**;
matching-ROM build remains **0% complete**.

## Pass 22 — resource-node unlink/recycle (`0x08060AB8`)

Recovered the previously external `ResourceNode_Unlink` boundary in
`src/resource_node.c`. The implementation now reproduces active-list unlinking,
free-list insertion, range-token release gating, auxiliary-node cleanup, the
recycle counter increment, and the post-operation active-list validation call.
Added field-offset assertions, `docs/RESOURCE_NODE_FINDINGS.md`, and an exact
Thumb disassembly artifact. Range-release and auxiliary-unlink helpers remain
explicit unresolved boundaries rather than guessed implementations.

Validation: all 36 C translation units compile for ARM7TDMI without warnings;
all existing host tests pass. The unlink routine is compile-validated but not
emulator-executed. Updated estimate: **50% traditional decompilation**;
matching-ROM build remains **0% complete**.

## Pass 23 — auxiliary resource-node unlink (`0x08060B5C`)

Recovered the auxiliary-node unlink/recycle helper as
`ResourceNode_UnlinkAuxiliary` in `src/resource_node.c`. It honors the state
byte at `+0x19`, repairs the active doubly linked list headed at `0x03005DF8`,
and pushes eligible nodes onto the free chain at `0x03005DE8`. This closes the
second list-management call made by `ResourceNode_Unlink`; auxiliary node
semantics remain intentionally neutral. Added a dedicated disassembly artifact
and findings note.

Validation: all 36 C translation units compile for ARM7TDMI; all current host
tests pass. Updated estimate: **51% traditional decompilation**; matching-ROM
build remains **0% complete**.

## Pass 24 — resource-node lifecycle execution tests (2026-10-11)

Added Linux simulated-IWRAM tests exercising the recovered primary and
auxiliary node unlink routines with original global RAM addresses. Four
scenarios pass: middle-node unlink with range release and auxiliary recycling,
head unlink with gated release, auxiliary tail unlink, and primary tail unlink.
The host harness stubs the two unresolved external dependencies. All 36 C
translation units still compile for ARM7TDMI and `make test-all` passes.
Completion estimate remains **51%** because this is validation, not additional
source coverage. Matching-ROM build remains **0%**.

## Range manager recovery — 2026-10-11

Reconstructed `0x0806082C` as `RuntimeRange_Release` in `src/runtime_range.c`. Confirmed IWRAM list roots at `0x03005DC8` and `0x03005DD8`, 8-byte nodes with two halfwords and next pointer, adjacent-range extension, sorted spare-node insertion, and second-pass coalescing/recycling. Preserved raw Thumb disassembly and documented remaining diagnostic-path caveat in `docs/RANGE_RELEASE_FINDINGS.md`. All 37 source files compile and existing host tests pass. Matching-ROM build still absent.

### 2026-10-11: Range-release behavioral tests
- Added `tests/test_runtime_range.c` (seven scenarios on mapped GBA IWRAM).
- Integrated `test-range` into `make test-all`.
- All five host-side test suites passed; 37 ARM7TDMI translation units compile.
- Estimate remains 52%; no matching-ROM build yet.

## 2026-10-11: range arena reset
Recovered ROM `0x08060958` into `src/runtime_range_init.c`, including object-token release, reserved range initialization, and 31-node spare chain. Added focused Thumb disassembly, findings, and a host test. 38 C translation units now compile and six host test suites pass. No matching ROM build yet.

## Range allocation recovery (2026-10-11)

Recovered ROM `0x080607B4` as `RuntimeRange_Alloc`, completing the currently identified range manager trio (reset, allocate, release) at source level. Added seven host-side scenarios and preserved Thumb disassembly. All 39 C translation units compile for ARM7TDMI and all seven host test suites pass. Matching-ROM build still unavailable. Overall recovery percentage remains a subjective estimate.

## 2026-10-11: resource-manifest original-ROM validation

Added `tools/verify_resource_manifest.py`, `tests/test_resource_manifest.py`, and `docs/RESOURCE_MANIFEST_VERIFICATION.md`. The tool checked 110 manifest records (108 primary + 2 alias-reachable) in the locally supplied original ROM, including table pointers, header sizes, aligned spans, and adjacent record boundaries. In-memory corruption tests for a size and pointer were detected. All 39 C units compiled and all existing host test suites passed. Completion estimate remains 54%: this is a verification improvement, not a newly recovered gameplay subsystem.

## 2026-10-11: full resource directory audit

- Verified all 32 directory slots, including repeated pointer-table aliases in slots 7–31.
- Confirmed all 110 manifested record headers use `{0, data_size, 0, 0}`.
- Identified unmanifested second pointer in slot 6 (`0x0821AAF4`), retained as an open question.
- Added `tools/audit_resource_directory.py` and corruption tests in `tests/test_resource_directory_audit.py`.
- This is a metadata/verification milestone, not new recovered gameplay C. Estimate remains 54%.

## 2026-10-11: alias-target record recovery

Confirmed the bank-6 second pointer at `0x0821AAF4` is a standard 16-byte-header record with 0x57 bytes of data; added it to the resource manifest. Identified both alias targets and their precise sizes: `0x0807DCA4` (0x40580 bytes) and `0x080BE234` (0x4D780 bytes), repeated through 25 directory slots. Added ROM-backed alias metadata validation and deliberate header-corruption tests. This is metadata recovery; 54% estimate unchanged.

## 2026-10-12: complete resource-pointer coverage

Cross-checked all 32 resource directory slots and all 134 pointer entries
against the 111 distinct records in the manifest. Fixed stale bank-6 sentinel
comments and unique-record counts in the C metadata and earlier findings.
Added `tools/check_resource_coverage.py` and mutation-based regression tests.
All 39 ARM7TDMI translation units compile and all existing host tests pass.
Source-recovery estimate remains 54%; matching-ROM build still unresolved.

## 2026-10-12: Resource reference trace

Added `tools/trace_resource_references.py` and three regression tests. Confirmed the sole aligned direct directory reference at `0x0804AF50`, recovered the two distinct alias-table addresses and their links to large resource records, and identified the bank-6 record reference at `0x08075200`. See `docs/RESOURCE_REFERENCE_TRACE.md`. No gameplay function has yet been reconstructed from this trace, so the source-recovery estimate remains 54%.

2026-10-12: Reconstructed ROM 0x0804AF08 resource directory selection in src/resource_directory_dispatch.c, preserving the literal-pool reference to 0x08075640 and tracing the two arguments to 0x080629B4. Saved exact disassembly and notes in docs/RESOURCE_DIRECTORY_CONSUMER.md. Source compilation verified; matching ROM not established. Discovered independent public matching-decomp project for cross-checking.

2026-10-12: Traced 0x0804AF08 -> 0x080629B4 -> 0x08062974. Corrected directory pair interpretation to (pointer-table base, signed-index descriptor), verified all 32 initial selections, added ROM-backed corruption tests and trace tool.

## 2026-10-14: ROM-backed directory descriptor audit

Confirmed the signed-index descriptors used by all 32 directory slots are
ROM-backed, with nine unique addresses and two repeated alias descriptors.
All initial signed indices are zero. Added a ROM-backed descriptor-storage
audit and three negative tests. This corrects the earlier suggestion that
these original descriptor bytes may themselves be mutable gameplay indices.
No additional function is claimed reconstructed in this pass; source recovery
estimate remains 54% and matching-ROM build is still outstanding.

## 2026-10-14: signed-index directory probe

Added `tools/probe_directory_indices.py` and a ROM-free synthetic regression
suite for positive and negative signed halfword indices, shared descriptor
aliases, and malformed resource pointers. This enables read-only inspection
of hypothetical pointer-table selections without implying they occur during
actual gameplay. No new gameplay routine reconstructed; source recovery
estimate remains 54%, matching ROM build still outstanding.

2026-10-14: Added aligned pointer cross-reference inventory for all unique
resource directory table and descriptor addresses, separating directory entries
from external candidates. Synthetic tests pass; no runtime writes inferred.
Estimate remains 54%.

## 2026-10-16: ARM rasterizer source recovery

Recovered C behavior for the primitive-edge processor, row renderer, and two
sample generators at `0x08064364`, `0x08064850`, `0x080641B8`, and `0x08064218`.
Both rasterizer calls in the bucket walker now have source definitions, with
shared declarations in `include/arm_rasterizer.h`; both source units use ARM
state. All 42 C translation units parsed for their configured ARM/Thumb modes,
and all 31 Python tests plus the ROM-backed alias check passed. `make check` and
`make partial-link` could not run because the required build tools are missing;
no ROM was built. The historical 54% figure remains an estimate and was not
recalculated. See `docs/PASS12_DEVELOPMENT_2026-10-16.md` for limits.

## 2026-10-16: vertex-parameter rasterizer recovery

Added C behavior reconstruction for `0x08064A14` as
`ArmRaster_ApplyVertexParameters`, including the second ROM table pointer at
`0x0874CC60`, signed fixed-point transforms, row-byte output, and signed clamp
behavior. All 42 C translation units parse for their configured ARM/Thumb
modes, all 31 Python tests and the ROM-backed alias check pass. This remains
source-level validation only; no ARM objects or ROM were built. The historical
54% estimate remains unrecalculated. See
`docs/PASS13_DEVELOPMENT_2026-10-16.md`.

## 2026-10-16: ARM vertex-row transform recovery

Added `ArmRaster_TransformVertexRows` for image entry `0x08064AFC`, preserving
the observed 10-byte input, 6-byte target, and 16-byte output steps, optional
interpolation, ARM multiply-accumulate order, projection branch, and signed
minimum stores. Static recovery checks and source parsing pass. The 42-unit
frontend parse and 32 Python regressions pass, along with the ROM-backed alias
check. The historical ~54% remains an estimate, not a measured percentage;
there is no current object audit or matching-ROM build. See
`docs/PASS14_DEVELOPMENT_2026-10-16.md` for exact verification limits.

## 2026-10-16: runtime-record initialization linkage correction

Replaced the stale `sub_08050388` call in `GameState_Init` with the recovered
`RuntimeRecord_Clear` symbol and corrected that routine to preserve manager
pointer `+0x00`, as the ROM does. The function map now reflects the 0x18-byte
record stride. This closes a source-level linkage gap and repairs one recovered
behavior; it does not replace an object-symbol audit. The rough overall
estimate remains **~54%**, unrecalculated and not measured coverage. Matching-
ROM progress remains unverified.

## 2026-10-16: frame-preparation layout correction

Rechecked `0x08049268` against its Thumb listing and corrected its recovered C
to use the context base `0x03000650`, while treating the pointer stored at
`0x03000FB0` as a separate object whose `+0xC26` halfword is reset. Renamed the
caller binding from provisional `GameState_Init` to `GameState_FramePrepare`
and corrected all recovered field offsets and access widths, including the
byte at context `+0x7F`. This repairs the ROM-call binding and source-level
layout; it does not establish object-level linkage or a matching ROM build.

The historical **~54% completion estimate remains unchanged and is not
measured coverage**. See `docs/PASS16_DEVELOPMENT_2026-10-16.md` for checks and
current build limits.

## 2026-10-16: active resource-list validator recovery

Recovered `ResourceNode_ValidateActiveList` at `0x080604F8` from the original
Thumb bytes. It walks the active list, checks that the head has no predecessor
and that each node's backward link agrees with the prior node, and passes one
of three ROM message pointers to the already-recovered return-only
`sub_08057C5C` on mismatch. It continues traversal without fixing or aborting
the list. Removed the source-level external declaration and expanded the host
C harness with malformed-link cases; the local Windows environment could not
execute that Linux-only `mmap` harness. The Python regression suite and ARM
frontend parse are run for this pass. The overall **~54% remains an unchanged
rough estimate, not measured coverage**; object-level unresolved counts and a
ROM build remain unavailable.

The same pass corrected diagnostic call bindings: failure sites in
`RuntimeMemory_Init` and `RuntimeBlock_FindFree` call the one-argument
return-only `0x08057B60`; `RuntimeObjectTable_Init` calls the two-argument
`0x08057C5C` with the allocation size. This removes the stale `FatalError`
source import without asserting fatal behavior. Verification: 37 Python tests,
42 C frontend parses with zero errors, and a ROM-byte check matching all 32
Thumb halfwords plus three literal pointers and call targets. The Linux-only C
host harness itself remains unrun because WSL startup is denied here.

## 2026-10-16: runtime record manager recovery

Reconciled `RuntimeRecord_Init` and `RuntimeRecord_Update` with the Thumb code.
The initializer preserves the allocation descriptor separately from its
payload, copies records from a linked source list, and returns early on zero
size or allocation failure with the ROM's exact diagnostic arguments. The
update loop now integrates position, velocity, and acceleration, mirrors
positions to the source list, and applies the signed boundary/reversal logic.
The `sub_08057C5C` declaration now accepts the one-, two-, and three-argument
call shapes supported by its ROM-confirmed save/restore/return sequence.

The pass-specific ROM check matched 176 Thumb halfwords, two diagnostic
pointers, three direct call targets, and the `0x08057C5C` return-only bytes.
Completion remains **approximately 54%**, unchanged and not measured coverage;
the newly verified counts describe this pass only. No candidate ROM was
produced because this host lacks the ARM build tools and the project has no
recovered ROM linker layout. See `docs/PASS18_DEVELOPMENT_2026-10-16.md`.

## 2026-10-16: object-record update recovery

Recovered `RuntimeObject_UpdateRecordArray` at `0x08050A74` and
`RuntimeObject_UpdateRecord` at `0x08058F18`. The batch routine adds header
halfwords at `+0x02/+0x04` and walks `+0x0C` records at `0x88`-byte intervals.
The per-record routine updates and mirrors two words, makes the flag-gated
`0x08058F84` call, and follows its scaled arithmetic path. The sibling calls
at `0x080596D0` and `0x08058F84` remain unresolved externals.

Verification matched 82 Thumb halfwords across four saved ranges and decoded
five direct-call targets from the supplied ROM. All 41 Python tests passed,
and libclang parsed 43 ARM7TDMI C translation units with zero errors. The
historical **~54% remains unchanged and is not measured coverage**. A ROM build
remains unavailable because the host lacks the ARM toolchain and the project
has no recovered linker layout.

## 2026-10-16: object-selection entry-table recovery

Recovered `RuntimeObject_InitializeEntryTable` at `0x08050AA0`, including
descriptor/payload handling, 0x30-byte input and 0x1C-byte output strides,
selected-index behavior, fixed-point table interpolation, and final dispatch.
Also source-defined the compact byte lookup at `0x08063AC4`. The other four
direct callees in the builder remain explicit unresolved externals.

ROM verification matched **216 halfwords across two ranges** and decoded
**20 direct Thumb calls** (eight outgoing and 12 incoming). These are measured
pass counts, not total recovery coverage. The overall completion figure stays
**approximately 54%**, unchanged and unmeasured; a complete ROM build remains
unavailable without an ARM toolchain and recovered linker layout. All 44
Python tests passed and libclang parsed all 44 C translation units with zero
errors. `make partial-link` could not start because `make` is unavailable.
See `docs/PASS20_DEVELOPMENT_2026-10-16.md`.

## Pass 21 — resource-node selection path (2026-10-16)

Recovered `0x080609E8` as the active-list insertion-point scan,
`0x08060A04` as free-node acquisition and activation, `0x08060B8C` as the
selection-entry field initializer, and `0x080611B4` as the selection-context
initializer. The direct source gap in the builder is reduced from four
address-named callees to one: `0x08061684` remains unresolved. Added ROM-backed
range and BL-target verification plus focused regressions.

The supplied ROM check matched 214 Thumb halfwords across three ranges and
decoded seven direct calls (three calls made by the new resource-node code and
four integration call sites in the existing builder). The completion estimate
remains roughly 54%, unchanged and not measured coverage. ARM object output,
partial linking, and a candidate ROM are still unavailable because this host
lacks `make` and an ARM compiler/linker, and the original GBA link layout is
not recovered. See `docs/PASS21_DEVELOPMENT_2026-10-16.md`.

## Pass 22 — selection dispatcher and context fields (2026-10-16)

Source-defined the Thumb wrapper at `0x08061684`, its context reset at
`0x0806124C`, and five adjacent packed-field helpers at `0x08061154`,
`0x08061170`, `0x0806117C`, `0x08061184`, and `0x0806118C`. The builder now
uses `RuntimeObjectSelection_Dispatch`; its downstream finalizer
`0x080614E0` and embedded-subcontext release `0x08060D00` remain unresolved.
The Pass 22 verifier checks 60 halfwords across seven ranges and 10 direct
call targets. The new translation unit is configured for Thumb state, but no
object-level ISA/interworking check or ROM build was possible without a C/ARM
compiler, linker, or `make`. The overall estimate remains **~54%**, unchanged
and not measured coverage. See `docs/PASS22_DEVELOPMENT_2026-10-16.md`.

## Pass 23 — resource-node chain release (2026-10-17)

Recovered `0x08060D00` as `ResourceNode_ReleaseChain` and connected it to the
selection-context reset. It recycles the counted active-list segment and its
auxiliary/range ownership, repairs list links, prepends the segment to the free
chain, clears the observed context fields, and validates the result. The ROM
verifier matches 94 Thumb halfwords and five direct call targets. All 55 Python
unit tests passed with the local ROM supplied; five additional ROM-backed
checks passed. Libclang parsed all 45 C translation units plus both updated C
behavior harnesses with no diagnostics. The host has no C/ARM compiler,
linker, or `make`; no objects, partial link, or candidate ROM were produced.
The rough **~54%** completion estimate remains unchanged and unmeasured;
matching-ROM progress remains **0%**. See
`docs/PASS23_DEVELOPMENT_2026-10-17.md`.

## Pass 24 — selection finalizer and chain operations (2026-10-17)

Recovered `0x08060C40` as `ResourceNode_AllocateChain`, `0x08060DBC` as
`ResourceNode_ResizeChain`, `0x08064F5C` as the selection-code counter, and
`0x080614E0` as `RuntimeObjectSelection_Finalize`. The dispatcher now passes a
named zero-terminated code stream. The finalizer grows the embedded chain,
configures ordinary entries, carries code 32 as a cursor marker, and delegates
the remaining layout/context work to still-unresolved `0x08061260`.

The ROM inspection also corrected Pass 23's chain-release model:
`0x08060D00` zeros the context count at `+0x08` as well as its head and tail.
It preserves context `+0x2C`; the C source and harness now match both details.
The original ROM verifiers
matched **228 halfwords and 10 calls** for the chain-operation ranges and **210
halfwords, seven calls, and three literals** for the finalizer range. The
previous release-chain check also passes at 94 halfwords and five calls. The
Python suite and frontend syntax checks are recorded in the pass report.

The overall completion figure remains the historical **~54% estimate**, not
measured source coverage. Matching-ROM progress is **0%**. No object build,
link, or candidate ROM is available because this host has no C/ARM compiler,
linker, or `make`, and the original GBA link layout is not recovered. See
`docs/PASS24_DEVELOPMENT_2026-10-17.md`.

## Pass 25 — selection layout and context correction (2026-10-17)

Recovered the layout loop at `0x08061260` and flags wrapper at `0x080614D4`.
The source models the two coordinate bases, mode-specific initial X offset,
per-entry projection and row wrapping, optional record scale, anchor-marker
handling, signed row step, and final vertical correction from the upper flag
bits. The finalizer now calls the named layout routine.

Rechecking the adjacent initializer corrected a prior context-layout mistake:
the halfword at `+0x08` stores caller-provided selection flags, `+0x0A` is the
cursor, `+0x0C` is the extent, and `+0x04` stores the scaled Y coordinate.
Pass 21 had mislabeled these fields and had treated the final initializer
argument as ignored; both the context source and regression assertion now
match the observed ROM stores.

The saved ROM range matched **320 Thumb halfwords** and decoded the wrapper
call to `0x08061260`; the existing finalizer verifier continues to check its
call site. The Python suite and available C frontend checks are recorded in
the pass report. No ARM object build, partial link, or candidate ROM was
produced. The historical **~54% completion estimate remains unchanged and
unmeasured**; matching-ROM progress remains **0%**. See
`docs/PASS25_DEVELOPMENT_2026-10-17.md`.

### Development pass 26 (2026-10-17)

Recovered the runtime-object affine transform at `0x08058F84` and its helpers
at `0x08059A8C`, `0x08059ADC`, `0x08059B24`, and `0x08059FC4`. The updater now
calls the named transform implementation; `0x080596D0` remains an explicit
external. The ROM verifier matched **352 Thumb halfwords**, **seven direct
calls**, and **12 literal words** across five ranges. Five focused tests
passed. Full-suite, frontend, and archive checks are recorded in
`docs/PASS26_DEVELOPMENT_2026-10-17.md`.

The historical **~54% completion estimate remains unchanged and unmeasured**;
matching-ROM progress remains **0%**. No ARM object build, partial link, or
candidate ROM was produced.

### Development pass 27 (2026-10-17)

Recovered `RuntimeObject_UpdateDisplayRegion` at `0x080596D0`, its frame
wrapper at `0x08059928`, and corrected the three BG register-address helpers
at `0x080599CC`, `0x08059A0C`, and `0x08059A4C`. The updater now supplies the
two register values left in `r1/r2` by the original caller. ROM checks matched
**421 Thumb halfwords**, **seven direct calls**, and **12 I/O literals** across
six ranges. All 74 Python tests and all 49 C frontend parses passed. The
`0x08059334` transfer backend remains a placeholder, so pixel equivalence is
not established. See `docs/PASS27_DEVELOPMENT_2026-10-17.md`.

The historical **~54% completion estimate remains unchanged and unmeasured**;
matching-ROM progress remains **0%**. No ARM object build, partial link, or
candidate ROM was produced.

### Development pass 28 (2026-10-17)

Recovered `RuntimeObject_InitializeDisplayState` at `0x08059958` and the
record `+0x64` mask helper at `0x080599B8`. The initializer clears the observed
IWRAM state bytes and BG scroll offsets, then initializes BG2/BG3 affine state.
Its three direct incoming calls and four outgoing helper calls are ROM-checked.
The verifier matched 63 Thumb halfwords across five ranges and three IWRAM
pointer literals. Caller bodies remain unrecovered, and no direct caller was
found for the flags helper.

The overall estimate remains **~54%**, unchanged and not measured coverage;
matching-ROM progress remains **0%**. The display-transfer backend remains a
placeholder. All 78 Python tests passed, and libclang parsed all 50 C
translation units with zero diagnostics. Object-level linkage and a candidate
ROM remain unverified. See
`docs/PASS28_DEVELOPMENT_2026-10-17.md`.

### Development pass 29 (2026-10-17)

Recovered five display-control routines at `0x08059C3C`, `0x08059CD8`,
`0x08059CEC`, `0x08059D14`, and `0x08059D28`. These write/read the low two
bits of BGxCNT, select the control register from a record byte, and update the
per-background enable bit in DISPCNT. The ROM verifier matched 218 halfwords
across ten ranges, 12 direct calls, and four mask literals. The five incoming
caller bodies remain unknown in source.

All 84 Python tests passed and 51 C translation units parsed with zero frontend
diagnostics. The rough **~54%** estimate remains historical and unmeasured;
matching-ROM progress remains **0%**. No object build or candidate ROM is
available. See `docs/PASS29_DEVELOPMENT_2026-10-17.md`.

### Development pass 30 (2026-10-17)

Recovered two record-based display wrappers at `0x0804A7EC` and
`0x0804A7FC`. The second follows the pointer at record `+0x88`, reads its
background-memory index at `+0x5D`, and dispatches through the shared Thumb
`BX r3` entry at `0x08065C44` to the even IWRAM pointer stored at `0x0807D994`;
the backend behavior remains unknown. ROM checks matched 52 Thumb halfwords,
two direct calls, two pointer literals, and all twelve register entries in the
adjacent interworking thunk family. The larger caller at `0x0804A748` remains
open because its incoming `r8` contract is unresolved.

All 89 Python tests and 52 C frontend parses passed. The rough **~54%** source
estimate is unchanged and unmeasured; matching-ROM progress remains **0%**.
No ARM objects, partial link, or candidate ROM were available from this host.
See `docs/PASS30_DEVELOPMENT_2026-10-17.md`.

### Development pass 31 (2026-10-17)

Recovered `ChildRuntime_InitVariantC` at `0x08058C98`, including its nested
record setup, byte-sized background-memory allocation counters, opaque
operation-slot call, and final BG control register write. Its ROM checks matched
233 Thumb halfwords, four call destinations, and five literal words across the
initializer, its observed caller setup, and the shared `BX r3` entry. Also
recovered the five-argument record initializer at `0x0805B268`; its ROM checks
matched 22 Thumb halfwords and its call from `0x0804A780`. The callback target
remains the even ARM address `0x03006FAC`, with its behavior unresolved. The
surrounding caller at `0x0804A748` is still not source-defined because its
incoming `r8` contract remains open.

The historical source-recovery estimate remains **~54%**, rough and
unmeasured. Matching-ROM progress remains **0%**. This host still lacks the
ARM compiler/linker and original section layout needed for a verified ROM
build; compile checks do not establish a candidate or matching ROM. See
`docs/PASS31_DEVELOPMENT_2026-10-17.md`.

All 98 Python tests passed with the locally supplied ROM enabled, and libclang
parsed 54 C translation units for ARM7TDMI with zero diagnostics. These are
source, frontend, and ROM-byte checks; they do not constitute a linked object
or ROM build.

## Pass 32 — 2026-10-17

Recovered the neighboring display-state field setters and indexed-address
helper at `0x0805B284`–`0x0805B294`. The ROM check matched 22 Thumb halfwords,
four direct calls into the address helper from `0x0805B2A4`, and its
`0x000003FF` index mask. Added an IWRAM target pointer audit: the only literal
word occurrence of `0x03006FAC` is at `0x0807D994`; 34 occurrences of the slot
address itself remain reference candidates, not decoded xrefs. The target's
code image and installer remain unresolved.

ROM verifiers for passes 26–32 passed. All **107 tests passed with the
original ROM supplied and no skips**. Libclang parsed **55 C translation units**
for ARM7TDMI with zero diagnostics. These results establish source syntax and
ROM-byte consistency only; there is still no object/link build or candidate
ROM. This host lacks the ARM toolchain and the original linker layout.

The historical source-recovery estimate remains **~54%**, rough and
unmeasured. Matching-ROM progress remains **0%**. See
`docs/PASS32_DEVELOPMENT_2026-10-17.md`.

## Pass 33 — 2026-10-17

Recovered the complete `0x0805B2A4` routine as
`RuntimeDisplay_BlitIndexed4bppTile`. The ROM reads eight packed-pixel rows,
selects four destination tile addresses from map entries `0/1/32/33`, shifts
each row by the low three coordinate bits, and ORs clipped fragments into
neighboring 32-byte tiles. Its caller at `0x0805B638` computes the tile-map
cell and passes the coordinates using the observed four-register-plus-stack
ABI. ROM checks cover 150 Thumb halfwords, five call destinations, and ten
conditional branch targets. The name/format interpretation is supported by
the 4-bit shifts and 32-byte blocks; runtime pixel equivalence remains
untested.

ROM verifiers for passes 26–33 and the pass 32 IWRAM pointer audit passed.
All **112 tests passed with the original ROM supplied and no skips**. Libclang
parsed **56 C translation units** for ARM7TDMI with zero diagnostics. No
object/link build or candidate ROM was produced. The existing source estimate
remains **~54%**, rough and unmeasured; matching-ROM progress remains **0%**.

## Pass 34 — 2026-10-17

Recovered `RuntimeDisplayState_InvokeRecordOperations` at `0x0805B3B8`.
It follows the object pointer at record `+0x00`, dispatches `(0, VRAM +
object[0x5D] * 0x4000, object_word[0x74])` and `(0, VRAM + object[0x5C] *
0x800, 0x800)` through the shared Thumb-to-ARM thunk, then stores halfword 1
at record `+0x0E`. The body’s incoming caller was not found, and target
`0x03006FAC` remains unresolved.

The historical source-recovery estimate remains approximately **54%** and is
not measured coverage; matching-ROM progress remains **0%**. Pass-specific
ROM checks, tests, parser results, and archive integrity are recorded in
`docs/PASS34_DEVELOPMENT_2026-10-17.md`.

## Pass 35 — 2026-10-17

Recovered `RuntimeDisplay_ComputeSequenceMetric` at `0x0805B400`. It scans a
zero-terminated byte sequence, adds five for byte `0x20`, and for other bytes
adds the caller's base metric, optionally subtracting a second lookup from the
ROM table at `0x0807D9A4`. Its direct caller at `0x0805B4C0` supplies the
sequence, table offset, and base metric; the larger display routine remains
source-open. The result is used in a mode-dependent origin adjustment, while
the table's product-specific meaning remains unknown.

The `0x03006FAC` callback installation remains unresolved. A range check shows
that it would fall outside the `0xD24` ARM module under the hypothesized base
`0x030061B8`; this rejects only that mapping, not other installation paths.
Pass-specific ROM evidence, suite results, frontend parsing, and archive
integrity are recorded in `docs/PASS35_DEVELOPMENT_2026-10-17.md`. The overall
estimate remains the historical rough **~54%**, not measured coverage.

## Pass 36 — 2026-10-17

Recovered `RuntimeDisplay_DrawGlyphSequence` at `0x0805B440`, the internal
descriptor lookup at `0x0805B814`, and argument setups at all five direct
callers. The renderer reserves map entries with the record's palette bits,
dispatches initialization of any newly allocated tile span through the known
generic callback wrapper, maps sequence bytes through `0x0807D9A4`, and feeds
the descriptor-backed 8x8 blocks to `RuntimeDisplay_BlitIndexed4bppTile` at
`0x0805B2A4`. It returns the ending X coordinate. The callback implementation
and language-specific control-byte meanings remain unresolved. The sequence
metric's mode-2 alignment is corrected to logical half (`metric >> 1`), as
shown by the Thumb LSR instruction.

The Pass 36 verifier matches **333 Thumb halfwords**, **11 direct calls**,
**20 conditional and 3 unconditional branch targets**, and **4 literal words**
across eight ranges. It includes all five observed callers. The pass tests,
full ROM-enabled suite, ARM7TDMI frontend parsing, and archive integrity are
recorded in `docs/PASS36_DEVELOPMENT_2026-10-17.md`. The source estimate stays
at the historical **~54% rough estimate**, not measured coverage; matching-ROM
progress remains **0%**. This host still cannot generate ARM objects or link a
candidate ROM.

## Pass 37 — 2026-10-17

Recovered `RuntimeDisplay_ProcessByteStream` at `0x0805B824` and its direct
calls into the glyph-sequence renderer. It buffers ordinary bytes; `0xFB`
updates record `+0x0D`, `0xFC` flushes and then updates record `+0x0C`, line
feed flushes/resets X/advances Y by `+0x0D`, and `0xFF` or a later NUL flushes
and returns. An initially empty stream returns without drawing. Bytes `0xFD`
and `0xFE` are ordinary buffered bytes. The mutable record-byte meanings stay
address-based. The full-ROM scan found zero direct Thumb BLs, zero direct
Thumb branches, and zero stored Thumb pointers to the parser entry; its
incoming dispatch remains unresolved.

The pass's ROM verifier, complete test suite, ARM7TDMI frontend parse,
source-level renderer-call check, toolchain availability, and archive checks
are recorded in `docs/PASS37_DEVELOPMENT_2026-10-17.md`. The historical overall
source estimate remains approximately **54%**, rough and not measured coverage;
matching-ROM progress remains **0%** unless a true candidate build is produced.

## Pass 38 — 2026-10-17

Recovered `CollisionData_BuildSplineIndex` at `0x0805B8E8` and its packed
record lookup helper at `0x0805DBA4`. The builder resolves three source-relative
offsets, clamps a signed count above 64 after the return-only diagnostic,
stores one pointer per packed entry, and clears three observed state fields.
The helper walks using the 32-bit stride at each entry `+0x04`. A whole-ROM
aligned Thumb-BL scan found nine call sites to each entry. The following
allocator/copy routine at `0x0805B95C` and callback slot `0x0807D998` remain
unresolved.

ROM-byte checks, tests, ARM7TDMI frontend parsing, archive integrity, and build
tool availability are recorded in `docs/PASS38_DEVELOPMENT_2026-10-17.md`.
The historical source-recovery estimate remains **approximately 54%**, a rough
value without a measured denominator; matching-ROM progress remains **0%**.


## Pass 39 — 2026-10-20

Recovered `CollisionData_InitializeOwnedSegments` at `0x0805B95C` from the supplied ROM. Added the C source reconstruction, instruction listing, ROM-backed verifier, regression tests, and pass notes. Verified 123 Thumb halfwords, 6 call targets, 9 conditional branches, 2 unconditional branches, 4 literal loads, and 3 literal words; the existing Pass 38 collision-spline verifier also passes. The callback installed at `0x0807D998` remains unresolved.


## Pass 40 — shared runtime-copy callback ABI (2026-10-20)

The ROM word at `0x0807D998` contains the even ARM-state IWRAM target
`0x03007034`. Both `RuntimeBuffer_CopyRow` (`0x08063210`) and
`CollisionData_InitializeOwnedSegments` (`0x0805B95C`) load this slot and pass
source, destination, and byte count through the shared `BX r3` trampoline at
`0x08065C44`. The shared copy-like ABI is now ROM-verified; the code installer
and target implementation remain unresolved. `make test-all`, `make partial-link`,
and all 28 ROM-backed `verify-*` Make targets pass. The relocatable object is
still not a ROM and matching progress remains 0%. See
`docs/PASS40_DEVELOPMENT_2026-10-20.md` and `docs/MATCHING_ROM_PLAN.md`.


## Pass 41 — runtime-image bounds audit (2026-10-20)

Audited the known ARM runtime image at ROM `0x080641B8..0x08064EDC` (`0xD24`
bytes). Under the explicitly hypothetical base `0x030061B8`, renderer targets
`0x0300646C` and `0x0300682C` are within range, while `0x03006FAC` and
`0x03007034` fall `0xD0` and `0x158` bytes beyond it. The assumed base remains
unproven; this is a negative constraint, not identification of another installer.
Added a range-audit tool, JSON evidence report, Make targets, and three tests.
No matching ROM candidate has been produced; byte-match progress remains 0%.

## Pass 48 (2026-10-24)
Original-ROM validation and callback-installer candidate scan completed; see `docs/PASS48_DEVELOPMENT_2026-10-24.md`. No callback implementation claimed.


## Pass 49 (2026-10-24)

Audited the Thumb routine at `0x08065994` against the supplied original ROM.
The routine takes `(source, destination, halfword_count)` in `r0-r2`, writes
DMA3 SAD/DAD/CNT at `0x040000D4`, `0x040000D8`, and `0x040000DC`, uses the
32-bit CNT write to set the enable bit in `0x040000DE`, and polls until the
DMA enable bit clears. It also temporarily zeros the halfword at `0x04000208`
and restores its saved value after the transfer; it updates the BG2X register
word at `0x04000204` from state at `0x03005E9C`. The visual purpose of these
display-register side effects is not yet established.

This pass also corrected the DMA-register labels in
`tools/audit_iwram_install_candidates.py`: `0x040000D0` is DMA2CNT_L, while
`0x040000D4` is DMA3SAD (not DMA3DAD); the scan now includes DMA3CNT_H at
`0x040000DE`. Regenerated candidate report contains 24 references (8 IWRAM
address literals and 16 DMA-register literals). These labels were wrong in the
Pass 48 report and are corrected in the Pass 49 report. The installer for the
upper-IWRAM callback at `0x03007034` remains unresolved; no causal connection
to `0x08065994` is claimed.

## Pass 50 — input-mask caller triage (2026-10-25)

Added a ROM-backed audit for the instruction fingerprint at `0x080517A4` and
its raw Thumb BL-shaped references. The original ROM contains 47 linear-scan
candidates targeting that address; these are not all confirmed calls because a
whole-ROM scan may encounter embedded data. The audit also identified an
important mismatch: the current `src/input.c` reconstruction reads
`0x03005E98`, but the bytes at `0x080517A4` instead load a literal from
`0x03000F48` and use a second PC-relative word at `0x080517B8`. That word
also overlaps a potential instruction entry, so the source model is left
unchanged until control flow and data/code boundaries are resolved. No secret
input or Easter egg is claimed. See `docs/PASS50_DEVELOPMENT_2026-10-25.md` and
`docs/input_mask_callers_pass50.json`.

## Pass 51 — input-mask local layout correction (2026-10-25)

Pass 51 verified the helper at `0x080517A4` and adjacent base-plus-offset
setter at `0x080517BC` against the original ROM. The helper evaluates
`*(u32 *)(*(u32 *)0x03000F48 + 0x6B4) & mask`; the adjacent routine stores a
value to that same computed field. The word at `0x080517B8` is a literal, not
an instruction-overlap indication; the adjacent function has its own literals
at `0x080517C8` and `0x080517CC`. `src/input.c` now represents the observed
indirection. This does not yet prove the initialized pointer's value, establish
equivalence with `0x03005E98` at all call sites, or identify a secret input.
See `docs/PASS51_DEVELOPMENT_2026-10-25.md`.


## Pass 54 — `sub_08051090` local control-flow audit (2026-10-25)

Added `tools/audit_sub_08051090.py` and a ROM-backed JSON report. The branch at
`0x0805109E` is BNE to `0x080510A8`; the first call is at `0x08051096` and the
zero-return fall-through calls `0x08057C5C` at `0x080510A4`. The store at
`0x080510AC` writes a value loaded from `[r4]` through the slot address
`0x03000F48`. The zero-return path remains anomalous because it subsequently
loads through `r4`; no explanation is asserted. Tests cover the bounded decoder.
See `docs/PASS54_DEVELOPMENT_2026-10-25.md`. No secret input or Easter egg is
claimed.

## Pass 56 — follow-on runtime-context initializer (2026-10-25)

Audited `0x08051120` against the original ROM. Important cross-pass detail: this routine clears runtime-base `+0x6B4` at `0x0805114A`, overwriting the earlier seed of `1` from `0x080510C2`; the observed final write here is zero. It also clears `+0x0`, `+0x6E8`, and `+0x6C0`, sets byte `+0x6AB` to `1`, and writes `0xFFFF` to halfword `+0x6EA`.

The routine initializes 56 table-backed records with stride `0xD0` from `0x08075B70`, dispatching two indirect callbacks per record, then initializes 10 entries with stride `0x50` from `0x08075850`. Field and callback meanings remain provisional/unknown. See `docs/PASS56_DEVELOPMENT_2026-10-25.md`, `docs/runtime_context_followup_pass56.json`, and `asm/runtime/runtime_context_followup_51120_pass56.thumb.s`. No Easter egg is claimed.

Pass 58: runtime state setter at `0x080517BC` is verified; its call paths supply values 1 and 1/4 to offset `+0x6B4`. See `docs/PASS58_DEVELOPMENT_2026-10-25.md`.

Pass 57: helper `0x08051744` indexes 56 objects at runtime +4 (stride 0x18); `0x08051704` indexes 10 entries at +0x544 (stride 8). Indirect trampoline `0x08065C44` branches to a callback dynamically stored in RAM `0x03006FAC`; see `docs/PASS57_DEVELOPMENT_2026-10-25.md`.
