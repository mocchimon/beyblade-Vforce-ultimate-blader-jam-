#!/usr/bin/env python3
"""Check the BG control and display-enable routines against the original ROM."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass29/runtime_display_controls.thumb.txt")
RANGES = (
    (0x08059C3C, 0x08059CD8),  # four BG control low-bit writes
    (0x08059CD8, 0x08059CEC),  # record-selected BG control read
    (0x08059CEC, 0x08059D14),  # one BG control low-bit write
    (0x08059D14, 0x08059D28),  # one BG control low-bit read
    (0x08059D28, 0x08059DDC),  # BG enable update and literal masks
    (0x0805EAAE, 0x0805EAB2),  # incoming caller of 0x08059C3C
    (0x08057F5A, 0x08057F5E),  # incoming caller of 0x08059CD8
    (0x0804A7CC, 0x0804A7D0),  # incoming caller of 0x08059CEC
    (0x0804A7D4, 0x0804A7D8),  # incoming caller of 0x08059D28
    (0x0804A7F4, 0x0804A7F8),  # incoming caller of 0x08059D28
)
CALL_TARGETS = {
    0x0805EAAE: 0x08059C3C,
    0x08057F5A: 0x08059CD8,
    0x0804A7CC: 0x08059CEC,
    0x0804A7D4: 0x08059D28,
    0x0804A7F4: 0x08059D28,
    0x08059C68: 0x08059A4C,
    0x08059C84: 0x08059A4C,
    0x08059C98: 0x08059A4C,
    0x08059CB2: 0x08059A4C,
    0x08059CDE: 0x08059A4C,
    0x08059CF8: 0x08059A4C,
    0x08059D1A: 0x08059A4C,
}
LITERALS = {
    0x08059DA4: 0x0000FEFF,
    0x08059DB4: 0x0000FDFF,
    0x08059DC4: 0x0000FBFF,
    0x08059DD8: 0x0000F7FF,
}


def _listing_halfwords():
    words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{4}\s*)+)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        for token in re.findall(r"[0-9a-fA-F]{4}", match.group(2)):
            if address in words:
                raise ValueError(f"duplicate listing address {address:#010x}")
            words[address] = int(token, 16)
            address += 2
    return words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if (upper & 0xF800) != 0xF000 or (lower & 0xF800) != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def verify(rom):
    words = _listing_halfwords()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in words:
                raise ValueError(f"listing is missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != words[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")

    return {
        "halfwords": checked,
        "calls": len(CALL_TARGETS),
        "literals": len(LITERALS),
        "ranges": len(RANGES),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {} Thumb halfwords across {} ranges, {} direct calls, and {} mask literals".format(
        result["halfwords"], result["ranges"], result["calls"],
        result["literals"]))


if __name__ == "__main__":
    main()
