#!/usr/bin/env python3
"""Verify the shared runtime-copy callback slot and its two ROM call sites."""
import argparse
import struct
from pathlib import Path

ROM_BASE = 0x08000000
SLOT = 0x0807D998
TARGET = 0x03007034
TRAMPOLINE = 0x08065C44

# Instructions prove that both callers load the same callback word, prepare
# (source, destination, byte_count) in r0-r2, and dispatch through BX r3.
EXPECTED_HALFWORDS = {
    # RuntimeBuffer_CopyRow: bounds check and callback argument setup.
    0x08063210: 0xB530, 0x08063212: 0x1C04, 0x08063214: 0x1C0D,
    0x08063216: 0x1C11, 0x08063218: 0x2208, 0x0806321A: 0x5EA0,
    0x0806321C: 0x4281, 0x0806321E: 0xDA0C, 0x08063220: 0x4B07,
    0x08063222: 0x88E2, 0x08063224: 0x4351, 0x08063226: 0x0049,
    0x08063228: 0x68E0, 0x0806322A: 0x1840, 0x0806322C: 0x88A4,
    0x0806322E: 0x0061, 0x08063230: 0x1869, 0x08063232: 0x0052,
    0x08063234: 0x681B, 0x08063236: 0xF002, 0x08063238: 0xFD05,
    0x0806323A: 0xBC30, 0x0806323C: 0xBC01, 0x0806323E: 0x4700,
    # CollisionData_InitializeOwnedSegments, first selected segment.
    0x0805B9DA: 0x491F, 0x0805B9DC: 0x6868, 0x0805B9DE: 0x680B,
    0x0805B9E0: 0x1C21, 0x0805B9E2: 0x4642,
    0x0805B9E4: 0xF00A, 0x0805B9E6: 0xF92E,
    # Same callback, second selected segment.
    0x0805B9F4: 0x4918, 0x0805B9F6: 0x68E8, 0x0805B9F8: 0x680B,
    0x0805B9FA: 0x1C21, 0x0805B9FC: 0x464A,
    0x0805B9FE: 0xF00A, 0x0805BA00: 0xF921,
}
LITERALS = {
    0x08063240: 0x0807D998,
    0x0807D998: TARGET,
}


def _word(rom, address):
    offset = address - ROM_BASE
    if offset < 0 or offset + 4 > len(rom):
        raise ValueError(f"ROM too short for word at {address:#010x}")
    return struct.unpack_from("<I", rom, offset)[0]


def verify(rom):
    for address, expected in EXPECTED_HALFWORDS.items():
        offset = address - ROM_BASE
        if offset < 0 or offset + 2 > len(rom):
            raise ValueError(f"ROM too short for instruction at {address:#010x}")
        actual = struct.unpack_from("<H", rom, offset)[0]
        if actual != expected:
            raise ValueError(f"instruction differs at {address:#010x}: {actual:#06x} != {expected:#06x}")

    for address, expected in LITERALS.items():
        actual = _word(rom, address)
        if actual != expected:
            raise ValueError(f"word differs at {address:#010x}: {actual:#010x} != {expected:#010x}")

    # Confirm all three direct call instructions land on the shared BX r3 thunk.
    for address in (0x08063236, 0x0805B9E4, 0x0805B9FE):
        upper = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
        lower = struct.unpack_from("<H", rom, address + 2 - ROM_BASE)[0]
        if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
            raise ValueError(f"expected Thumb BL at {address:#010x}")
        displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
        if upper & 0x0400:
            displacement -= 0x00800000
        target = address + 4 + displacement
        if target != TRAMPOLINE:
            raise ValueError(f"BL at {address:#010x} targets {target:#010x}, not {TRAMPOLINE:#010x}")

    # The trampoline's first halfword is BX r3. Its following alignment NOP
    # is independently visible in the ROM listing.
    if struct.unpack_from("<H", rom, TRAMPOLINE - ROM_BASE)[0] != 0x4718:
        raise ValueError("shared trampoline no longer begins with BX r3")

    return {
        "instructions": len(EXPECTED_HALFWORDS),
        "call_sites": 3,
        "callback_slot": SLOT,
        "callback_target": TARGET,
        "trampoline": TRAMPOLINE,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print(f"PASS: {result['instructions']} instruction halfwords; "
          f"{result['call_sites']} call sites share callback slot "
          f"{result['callback_slot']:#010x} -> {result['callback_target']:#010x} "
          f"via {result['trampoline']:#010x}")


if __name__ == "__main__":
    main()
