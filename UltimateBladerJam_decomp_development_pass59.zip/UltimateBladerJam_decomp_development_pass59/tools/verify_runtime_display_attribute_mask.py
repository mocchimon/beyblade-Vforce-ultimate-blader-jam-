#!/usr/bin/env python3
"""Verify the Thumb fingerprint for the attribute-mask routine at 0x08059620."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass47/runtime_display_attribute_mask.thumb.txt")
RANGES = ((0x08059620, 0x080596CA),)
LITERALS = {0x080596CC: 0x00000FFF}
BRANCH_TARGETS = {
    0x0805966A: 0x080596BA,
    0x08059678: 0x080596BA,
    0x0805968E: 0x080596AE,
    0x080596AC: 0x08059696,
    0x080596B8: 0x08059684,
}


def listing_halfwords():
    words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*([0-9a-fA-F]{4})\s*$", line)
        if not match:
            continue
        address, value = int(match.group(1), 16), int(match.group(2), 16)
        if address in words:
            raise ValueError(f"duplicate listing address {address:#010x}")
        words[address] = value
    return words


def decode_cond_branch(rom, address):
    insn = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if (insn & 0xF000) != 0xD000 or ((insn >> 8) & 0xF) >= 0xE:
        raise ValueError(f"invalid conditional branch at {address:#010x}")
    displacement = insn & 0xFF
    if displacement & 0x80:
        displacement -= 0x100
    return address + 4 + displacement * 2


def verify(rom):
    words = listing_halfwords()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in words:
                raise ValueError(f"listing missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != words[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1
    literal_values = {}
    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(f"literal mismatch at {address:#010x}: {actual:#010x}")
        literal_values[f"0x{address:08X}"] = f"0x{actual:08X}"
    for address, expected in BRANCH_TARGETS.items():
        actual = decode_cond_branch(rom, address)
        if actual != expected:
            raise ValueError(f"branch target mismatch at {address:#010x}: {actual:#010x}")
    return {"halfwords": checked, "literal_words": len(LITERALS),
            "conditional_branches": len(BRANCH_TARGETS),
            "entry": "0x08059620", "end_exclusive": "0x080596CA"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path)
    args = parser.parse_args()
    result = verify(args.rom.read_bytes())
    print("PASS: attribute-mask routine at {}: {} halfwords, {} literal words, {} branches".format(
        result["entry"], result["halfwords"], result["literal_words"],
        result["conditional_branches"]))


if __name__ == "__main__":
    main()
