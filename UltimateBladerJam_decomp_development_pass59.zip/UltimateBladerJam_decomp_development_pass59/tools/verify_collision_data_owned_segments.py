#!/usr/bin/env python3
"""Verify Pass 39 collision owned-segment initializer against the supplied ROM."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
ENTRY = 0x0805B95C
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass39/collision_data_owned_segments.thumb.txt")
RANGES = (
    (0x0805B95C, 0x0805B9CA),
    (0x0805B9D0, 0x0805BA58),
)
PADDING_HALFWORDS = {0x0805B9CA: 0x0000}
LITERALS = {
    0x0805B9CC: 0x08755430,
    0x0805BA58: 0x0807D998,
    0x0805BA5C: 0x087553F4,
}
CALL_TARGETS = {
    0x0805B9B0: 0x0805A444,  # alternate heap allocator
    0x0805B9C4: 0x08057C5C,  # allocation diagnostic
    0x0805B9E4: 0x08065C44,  # installed operation trampoline
    0x0805B9FE: 0x08065C44,  # installed operation trampoline
    0x0805BA14: 0x08057B60,  # spline-count diagnostic
    0x0805BA2A: 0x0805DBA4,  # packed spline lookup
}
CONDITIONAL_BRANCHES = {
    0x0805B99C: 0x0805B9A0,
    0x0805B9A6: 0x0805B9AA,
    0x0805B9AC: 0x0805B9B8,
    0x0805B9BE: 0x0805B9D0,
    0x0805B9D8: 0x0805B9EC,
    0x0805B9F2: 0x0805BA04,
    0x0805BA0E: 0x0805BA18,
    0x0805BA20: 0x0805BA42,
    0x0805BA40: 0x0805BA22,
}
UNCONDITIONAL_BRANCHES = {
    0x0805B9B6: 0x0805B9BA,
    0x0805B9C8: 0x0805BA04,
}
LITERAL_LOADS = {
    0x0805B9DA: 0x0805BA58,
    0x0805B9F4: 0x0805BA58,
    0x0805BA12: 0x0805BA5C,
    0x0805B9C0: 0x0805B9CC,
}


def _listing():
    halfwords = {}
    data_words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*(.*)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        tokens = match.group(2).split(";", 1)[0].strip().split()
        if address in LITERALS:
            if len(tokens) != 4 or any(len(token) != 2 for token in tokens):
                raise ValueError(f"invalid literal bytes at {address:#010x}")
            data_words[address] = bytes(int(token, 16) for token in tokens)
        else:
            if len(tokens) != 1 or len(tokens[0]) != 4:
                raise ValueError(f"invalid Thumb halfword at {address:#010x}")
            if address in halfwords:
                raise ValueError(f"duplicate listing address {address:#010x}")
            halfwords[address] = int(tokens[0], 16)
    return halfwords, data_words


def _decode_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def _branch_target(rom, address, conditional):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if conditional:
        if instruction & 0xF000 != 0xD000 or ((instruction >> 8) & 0xF) >= 0xE:
            raise ValueError(f"invalid conditional branch at {address:#010x}")
        displacement = instruction & 0xFF
        if displacement & 0x80:
            displacement -= 0x100
    else:
        if instruction & 0xF800 != 0xE000:
            raise ValueError(f"invalid unconditional branch at {address:#010x}")
        displacement = instruction & 0x7FF
        if displacement & 0x400:
            displacement -= 0x800
    return address + 4 + displacement * 2


def _literal_target(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF800 != 0x4800:
        raise ValueError(f"invalid LDR literal at {address:#010x}")
    base = (address + 4) & ~3
    return base + ((instruction & 0xFF) << 2)


def verify(rom):
    halfwords, listed_data = _listing()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in halfwords:
                raise ValueError(f"listing missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != halfwords[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        if _decode_bl(rom, address) != expected:
            raise ValueError(f"BL target differs at {address:#010x}")
    for address, expected in CONDITIONAL_BRANCHES.items():
        if _branch_target(rom, address, True) != expected:
            raise ValueError(f"conditional branch target differs at {address:#010x}")
    for address, expected in UNCONDITIONAL_BRANCHES.items():
        if _branch_target(rom, address, False) != expected:
            raise ValueError(f"unconditional branch target differs at {address:#010x}")
    for address, expected in LITERAL_LOADS.items():
        if _literal_target(rom, address) != expected:
            raise ValueError(f"literal load target differs at {address:#010x}")
    for address, expected in PADDING_HALFWORDS.items():
        actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(f"padding halfword at {address:#010x} differs")
    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(f"literal at {address:#010x} differs")
        if listed_data.get(address) != struct.pack("<I", expected):
            raise ValueError(f"listing literal differs at {address:#010x}")

    return {"halfwords": checked, "padding_halfwords": len(PADDING_HALFWORDS), "calls": len(CALL_TARGETS),
            "conditional_branches": len(CONDITIONAL_BRANCHES),
            "unconditional_branches": len(UNCONDITIONAL_BRANCHES),
            "literal_loads": len(LITERAL_LOADS), "literals": len(LITERALS)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {halfwords} Thumb halfwords + {padding_halfwords} padding halfword, {calls} calls, "
          "{conditional_branches} conditional and {unconditional_branches} "
          "unconditional branches, {literal_loads} literal loads and "
          "{literals} literal words".format(**result))


if __name__ == "__main__":
    main()
