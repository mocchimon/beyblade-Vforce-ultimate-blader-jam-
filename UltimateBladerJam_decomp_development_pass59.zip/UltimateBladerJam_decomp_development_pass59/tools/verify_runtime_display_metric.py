#!/usr/bin/env python3
"""Verify the byte-sequence metric routine and its observed call setup."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass35/runtime_display_metric.thumb.txt")
RANGES = (
    (0x0805B400, 0x0805B43A),  # helper body and return
    (0x0805B4B8, 0x0805B4C4),  # r0-r2 setup and call from display routine
    (0x0805B4C4, 0x0805B4E4),  # metric-based origin adjustment
)
CALL_TARGETS = {0x0805B4C0: 0x0805B400}
BRANCH_TARGETS = {
    0x0805B40E: 0x0805B432,
    0x0805B416: 0x0805B428,
    0x0805B420: 0x0805B428,
    0x0805B430: 0x0805B412,
    0x0805B4CC: 0x0805B4D4,
    0x0805B4D0: 0x0805B4DC,
}
LITERALS = {0x0805B43C: 0x0807D9A4}


def _listing_halfwords():
    words = {}
    data_words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*(.*)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        payload = match.group(2).split(";", 1)[0].strip()
        tokens = re.findall(r"[0-9a-fA-F]{2,4}", payload)
        if address == 0x0805B43C:
            if len(tokens) != 4:
                raise ValueError("expected four literal bytes at 0x0805b43c")
            data_words[address] = bytes(int(token, 16) for token in tokens)
            continue
        if not tokens:
            continue
        for token in tokens:
            if len(token) != 4:
                raise ValueError(f"invalid halfword token {token!r}")
            if address in words:
                raise ValueError(f"duplicate listing address {address:#010x}")
            words[address] = int(token, 16)
            address += 2
    return words, data_words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if (upper & 0xF800) != 0xF000 or (lower & 0xF800) != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def _decode_thumb_cond_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF000 != 0xD000 or (instruction >> 8) & 0xF >= 0xE:
        raise ValueError(f"invalid conditional branch at {address:#010x}")
    displacement = instruction & 0xFF
    if displacement & 0x80:
        displacement -= 0x100
    return address + 4 + (displacement << 1)


def verify(rom):
    words, data_words = _listing_halfwords()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in words:
                raise ValueError(f"listing is missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != words[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in BRANCH_TARGETS.items():
        actual = _decode_thumb_cond_branch(rom, address)
        if actual != expected:
            raise ValueError(
                f"branch at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")
        if data_words.get(address) != struct.pack("<I", expected):
            raise ValueError(f"listing literal bytes differ at {address:#010x}")

    return {"halfwords": checked, "calls": len(CALL_TARGETS),
            "branches": len(BRANCH_TARGETS), "literals": len(LITERALS),
            "ranges": len(RANGES)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {} Thumb halfwords, {} direct call, {} branch targets, "
          "and {} table-pointer literal across {} ranges".format(
              result["halfwords"], result["calls"], result["branches"],
              result["literals"], result["ranges"]))


if __name__ == "__main__":
    main()
