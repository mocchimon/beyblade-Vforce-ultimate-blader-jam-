#!/usr/bin/env python3
"""Verify the encoded display byte-stream routine against the original ROM."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
ENTRY = 0x0805B824
THUMB_ENTRY_POINTER = ENTRY | 1
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass37/runtime_display_byte_stream.thumb.txt")
RANGES = ((ENTRY, 0x0805B8E6),)
CALL_TARGETS = {
    0x0805B884: 0x0805B440,
    0x0805B896: 0x0805B440,
    0x0805B8B4: 0x0805B440,
}
CONDITIONAL_BRANCHES = {
    0x0805B84C: 0x0805B8D6,
    0x0805B852: 0x0805B8D6,
    0x0805B860: 0x0805B8C4,
    0x0805B864: 0x0805B870,
    0x0805B868: 0x0805B878,
    0x0805B86C: 0x0805B88A,
    0x0805B872: 0x0805B8A8,
    0x0805B876: 0x0805B8CC,
    0x0805B8D4: 0x0805B85A,
}
UNCONDITIONAL_BRANCHES = {
    0x0805B86E: 0x0805B8CC,
    0x0805B888: 0x0805B8D6,
    0x0805B8A6: 0x0805B8D0,
    0x0805B8C2: 0x0805B8D0,
    0x0805B8CA: 0x0805B8D0,
}


def _listing():
    halfwords = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*(.*)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        payload = match.group(2).split(";", 1)[0].strip()
        tokens = payload.split()
        if len(tokens) != 1 or len(tokens[0]) != 4:
            raise ValueError(f"invalid Thumb halfword at {address:#010x}")
        if address in halfwords:
            raise ValueError(f"duplicate listing address {address:#010x}")
        halfwords[address] = int(tokens[0], 16)
    return halfwords


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def _decode_conditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF000 != 0xD000 or ((instruction >> 8) & 0xF) >= 0xE:
        raise ValueError(f"invalid conditional branch at {address:#010x}")
    displacement = instruction & 0xFF
    if displacement & 0x80:
        displacement -= 0x100
    return address + 4 + (displacement << 1)


def _decode_unconditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF800 != 0xE000:
        raise ValueError(f"invalid unconditional branch at {address:#010x}")
    displacement = instruction & 0x7FF
    if displacement & 0x400:
        displacement -= 0x800
    return address + 4 + (displacement << 1)


def _direct_bl_targets(rom, target):
    """Return aligned Thumb BL instruction pairs which decode to target."""
    matches = []
    for offset in range(0, len(rom) - 3, 2):
        upper, lower = struct.unpack_from("<HH", rom, offset)
        if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
            continue
        displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
        if upper & 0x0400:
            displacement -= 0x00800000
        if ROM_BASE + offset + 4 + displacement == target:
            matches.append(ROM_BASE + offset)
    return matches


def _direct_branch_targets(rom, target):
    """Return conditional/unconditional Thumb branches which target entry."""
    matches = []
    for offset in range(0, len(rom) - 1, 2):
        instruction = struct.unpack_from("<H", rom, offset)[0]
        address = ROM_BASE + offset
        if (instruction & 0xF000 == 0xD000 and
                ((instruction >> 8) & 0xF) < 0xE):
            displacement = instruction & 0xFF
            if displacement & 0x80:
                displacement -= 0x100
            if address + 4 + (displacement << 1) == target:
                matches.append(address)
        elif instruction & 0xF800 == 0xE000:
            displacement = instruction & 0x7FF
            if displacement & 0x400:
                displacement -= 0x800
            if address + 4 + (displacement << 1) == target:
                matches.append(address)
    return matches


def verify(rom):
    halfwords = _listing()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in halfwords:
                raise ValueError(f"listing missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != halfwords[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in CONDITIONAL_BRANCHES.items():
        if _decode_conditional_branch(rom, address) != expected:
            raise ValueError(
                f"conditional branch target differs at {address:#010x}")

    for address, expected in UNCONDITIONAL_BRANCHES.items():
        if _decode_unconditional_branch(rom, address) != expected:
            raise ValueError(
                f"unconditional branch target differs at {address:#010x}")

    direct_entry_calls = _direct_bl_targets(rom, ENTRY)
    if direct_entry_calls:
        raise ValueError(
            "unexpected direct Thumb BL call(s) to parser: " +
            ", ".join(f"{address:#010x}" for address in direct_entry_calls))

    direct_entry_branches = _direct_branch_targets(rom, ENTRY)
    if direct_entry_branches:
        raise ValueError(
            "unexpected direct Thumb branch(es) to parser: " +
            ", ".join(f"{address:#010x}" for address in direct_entry_branches))

    entry_pointer_count = rom.count(struct.pack("<I", THUMB_ENTRY_POINTER))
    if entry_pointer_count:
        raise ValueError(
            f"unexpected stored Thumb entry pointer count: {entry_pointer_count}")

    return {"halfwords": checked, "calls": len(CALL_TARGETS),
            "conditional_branches": len(CONDITIONAL_BRANCHES),
            "unconditional_branches": len(UNCONDITIONAL_BRANCHES),
            "direct_entry_calls": len(direct_entry_calls),
            "direct_entry_branches": len(direct_entry_branches),
            "stored_entry_pointers": entry_pointer_count,
            "ranges": len(RANGES)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {halfwords} Thumb halfwords, {calls} direct renderer calls, "
          "{conditional_branches} conditional and "
          "{unconditional_branches} unconditional branch targets across "
          "{ranges} range; parser entry has {direct_entry_calls} direct BL "
          "call(s), {direct_entry_branches} direct branch(es), and "
          "{stored_entry_pointers} stored Thumb pointer(s)".format(
              **result))


if __name__ == "__main__":
    main()
