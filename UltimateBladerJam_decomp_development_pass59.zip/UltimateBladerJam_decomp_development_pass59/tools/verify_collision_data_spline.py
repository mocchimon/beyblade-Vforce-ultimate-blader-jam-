#!/usr/bin/env python3
"""Verify collision spline cache initialization and packed lookup in the ROM."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
BUILD_SPLINE_INDEX = 0x0805B8E8
GET_SPLINE_BY_INDEX = 0x0805DBA4
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass38/collision_data_spline.thumb.txt")
RANGES = (
    (BUILD_SPLINE_INDEX, 0x0805B956),
    (GET_SPLINE_BY_INDEX, 0x0805DBD0),
    (0x0804A3D6, 0x0804A3DE),
    (0x08053660, 0x08053666),
    (0x08054164, 0x0805416C),
    (0x080547CE, 0x080547D8),
    (0x08056C4E, 0x08056C54),
    (0x08056CC6, 0x08056CCC),
    (0x08056DB4, 0x08056DBC),
    (0x08057654, 0x0805765C),
    (0x0805EAD4, 0x0805EAE0),
    (0x0805BA26, 0x0805BA2E),
    (0x0805D6BA, 0x0805D6C2),
    (0x0805DBE6, 0x0805DBEE),
    (0x0805DCD8, 0x0805DCE0),
    (0x0805DCF8, 0x0805DD00),
    (0x0805DD4A, 0x0805DD52),
    (0x0805E002, 0x0805E00A),
    (0x0805E098, 0x0805E0A0),
)
CONSTRUCTOR_CALLERS = {
    0x0804A3DA,
    0x08053662,
    0x08054168,
    0x080547D4,
    0x08056C50,
    0x08056CC8,
    0x08056DB8,
    0x08057658,
    0x0805EADA,
}
CALL_TARGETS = {
    0x0805B90E: 0x08057B60,
    0x0805B924: GET_SPLINE_BY_INDEX,
    **{site: BUILD_SPLINE_INDEX for site in CONSTRUCTOR_CALLERS},
}
HELPER_CALLERS = {
    0x0805B924,
    0x0805BA2A,
    0x0805D6BE,
    0x0805DBEA,
    0x0805DCDC,
    0x0805DCFC,
    0x0805DD4E,
    0x0805E006,
    0x0805E09C,
}
CALL_TARGETS.update({site: GET_SPLINE_BY_INDEX for site in HELPER_CALLERS})
CONDITIONAL_BRANCHES = {
    0x0805B908: 0x0805B912,
    0x0805B91A: 0x0805B93C,
    0x0805B93A: 0x0805B91C,
    0x0805DBB2: 0x0805DBC8,
    0x0805DBB8: 0x0805DBBE,
    0x0805DBC6: 0x0805DBB6,
}
UNCONDITIONAL_BRANCHES = {
    0x0805DBBC: 0x0805DBCA,
}
LITERALS = {
    0x0805B958: 0x087553F4,
}


def _listing():
    halfwords = {}
    data_words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*(.*)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        tokens = match.group(2).split(";", 1)[0].strip().split()
        if address in LITERALS:
            if len(tokens) != 4 or any(len(token) != 2 for token in tokens):
                raise ValueError(f"invalid literal bytes at {address:#010x}")
            data_words[address] = bytes(int(token, 16) for token in tokens)
            continue
        if len(tokens) != 1 or len(tokens[0]) != 4:
            raise ValueError(f"invalid Thumb halfword at {address:#010x}")
        if address in halfwords:
            raise ValueError(f"duplicate listing address {address:#010x}")
        halfwords[address] = int(tokens[0], 16)
    return halfwords, data_words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def _decode_conditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF000 != 0xD000 or ((instruction >> 8) & 0xF) >= 0xE:
        raise ValueError(f"invalid conditional branch at {address:#010x}")
    displacement = instruction & 0xFF
    if displacement & 0x80:
        displacement -= 0x100
    return address + 4 + (displacement << 1)


def _decode_unconditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF800 != 0xE000:
        raise ValueError(f"invalid unconditional branch at {address:#010x}")
    displacement = instruction & 0x7FF
    if displacement & 0x400:
        displacement -= 0x800
    return address + 4 + (displacement << 1)


def _direct_bl_callers(rom, target):
    callers = set()
    for offset in range(0, len(rom) - 3, 2):
        upper, lower = struct.unpack_from("<HH", rom, offset)
        if upper & 0xF800 != 0xF000 or lower & 0xF800 != 0xF800:
            continue
        displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
        if upper & 0x0400:
            displacement -= 0x00800000
        if ROM_BASE + offset + 4 + displacement == target:
            callers.add(ROM_BASE + offset)
    return callers


def verify(rom):
    halfwords, listed_data = _listing()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in halfwords:
                raise ValueError(f"listing missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != halfwords[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in CONDITIONAL_BRANCHES.items():
        if _decode_conditional_branch(rom, address) != expected:
            raise ValueError(
                f"conditional branch target differs at {address:#010x}")

    for address, expected in UNCONDITIONAL_BRANCHES.items():
        if _decode_unconditional_branch(rom, address) != expected:
            raise ValueError(
                f"unconditional branch target differs at {address:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")
        if listed_data.get(address) != struct.pack("<I", expected):
            raise ValueError(f"listing literal differs at {address:#010x}")

    actual_constructor_callers = _direct_bl_callers(rom, BUILD_SPLINE_INDEX)
    if actual_constructor_callers != CONSTRUCTOR_CALLERS:
        missing = CONSTRUCTOR_CALLERS - actual_constructor_callers
        extra = actual_constructor_callers - CONSTRUCTOR_CALLERS
        raise ValueError(
            f"constructor caller set differs; missing={sorted(missing)}, "
            f"extra={sorted(extra)}")

    actual_helper_callers = _direct_bl_callers(rom, GET_SPLINE_BY_INDEX)
    if actual_helper_callers != HELPER_CALLERS:
        raise ValueError(
            f"spline lookup caller set differs: {sorted(actual_helper_callers)}")

    return {"halfwords": checked, "calls": len(CALL_TARGETS),
            "conditional_branches": len(CONDITIONAL_BRANCHES),
            "unconditional_branches": len(UNCONDITIONAL_BRANCHES),
            "literals": len(LITERALS),
            "constructor_callers": len(actual_constructor_callers),
            "helper_callers": len(actual_helper_callers),
            "ranges": len(RANGES)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {halfwords} Thumb halfwords, {calls} direct calls, "
          "{conditional_branches} conditional and "
          "{unconditional_branches} unconditional branch targets, "
          "{literals} literal words across {ranges} ranges; found "
          "{constructor_callers} constructor callers and "
          "{helper_callers} lookup caller(s)".format(**result))


if __name__ == "__main__":
    main()
