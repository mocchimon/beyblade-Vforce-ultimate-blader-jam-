#!/usr/bin/env python3
"""Verify the ARM runtime image and its adjacent 32-word offset table.

This is ROM-backed structural validation, not a claim that the module is the
source of the separate upper-IWRAM dispatch targets. The loader consumes 29 of
the 32 table slots and rebases those offsets into an allocated module block.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path

ROM_BASE = 0x08000000
IMAGE_START = 0x080641B8
IMAGE_END = 0x08064EDC       # exclusive
IMAGE_SIZE = IMAGE_END - IMAGE_START
TABLE_START = IMAGE_END
TABLE_WORDS = 32
TABLE_END = TABLE_START + TABLE_WORDS * 4
# Loader table slots that are actually rebased into the context record.
USED_SLOTS = tuple(i for i in range(TABLE_WORDS) if i not in (0x3C // 4, 0x4C // 4, 0x50 // 4))
KNOWN_ENTRIES = {
    0x000: "ArmRaster_EmitSamples",
    0x060: "ArmRaster_EmitPackedSamples",
    0x1AC: "ArmRaster_ProcessPrimitiveEdges",
    0x434: "ArmRaster_ProcessAlternateEdgeCase",
    0x56C: "ArmRaster_ClampSpan",
    0x698: "ArmRaster_DrawRows",
    0x85C: "ArmRaster_ApplyVertexParameters",
    0x944: "ArmRaster_TransformVertexRows",
    0xA80: "ArmRaster_InsertBucketItem",
    0xAD4: "ArmRaster_BuildEdgeBuckets",
    0xC28: "ArmRaster_ProcessEdgeBuckets",
    0xC9C: "ArmRaster_CopyEightRowSlices",
}


def audit(rom):
    if len(rom) < TABLE_END - ROM_BASE:
        raise ValueError("ROM too short for ARM runtime module and offset table")
    image_off = IMAGE_START - ROM_BASE
    image = rom[image_off: image_off + IMAGE_SIZE]
    if len(image) != IMAGE_SIZE:
        raise ValueError("truncated ARM runtime image")
    table_off = TABLE_START - ROM_BASE
    values = [struct.unpack_from('<I', rom, table_off + 4 * i)[0] for i in range(TABLE_WORDS)]
    rows = []
    errors = []
    for slot, value in enumerate(values):
        # Zero means an intentionally absent relocation. IMAGE_SIZE is a valid
        # one-past-end pointer in the slot consumed into context offset +0x70.
        valid = value == 0 or value <= IMAGE_SIZE
        if not valid:
            errors.append(f"slot {slot} offset 0x{value:X} exceeds image size 0x{IMAGE_SIZE:X}")
        rows.append({
            "slot_index": slot,
            "table_address": f"0x{TABLE_START + slot * 4:08X}",
            "value": f"0x{value:08X}",
            "used_by_loader": slot in USED_SLOTS,
            "valid_offset_or_null": valid,
            "one_past_end": value == IMAGE_SIZE,
            "target_rom_address": f"0x{IMAGE_START + value:08X}" if value else None,
            "known_entry": KNOWN_ENTRIES.get(value),
        })
    used_invalid = [r for r in rows if r['used_by_loader'] and not r['valid_offset_or_null']]
    if used_invalid:
        errors.append("one or more loader-consumed slots are out of range")
    # The ROM's ARM image starts with the instruction sequence previously
    # confirmed by disassembly. This catches accidental offsets/hash mistakes.
    first_words = [struct.unpack_from('<I', image, i)[0] for i in (0, 4, 8, 12, 16)]
    expected_first_words = [0xE2014CFF, 0xE0433002, 0xE1A03403, 0xE1A02402, 0xE0822204]
    if first_words != expected_first_words:
        errors.append("ARM image entry instruction fingerprint mismatch")
    return {
        "rom_size": len(rom),
        "rom_sha256": hashlib.sha256(rom).hexdigest(),
        "image_start": f"0x{IMAGE_START:08X}",
        "image_end_exclusive": f"0x{IMAGE_END:08X}",
        "image_size": IMAGE_SIZE,
        "image_sha256": hashlib.sha256(image).hexdigest(),
        "table_start": f"0x{TABLE_START:08X}",
        "table_end_exclusive": f"0x{TABLE_END:08X}",
        "table_word_count": TABLE_WORDS,
        "loader_consumed_slot_count": len(USED_SLOTS),
        "first_arm_words": [f"0x{x:08X}" for x in first_words],
        "known_entry_offsets": {f"0x{k:03X}": v for k, v in KNOWN_ENTRIES.items()},
        "table": rows,
        "errors": errors,
        "pass": not errors,
        "interpretation": [
            "The 0xD24-byte image is copied to a heap block by the loader at 0x0805EFC0.",
            "The adjacent 32-word table contains offsets/null entries; 29 slots are rebased into context fields.",
            "Offset 0xD24 is a valid one-past-end pointer, not an instruction entry.",
            "This module's heap destination does not prove it supplies upper-IWRAM callbacks such as 0x03007034.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', type=Path)
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    result = audit(args.rom.read_bytes())
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2) + '\n')
    print(f"ROM {result['rom_sha256']}")
    print(f"ARM module: {result['image_size']:#x} bytes; table words: {result['table_word_count']}; consumed slots: {result['loader_consumed_slot_count']}")
    print(f"Known entry offsets matched: {len(result['known_entry_offsets'])}; one-past-end entries: {sum(r['one_past_end'] for r in result['table'])}")
    for error in result['errors']:
        print(f"ERROR: {error}")
    print("PASS" if result['pass'] else "FAIL")
    if not result['pass']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
