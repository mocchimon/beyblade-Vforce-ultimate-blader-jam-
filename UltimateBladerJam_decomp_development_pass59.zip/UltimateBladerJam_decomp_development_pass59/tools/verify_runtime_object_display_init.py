#!/usr/bin/env python3
"""Check display-state setup and record flag access against the original ROM."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass28/runtime_object_display_init.thumb.txt")
RANGES = (
    (0x08059958, 0x080599B8),  # initializer and IWRAM pointer literals
    (0x080599B8, 0x080599CA),  # record +0x64 flag test
    (0x0804277E, 0x08042782),  # incoming direct caller
    (0x0805073E, 0x08050742),  # incoming direct caller
    (0x0805E996, 0x0805E99A),  # incoming direct caller
)
CALL_TARGETS = {
    0x0804277E: 0x08059958,
    0x0805073E: 0x08059958,
    0x0805E996: 0x08059958,
    0x08059970: 0x080599CC,
    0x08059978: 0x08059A0C,
    0x08059994: 0x08059B24,
    0x080599A0: 0x08059B24,
}
LITERALS = {
    0x080599AC: 0x03000DE0,
    0x080599B0: 0x03000E40,
    0x080599B4: 0x03000E3C,
}


def _listing_halfwords():
    words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{4}\s*)+)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        for token in re.findall(r"[0-9a-fA-F]{4}", match.group(2)):
            if address in words:
                raise ValueError(f"duplicate listing address {address:#010x}")
            words[address] = int(token, 16)
            address += 2
    return words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if (upper & 0xF800) != 0xF000 or (lower & 0xF800) != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def verify(rom):
    words = _listing_halfwords()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in words:
                raise ValueError(f"listing is missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != words[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")

    return {
        "halfwords": checked,
        "calls": len(CALL_TARGETS),
        "literals": len(LITERALS),
        "ranges": len(RANGES),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {} Thumb halfwords across {} ranges, {} direct calls, and {} IWRAM pointers".format(
        result["halfwords"], result["ranges"], result["calls"],
        result["literals"]))


if __name__ == "__main__":
    main()
