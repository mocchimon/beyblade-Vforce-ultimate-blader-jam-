#!/usr/bin/env python3
"""Verify the sequence renderer, its glyph lookup helper, and five callers."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass36/runtime_display_sequence.thumb.txt")
RANGES = (
    (0x0805B440, 0x0805B4B4),  # renderer setup through its first literal pool
    (0x0805B4B8, 0x0805B67E),  # renderer body, tile loops, and epilogue
    (0x0805B814, 0x0805B824),  # descriptor-driven indexed glyph lookup
    (0x0805B700, 0x0805B710),  # decimal sequence caller
    (0x0805B7F2, 0x0805B802),  # second decimal sequence caller
    (0x0805B878, 0x0805B888),  # escaped-byte sequence caller
    (0x0805B88A, 0x0805B89A),  # newline sequence caller
    (0x0805B8A8, 0x0805B8B8),  # control-byte sequence caller
)
CALL_TARGETS = {
    0x0805B492: 0x08059A4C,
    0x0805B4AC: 0x08057B60,
    0x0805B4C0: 0x0805B400,
    0x0805B5A6: 0x08065C44,
    0x0805B5DE: 0x0805B814,
    0x0805B638: 0x0805B2A4,
    0x0805B70C: 0x0805B440,
    0x0805B7FE: 0x0805B440,
    0x0805B884: 0x0805B440,
    0x0805B896: 0x0805B440,
    0x0805B8B4: 0x0805B440,
}
CONDITIONAL_BRANCHES = {
    0x0805B49E: 0x0805B4AA,
    0x0805B4A8: 0x0805B4B8,
    0x0805B4CC: 0x0805B4D4,
    0x0805B4D0: 0x0805B4DC,
    0x0805B502: 0x0805B506,
    0x0805B526: 0x0805B57C,
    0x0805B536: 0x0805B570,
    0x0805B542: 0x0805B550,
    0x0805B56E: 0x0805B53C,
    0x0805B57A: 0x0805B530,
    0x0805B586: 0x0805B5AA,
    0x0805B5C2: 0x0805B66C,
    0x0805B5CA: 0x0805B654,
    0x0805B5EE: 0x0805B5FA,
    0x0805B604: 0x0805B654,
    0x0805B61C: 0x0805B648,
    0x0805B646: 0x0805B62A,
    0x0805B652: 0x0805B606,
    0x0805B65E: 0x0805B66C,
    0x0805B66A: 0x0805B5C4,
}
UNCONDITIONAL_BRANCHES = {
    0x0805B4B0: 0x0805B66C,
    0x0805B4D2: 0x0805B4E4,
    0x0805B4DA: 0x0805B4E4,
}
LITERALS = {
    0x0805B4B4: 0x087553C0,
    0x0805B680: 0x00000FFF,
    0x0805B684: 0x0807D994,
    0x0805B688: 0x0807D9A4,
}


def _listing():
    halfwords = {}
    data_words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*(.*)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        payload = match.group(2).split(";", 1)[0].strip()
        tokens = payload.split()
        if address in LITERALS:
            if len(tokens) != 4 or any(len(token) != 2 for token in tokens):
                raise ValueError(f"invalid literal bytes at {address:#010x}")
            data_words[address] = bytes(int(token, 16) for token in tokens)
            continue
        for token in tokens:
            if len(token) != 4:
                raise ValueError(f"invalid Thumb halfword token {token!r}")
            if address in halfwords:
                raise ValueError(f"duplicate listing address {address:#010x}")
            halfwords[address] = int(token, 16)
            address += 2
    return halfwords, data_words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if (upper & 0xF800) != 0xF000 or (lower & 0xF800) != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def _decode_conditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF000 != 0xD000 or ((instruction >> 8) & 0xF) >= 0xE:
        raise ValueError(f"invalid conditional branch at {address:#010x}")
    displacement = instruction & 0xFF
    if displacement & 0x80:
        displacement -= 0x100
    return address + 4 + (displacement << 1)


def _decode_unconditional_branch(rom, address):
    instruction = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
    if instruction & 0xF800 != 0xE000:
        raise ValueError(f"invalid unconditional branch at {address:#010x}")
    displacement = instruction & 0x7FF
    if displacement & 0x400:
        displacement -= 0x800
    return address + 4 + (displacement << 1)


def verify(rom):
    halfwords, listed_data = _listing()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in halfwords:
                raise ValueError(f"listing missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != halfwords[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in CONDITIONAL_BRANCHES.items():
        if _decode_conditional_branch(rom, address) != expected:
            raise ValueError(f"conditional branch target differs at {address:#010x}")

    for address, expected in UNCONDITIONAL_BRANCHES.items():
        if _decode_unconditional_branch(rom, address) != expected:
            raise ValueError(f"branch target differs at {address:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")
        if listed_data.get(address) != struct.pack("<I", expected):
            raise ValueError(f"listing literal differs at {address:#010x}")

    return {"halfwords": checked, "calls": len(CALL_TARGETS),
            "conditional_branches": len(CONDITIONAL_BRANCHES),
            "unconditional_branches": len(UNCONDITIONAL_BRANCHES),
            "literals": len(LITERALS), "ranges": len(RANGES)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {halfwords} Thumb halfwords, {calls} direct calls, "
          "{conditional_branches} conditional and "
          "{unconditional_branches} unconditional branch targets, "
          "and {literals} literal words across {ranges} ranges".format(
              **result))


if __name__ == "__main__":
    main()
