#!/usr/bin/env python3
"""Verify the ROM bytes and dispatch edges for ChildRuntime_InitVariantC."""
import argparse
import re
import struct
from pathlib import Path

ROM_BASE = 0x08000000
LISTING = (Path(__file__).resolve().parents[1] /
           "asm/pass31/child_runtime_init_variant_c.thumb.txt")
RANGES = (
    (0x08058C98, 0x08058E3C),  # initializer body, embedded literals, and return
    (0x0804A748, 0x0804A772),  # only through the caller's BL to this initializer
    (0x08065C44, 0x08065C48),  # shared Thumb BX r3 interworking entry
)
CALL_TARGETS = {
    0x08058CC6: 0x080592A8,
    0x08058E08: 0x08065C44,
    0x08058E0E: 0x08059A4C,
    0x0804A76E: 0x08058C98,
}
LITERALS = {
    0x08058D68: 0x03000CA0,
    0x08058D9C: 0x03000DE0,
    0x08058DE0: 0x03000E3C,
    0x08058E38: 0x0807D994,
    0x0807D994: 0x03006FAC,
}
THUMB_BX_R3 = 0x4718


def _listing_halfwords():
    words = {}
    for line in LISTING.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{4}\s*)+)$", line)
        if not match:
            continue
        address = int(match.group(1), 16)
        for token in re.findall(r"[0-9a-fA-F]{4}", match.group(2)):
            if address in words:
                raise ValueError(f"duplicate listing address {address:#010x}")
            words[address] = int(token, 16)
            address += 2
    return words


def _decode_thumb_bl(rom, address):
    upper, lower = struct.unpack_from("<HH", rom, address - ROM_BASE)
    if (upper & 0xF800) != 0xF000 or (lower & 0xF800) != 0xF800:
        raise ValueError(f"invalid Thumb BL at {address:#010x}")
    displacement = ((upper & 0x7FF) << 12) | ((lower & 0x7FF) << 1)
    if upper & 0x0400:
        displacement -= 0x00800000
    return address + 4 + displacement


def verify(rom):
    words = _listing_halfwords()
    checked = 0
    for start, end in RANGES:
        for address in range(start, end, 2):
            if address not in words:
                raise ValueError(f"listing is missing halfword at {address:#010x}")
            actual = struct.unpack_from("<H", rom, address - ROM_BASE)[0]
            if actual != words[address]:
                raise ValueError(f"Thumb bytes differ at {address:#010x}")
            checked += 1

    for address, expected in CALL_TARGETS.items():
        actual = _decode_thumb_bl(rom, address)
        if actual != expected:
            raise ValueError(
                f"call at {address:#010x} targets {actual:#010x}, "
                f"expected {expected:#010x}")

    for address, expected in LITERALS.items():
        actual = struct.unpack_from("<I", rom, address - ROM_BASE)[0]
        if actual != expected:
            raise ValueError(
                f"literal at {address:#010x} is {actual:#010x}, "
                f"expected {expected:#010x}")

    if words[0x08065C44] != THUMB_BX_R3 or words[0x08065C46] != 0x46C0:
        raise ValueError("background-operation call is not the BX r3 thunk")
    callback_address = LITERALS[0x0807D994]
    if callback_address & 1:
        raise ValueError("callback address does not select ARM state")
    return {
        "halfwords": checked,
        "calls": len(CALL_TARGETS),
        "literals": len(LITERALS),
        "ranges": len(RANGES),
        "callback_address": callback_address,
        "interworking": "Thumb BX r3 to even-address ARM target",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path, help="path to the original GBA ROM")
    result = verify(parser.parse_args().rom.read_bytes())
    print("PASS: {} Thumb halfwords across {} ranges, {} direct calls, "
          "{} literal words; callback {} ({})".format(
              result["halfwords"], result["ranges"], result["calls"],
              result["literals"], f"{result['callback_address']:#010x}",
              result["interworking"]))


if __name__ == "__main__":
    main()
