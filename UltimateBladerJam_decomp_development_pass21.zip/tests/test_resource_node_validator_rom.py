import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from verify_resource_node_validator import verify


class ResourceNodeValidatorRomTests(unittest.TestCase):
    def test_original_rom_bytes_match_listing_and_call_contract(self):
        if len(sys.argv) < 2:
            self.fail("pass the locally supplied original ROM path as argv[1]")
        report = verify(Path(sys.argv[1]).read_bytes())
        self.assertEqual(report["entry"], 0x080604F8)
        self.assertEqual(report["instruction_halfwords"], 32)
        self.assertEqual(report["diagnostic_pointers"],
                         (0x0875591C, 0x08755938, 0x08755954))
        self.assertEqual(report["call_targets"], (0x08057C5C,) * 3)


if __name__ == "__main__":
    unittest.main()
